# PowerShell Deployment Script for Solution.AI to Plesk Server
# Server: ai.erpabsolute.net (156.67.110.254:15987)

Write-Host "=== Solution.AI Plesk Deployment Script ===" -ForegroundColor Cyan
Write-Host "Target Server: ai.erpabsolute.net" -ForegroundColor Green
Write-Host "Server IP: 156.67.110.254" -ForegroundColor Green
Write-Host "Port: 15987" -ForegroundColor Green
Write-Host "Plesk Panel: http://156.67.110.254:8880/" -ForegroundColor Green
Write-Host ""

# Configuration
$ServerUser = "your_ssh_username"  # Update this with your SSH username
$ServerHost = "156.67.110.254"
$RemotePath = "/var/www/vhosts/ai.erpabsolute.net/httpdocs"
$LocalPath = "."

Write-Host "Prerequisites:" -ForegroundColor Yellow
Write-Host "1. SSH access to the server (use PuTTY or OpenSSH)" -ForegroundColor White
Write-Host "2. SCP/SFTP client (WinSCP recommended)" -ForegroundColor White
Write-Host "3. Updated SERVER_USER variable in this script" -ForegroundColor White
Write-Host ""

$continue = Read-Host "Continue with deployment? (y/N)"
if ($continue -ne "y" -and $continue -ne "Y") {
    Write-Host "Deployment cancelled." -ForegroundColor Red
    exit 1
}

Write-Host "Step 1: Creating deployment package..." -ForegroundColor Cyan
# Create a temporary deployment directory
$DeployDir = "deploy_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
New-Item -ItemType Directory -Path $DeployDir -Force | Out-Null

Write-Host "Copying application files..." -ForegroundColor White
# Copy necessary files and directories
Copy-Item -Path "app" -Destination "$DeployDir\" -Recurse -Force
Copy-Item -Path "plesk_deployment.py" -Destination "$DeployDir\" -Force
Copy-Item -Path "passenger_wsgi.py" -Destination "$DeployDir\" -Force
Copy-Item -Path "requirements-plesk.txt" -Destination "$DeployDir\" -Force
Copy-Item -Path ".env" -Destination "$DeployDir\" -Force
Copy-Item -Path ".htaccess" -Destination "$DeployDir\" -Force
Copy-Item -Path "PLESK_DEPLOYMENT_GUIDE.md" -Destination "$DeployDir\" -Force

# Create logs directory
New-Item -ItemType Directory -Path "$DeployDir\logs" -Force | Out-Null
New-Item -ItemType File -Path "$DeployDir\logs\.gitkeep" -Force | Out-Null

Write-Host "Step 2: Preparing for upload..." -ForegroundColor Cyan
Write-Host "Files prepared in directory: $DeployDir" -ForegroundColor Green
Write-Host ""

Write-Host "Manual Upload Instructions:" -ForegroundColor Yellow
Write-Host "Since PowerShell doesn't have built-in SCP, please follow these steps:" -ForegroundColor White
Write-Host ""
Write-Host "Option 1 - Using WinSCP:" -ForegroundColor Green
Write-Host "1. Download and install WinSCP from https://winscp.net/" -ForegroundColor White
Write-Host "2. Connect to server: $ServerHost" -ForegroundColor White
Write-Host "3. Navigate to: $RemotePath" -ForegroundColor White
Write-Host "4. Upload all files from: $((Get-Location).Path)\$DeployDir" -ForegroundColor White
Write-Host ""

Write-Host "Option 2 - Using OpenSSH (if installed):" -ForegroundColor Green
Write-Host "Run this command in PowerShell:" -ForegroundColor White
Write-Host "scp -r $DeployDir\* ${ServerUser}@${ServerHost}:$RemotePath/" -ForegroundColor Gray
Write-Host ""

Write-Host "Option 3 - Using Plesk File Manager:" -ForegroundColor Green
Write-Host "1. Access Plesk Panel: http://156.67.110.254:8880/" -ForegroundColor White
Write-Host "2. Go to Files > File Manager" -ForegroundColor White
Write-Host "3. Navigate to httpdocs directory" -ForegroundColor White
Write-Host "4. Upload files from: $DeployDir" -ForegroundColor White
Write-Host ""

$uploadComplete = Read-Host "Press Enter after you've uploaded the files..."

Write-Host "Step 3: Post-upload configuration..." -ForegroundColor Cyan
Write-Host ""
Write-Host "SSH Commands to run on the server:" -ForegroundColor Yellow
Write-Host "# Connect to server via SSH" -ForegroundColor Gray
Write-Host "ssh $ServerUser@$ServerHost" -ForegroundColor Gray
Write-Host ""
Write-Host "# Set file permissions" -ForegroundColor Gray
Write-Host "cd $RemotePath" -ForegroundColor Gray
Write-Host "chmod 755 ." -ForegroundColor Gray
Write-Host "chmod -R 644 *" -ForegroundColor Gray
Write-Host "chmod 755 plesk_deployment.py" -ForegroundColor Gray
Write-Host "chmod 755 passenger_wsgi.py" -ForegroundColor Gray
Write-Host "chmod 755 logs" -ForegroundColor Gray
Write-Host "find . -type d -exec chmod 755 {} \;" -ForegroundColor Gray
Write-Host ""
Write-Host "# Install Python dependencies" -ForegroundColor Gray
Write-Host "pip3 install -r requirements-plesk.txt" -ForegroundColor Gray
Write-Host ""

Write-Host "Step 4: Plesk Configuration" -ForegroundColor Cyan
Write-Host ""
Write-Host "Configure in Plesk Panel (http://156.67.110.254:8880/):" -ForegroundColor Yellow
Write-Host "1. Go to Websites & Domains > Python" -ForegroundColor White
Write-Host "2. Create new Python application:" -ForegroundColor White
Write-Host "   - Application Type: Python 3.9+" -ForegroundColor White
Write-Host "   - Application Root: /httpdocs" -ForegroundColor White
Write-Host "   - Application URL: /" -ForegroundColor White
Write-Host "   - Startup File: plesk_deployment.py" -ForegroundColor White
Write-Host ""
Write-Host "3. Set Environment Variables:" -ForegroundColor White
Write-Host "   - OPENAI_API_KEY=your_openai_api_key" -ForegroundColor White
Write-Host "   - SECRET_KEY=your_production_secret_key" -ForegroundColor White
Write-Host "   - FLASK_ENV=production" -ForegroundColor White
Write-Host "   - PORT=15987" -ForegroundColor White
Write-Host "   - TESSERACT_CMD=/usr/bin/tesseract" -ForegroundColor White
Write-Host ""

Write-Host "Step 5: Testing" -ForegroundColor Cyan
Write-Host "Test URLs:" -ForegroundColor Yellow
Write-Host "- Basic: https://ai.erpabsolute.net/" -ForegroundColor White
Write-Host "- With params: https://ai.erpabsolute.net/?regid=test&uid=testuser" -ForegroundColor White
Write-Host ""

Write-Host "=== Deployment Summary ===" -ForegroundColor Cyan
Write-Host "✓ Files prepared in: $DeployDir" -ForegroundColor Green
Write-Host "📁 Next steps:" -ForegroundColor Yellow
Write-Host "1. Complete file upload to server" -ForegroundColor White
Write-Host "2. Run SSH commands for permissions" -ForegroundColor White
Write-Host "3. Configure Python application in Plesk" -ForegroundColor White
Write-Host "4. Set environment variables" -ForegroundColor White
Write-Host "5. Test the application" -ForegroundColor White
Write-Host ""
Write-Host "📖 For detailed instructions, see: PLESK_DEPLOYMENT_GUIDE.md" -ForegroundColor Green

$cleanup = Read-Host "Remove deployment directory? (y/N)"
if ($cleanup -eq "y" -or $cleanup -eq "Y") {
    Remove-Item -Path $DeployDir -Recurse -Force
    Write-Host "Deployment directory cleaned up." -ForegroundColor Green
}
else {
    Write-Host "Deployment directory preserved: $DeployDir" -ForegroundColor Yellow
}

Write-Host "Deployment script completed!" -ForegroundColor Green