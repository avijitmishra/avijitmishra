#!/bin/bash
# Deployment script for Solution.AI to Plesk Server
# Server: ai.erpabsolute.net (156.67.110.254:15987)

echo "=== Solution.AI Plesk Deployment Script ==="
echo "Target Server: ai.erpabsolute.net"
echo "Server IP: 156.67.110.254"
echo "Port: 15987"
echo "Plesk Panel: http://156.67.110.254:8880/"
echo ""

# Configuration
SERVER_USER="your_ssh_username"
SERVER_HOST="156.67.110.254"
REMOTE_PATH="/var/www/vhosts/ai.erpabsolute.net/httpdocs"
LOCAL_PATH="."

echo "Please ensure you have:"
echo "1. SSH access to the server"
echo "2. Proper file permissions"
echo "3. Updated the SERVER_USER variable in this script"
echo ""

read -p "Continue with deployment? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Deployment cancelled."
    exit 1
fi

echo "Step 1: Creating deployment package..."
# Create a temporary deployment directory
DEPLOY_DIR="deploy_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$DEPLOY_DIR"

# Copy necessary files
echo "Copying application files..."
cp -r app/ "$DEPLOY_DIR/"
cp plesk_deployment.py "$DEPLOY_DIR/"
cp passenger_wsgi.py "$DEPLOY_DIR/"
cp requirements-plesk.txt "$DEPLOY_DIR/"
cp .env "$DEPLOY_DIR/"
cp .htaccess "$DEPLOY_DIR/"
cp PLESK_DEPLOYMENT_GUIDE.md "$DEPLOY_DIR/"

# Create logs directory
mkdir -p "$DEPLOY_DIR/logs"
touch "$DEPLOY_DIR/logs/.gitkeep"

echo "Step 2: Uploading files to server..."
if command -v rsync >/dev/null 2>&1; then
    echo "Using rsync for deployment..."
    rsync -avz --progress "$DEPLOY_DIR/" "$SERVER_USER@$SERVER_HOST:$REMOTE_PATH/"
else
    echo "rsync not found. Using scp for deployment..."
    scp -r "$DEPLOY_DIR/"* "$SERVER_USER@$SERVER_HOST:$REMOTE_PATH/"
fi

echo "Step 3: Setting file permissions..."
ssh "$SERVER_USER@$SERVER_HOST" << 'ENDSSH'
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs
chmod 755 .
chmod -R 644 *
chmod 755 plesk_deployment.py
chmod 755 passenger_wsgi.py
chmod 755 logs
find . -type d -exec chmod 755 {} \;
echo "File permissions set successfully."
ENDSSH

echo "Step 4: Installing Python dependencies..."
ssh "$SERVER_USER@$SERVER_HOST" << 'ENDSSH'
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs
if command -v pip3 >/dev/null 2>&1; then
    pip3 install -r requirements-plesk.txt
elif command -v pip >/dev/null 2>&1; then
    pip install -r requirements-plesk.txt
else
    echo "Warning: pip not found. Please install dependencies manually."
fi
echo "Dependencies installation completed."
ENDSSH

echo "Step 5: Testing deployment..."
echo "Testing application accessibility..."
curl -I "http://$SERVER_HOST/" 2>/dev/null | head -1

echo ""
echo "=== Deployment Summary ==="
echo "✓ Files uploaded to: $REMOTE_PATH"
echo "✓ Permissions set"
echo "✓ Dependencies installed"
echo ""
echo "Next steps:"
echo "1. Access Plesk Panel: http://156.67.110.254:8880/"
echo "2. Configure Python application settings"
echo "3. Set environment variables in Plesk"
echo "4. Test the application: https://ai.erpabsolute.net/"
echo ""
echo "For detailed instructions, see: PLESK_DEPLOYMENT_GUIDE.md"

# Cleanup
echo "Cleaning up deployment package..."
rm -rf "$DEPLOY_DIR"

echo "Deployment script completed!"