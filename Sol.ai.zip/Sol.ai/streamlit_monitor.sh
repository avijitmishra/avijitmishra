#!/bin/bash
# Streamlit Health Monitor and Auto-Restart Script
# This script monitors Streamlit and restarts it if it goes down

# Configuration
APP_DIR="/var/www/vhosts/ai.erpabsolute.net/httpdocs"
LOG_DIR="/var/www/vhosts/ai.erpabsolute.net/logs"
STARTUP_SCRIPT="$APP_DIR/start_streamlit.sh"
CHECK_INTERVAL=60  # Check every 60 seconds
MAX_RESTART_ATTEMPTS=5
RESTART_DELAY=30

# Create logs directory
mkdir -p "$LOG_DIR"

# Logging function
log_health() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] HEALTH: $1" >> "$LOG_DIR/health.log"
}

# Function to check if Streamlit is responding
check_streamlit_health() {
    # Check if process is running
    if ! pgrep -f "streamlit run app.py" > /dev/null; then
        return 1
    fi
    
    # Check if port 8501 is responding
    if ! curl -s --max-time 10 http://localhost:8501 > /dev/null; then
        return 1
    fi
    
    return 0
}

# Function to restart Streamlit
restart_streamlit() {
    log_health "Attempting to restart Streamlit..."
    if [ -x "$STARTUP_SCRIPT" ]; then
        "$STARTUP_SCRIPT" restart
        return $?
    else
        log_health "ERROR: Startup script not found or not executable: $STARTUP_SCRIPT"
        return 1
    fi
}

# Main monitoring loop
main() {
    log_health "Starting Streamlit health monitor..."
    restart_count=0
    
    while true; do
        if check_streamlit_health; then
            log_health "✅ Streamlit is healthy"
            restart_count=0  # Reset counter on successful check
        else
            log_health "❌ Streamlit health check failed"
            
            if [ $restart_count -lt $MAX_RESTART_ATTEMPTS ]; then
                restart_count=$((restart_count + 1))
                log_health "Restart attempt $restart_count/$MAX_RESTART_ATTEMPTS"
                
                if restart_streamlit; then
                    log_health "✅ Streamlit restarted successfully"
                    sleep $RESTART_DELAY  # Wait before next check
                else
                    log_health "❌ Failed to restart Streamlit"
                    sleep $RESTART_DELAY
                fi
            else
                log_health "❌ Maximum restart attempts reached. Manual intervention required."
                # Send alert email if configured
                if command -v mail &> /dev/null; then
                    echo "Streamlit service on ai.erpabsolute.net has failed multiple restart attempts. Manual intervention required." | \
                        mail -s "ALERT: Streamlit Service Down" admin@erpabsolute.net 2>/dev/null || true
                fi
                sleep 300  # Wait 5 minutes before trying again
                restart_count=0  # Reset counter
            fi
        fi
        
        sleep $CHECK_INTERVAL
    done
}

# Handle signals
trap 'log_health "Health monitor stopping..."; exit 0' SIGTERM SIGINT

# Start monitoring
main