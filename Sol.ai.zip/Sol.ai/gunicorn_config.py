# Gunicorn configuration file
import multiprocessing
import os

# Server socket
bind = '127.0.0.1:5000'

# Worker processes
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = 'gunicorn.workers.gthread.ThreadWorker'
threads = 3

# Logging
accesslog = '/var/log/gunicorn/access.log'
errorlog = '/var/log/gunicorn/error.log'
loglevel = 'info'

# Security
limit_request_line = 4094
limit_request_fields = 100
limit_request_field_size = 8190

# Timeouts
timeout = 120
keepalive = 5

# Server mechanics
pidfile = '/tmp/gunicorn.pid'
user = 'psacln'
group = 'psaserv'

# Server software
server_software = 'gunicorn'

# Load environment variables from .env file
from dotenv import load_dotenv
load_dotenv()
