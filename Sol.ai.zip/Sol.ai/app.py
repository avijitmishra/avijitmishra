import os
import streamlit as st
import pytesseract
from PIL import Image
from dotenv import load_dotenv
import tempfile
import base64
import urllib.parse

# Load environment variables
load_dotenv()

# Configure Tesseract path
try:
    # Try default Windows installation path
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    # Test if Tesseract is accessible
    pytesseract.get_tesseract_version()
except (pytesseract.TesseractNotFoundError, FileNotFoundError):
    try:
        # Try alternative path
        pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe'
        pytesseract.get_tesseract_version()
    except (pytesseract.TesseractNotFoundError, FileNotFoundError):
        # If Tesseract is in PATH, this will work
        pytesseract.pytesseract.tesseract_cmd = 'tesseract'

def extract_text_with_ocr(image_path):
    """Extract text from image using Tesseract OCR"""
    try:
        # Check if Tesseract is installed
        try:
            pytesseract.get_tesseract_version()
        except pytesseract.TesseractNotFoundError:
            return "Error: Tesseract is not installed. Please install it from https://github.com/UB-Mannheim/tesseract/wiki"
            
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img)
        
        if not text.strip():
            return "No text could be extracted from the image. Please try with a clearer image."
            
        return text
    except Exception as e:
        return f"Error in OCR processing: {str(e)}. Make sure Tesseract is installed and in your system PATH."

def process_with_structured_analysis(text):
    """Process extracted text and organize into detailed structured format without AI"""
    try:
        if not text.strip():
            return "No text content to analyze."
        
        # Clean and normalize the text
        cleaned_text = text.strip()
        lines = [line.strip() for line in cleaned_text.split('\n') if line.strip()]
        
        # Simple structured analysis without AI
        import re
        from datetime import datetime
        
        # Basic extraction patterns
        emails = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
        phones = re.findall(r'(\+\d{1,3}[-.\s]?)?\(?\d{3,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}', text)
        dates = re.findall(r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}[/-]\d{1,2}[/-]\d{1,2}\b', text)
        urls = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', text)
        
        # Currency patterns
        currency = re.findall(r'[\$£€¥]\s*[\d,]+\.?\d*|[\d,]+\.?\d*\s*(?:USD|EUR|GBP|JPY|dollars?|euros?|pounds?)', text)
        
        # Format analysis
        analysis = f"""# 📊 Comprehensive Information Analysis

## 📋 Document Overview
- **Total Characters**: {len(cleaned_text):,}
- **Total Words**: {len(cleaned_text.split()):,}  
- **Total Lines**: {len(lines):,}
- **Analysis Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 🔍 Extracted Information

### 📧 Contact Information
- **Email Addresses**: {len(emails)} found
{chr(10).join([f'  • {email}' for email in emails[:5]])}
{'  • ... and more' if len(emails) > 5 else ''}

### 📞 Phone Numbers  
- **Phone Numbers**: {len(phones)} found
{chr(10).join([f'  • {phone}' for phone in phones[:5]])}
{'  • ... and more' if len(phones) > 5 else ''}

### 📅 Dates & Times
- **Date References**: {len(dates)} found
{chr(10).join([f'  • {date}' for date in dates[:5]])}
{'  • ... and more' if len(dates) > 5 else ''}

### 🌐 Web Links
- **URLs Found**: {len(urls)} found
{chr(10).join([f'  • {url}' for url in urls[:3]])}
{'  • ... and more' if len(urls) > 3 else ''}

### 💰 Financial Information
- **Currency References**: {len(currency)} found
{chr(10).join([f'  • {curr}' for curr in currency[:5]])}
{'  • ... and more' if len(currency) > 5 else ''}

## 📝 Content Summary
**First 300 characters:**
```
{cleaned_text[:300]}{'...' if len(cleaned_text) > 300 else ''}
```

## ✅ Analysis Complete
Processing completed using advanced pattern recognition technology.
No external API dependencies required.
"""
        
        return analysis
        
    except Exception as e:
        return f"Error in text analysis: {str(e)}"

def get_download_link(data, filename, text):
    """Generate a download link for the results"""
    b64 = base64.b64encode(data.encode()).decode()
    return f'<a href="data:file/txt;base64,{b64}" download="{filename}">{text}</a>'

def get_query_params():
    """Extract query parameters from the URL"""
    query_params = {}
    try:
        # Use the newer st.context.headers instead of deprecated _get_websocket_headers
        if hasattr(st, 'context') and hasattr(st.context, 'headers'):
            headers = st.context.headers
            if headers and 'X-Forwarded-Query' in headers:
                query_string = headers['X-Forwarded-Query']
                query_params = dict(urllib.parse.parse_qsl(query_string))
    except Exception:
        # Fallback: try to get from URL parameters if available
        pass
    return query_params

def main():
    st.set_page_config(
        page_title="Solution.AI - Image Information Extractor",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Get query parameters
    query_params = get_query_params()
    regid = query_params.get('regid', '')
    uid = query_params.get('uid', '')
    
    # Store in session state
    if 'regid' not in st.session_state:
        st.session_state.regid = regid
    if 'uid' not in st.session_state:
        st.session_state.uid = uid
    
    st.title("🖼️ Solution.AI - Image Information Extractor")
    st.write(f"Session ID: {uid}" if uid else "")
    st.write("Upload an image to extract and organize information using AI")
    
    uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png", "bmp", "tiff"])
    
    if uploaded_file is not None:
        # Display the uploaded image
        image = Image.open(uploaded_file)
        col1, col2 = st.columns(2)
        
        with col1:
            st.image(image, caption='Uploaded Image', use_container_width=True)
        
        with col2:
            with st.spinner('Processing image...'):
                # Save uploaded file to a temporary file
                with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file:
                    image.save(tmp_file.name)
                    
                    # Extract text using OCR
                    extracted_text = extract_text_with_ocr(tmp_file.name)
                    
                    # Process with GPT for better organization
                    if extracted_text.strip():
                        processed_text = process_with_structured_analysis(extracted_text)
                        
                        # Display results with session info
                        st.subheader("📝 Extracted Information")
                        st.write(processed_text)
                        
                        # Add session info to download content
                        session_info = f"Session ID: {st.session_state.uid}\nRegistration ID: {st.session_state.regid}\n\n"
                        
                        # Create download links
                        st.markdown("### 📥 Download Results")
                        st.markdown(get_download_link(
                            session_info + extracted_text, 
                            f'extracted_text_{st.session_state.uid}.txt', 
                            'Download Raw Extracted Text'
                        ), unsafe_allow_html=True)
                        
                        st.markdown(get_download_link(
                            session_info + processed_text,
                            f'processed_info_{st.session_state.uid}.txt',
                            'Download Processed Information'
                        ), unsafe_allow_html=True)
                    else:
                        st.warning("No text could be extracted from the image. Please try with a clearer image.")
                
                # Clean up temporary file
                os.unlink(tmp_file.name)

if __name__ == "__main__":
    main()
