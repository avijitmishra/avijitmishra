# Solution.AI Plesk Deployment Package

## ✅ **FIXED: Deprecation Warnings Removed**

### � **Recent Updates:**
- ✅ **Streamlit deprecation warnings fixed**
  - Removed `_get_websocket_headers()` usage
  - Updated to use `st.context.headers` 
  - Changed `use_column_width=True` to `use_container_width=True`
  
- ✅ **OpenAI API updated**
  - Updated from deprecated `openai.ChatCompletion.create()`
  - Now using modern `OpenAI().chat.completions.create()`
  - Applied to both Streamlit and Flask applications

- ✅ **404 Error Troubleshooting**
  - Created comprehensive troubleshooting guide
  - Added server test HTML file
  - Deployment verification tools ready

## 📦 **Updated Deployment Package**

This package contains all necessary files to deploy Solution.AI to your Plesk server at `ai.erpabsolute.net`.

### 🔧 Core Application Files
- `plesk_deployment.py` - Main WSGI application entry point for Plesk
- `passenger_wsgi.py` - Passenger/WSGI configuration file
- `app/` - Flask application directory (existing)
  - `__init__.py` - Flask app initialization
  - `routes.py` - Application routes and logic
  - `templates/` - HTML templates

### 📋 Configuration Files
- `requirements-plesk.txt` - Python dependencies for Plesk environment
- `.env.plesk` - Environment variables template (rename to `.env`)
- `.htaccess` - Apache configuration and security settings

### 🚀 Deployment Scripts
- `deploy_to_plesk.sh` - Linux/macOS deployment script
- `deploy_to_plesk.ps1` - PowerShell deployment script for Windows
- `test_deployment.py` - Post-deployment testing script

### 📖 Documentation
- `PLESK_DEPLOYMENT_GUIDE.md` - Comprehensive deployment instructions
- `DEPLOYMENT_SUMMARY.md` - This file

## 🎯 Quick Start Deployment

### Server Information
- **Domain**: ai.erpabsolute.net
- **Server IP**: 156.67.110.254
- **Port**: 15987
- **Plesk Panel**: http://156.67.110.254:8880/

### Query String Support
The application supports query parameters for session tracking:
- `regid` - Registration ID
- `uid` - User ID

Example URLs:
- `https://ai.erpabsolute.net/`
- `https://ai.erpabsolute.net/?regid=12345&uid=user001`

### Step-by-Step Deployment

#### 1. Prepare Environment
```bash
# Copy environment template
cp .env.plesk .env

# Edit .env with your actual values:
# - OpenAI API key
# - Production secret key
# - Server-specific paths
```

#### 2. Deploy Files
**Option A: Using PowerShell (Windows)**
```powershell
.\deploy_to_plesk.ps1
```

**Option B: Using Bash (Linux/macOS)**
```bash
chmod +x deploy_to_plesk.sh
./deploy_to_plesk.sh
```

**Option C: Manual Upload**
1. Access Plesk Panel: http://156.67.110.254:8880/
2. Go to File Manager
3. Upload all files to `httpdocs` directory

#### 3. Configure Plesk Python App
1. In Plesk Panel, go to "Websites & Domains" > "Python"
2. Create new Python application:
   - **Application Type**: Python 3.9+
   - **Application Root**: `/httpdocs`
   - **Application URL**: `/`
   - **Startup File**: `plesk_deployment.py`

#### 4. Set Environment Variables
In Plesk Python app settings, add:
```
OPENAI_API_KEY=your_openai_api_key_here
SECRET_KEY=your_production_secret_key
FLASK_ENV=production
FLASK_DEBUG=0
PORT=15987
TESSERACT_CMD=/usr/bin/tesseract
```

#### 5. Install Dependencies
```bash
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs
pip3 install -r requirements-plesk.txt
```

#### 6. Set File Permissions
```bash
chmod 755 /var/www/vhosts/ai.erpabsolute.net/httpdocs
chmod -R 644 /var/www/vhosts/ai.erpabsolute.net/httpdocs/*
chmod 755 /var/www/vhosts/ai.erpabsolute.net/httpdocs/plesk_deployment.py
chmod 755 /var/www/vhosts/ai.erpabsolute.net/httpdocs/logs
```

#### 7. Test Deployment
```bash
python3 test_deployment.py
```

## 🔧 System Requirements

### Server Requirements
- **OS**: Linux (Ubuntu/CentOS/RHEL)
- **Python**: 3.9 or higher
- **Web Server**: Apache with mod_wsgi or Passenger
- **OCR Engine**: Tesseract OCR

### Python Dependencies
- Flask 3.1.2
- pytesseract 0.3.13
- Pillow 11.3.0
- openai 2.4.0
- python-dotenv 1.1.1
- Other dependencies in `requirements-plesk.txt`

### System Dependencies
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install tesseract-ocr tesseract-ocr-eng python3-pip

# CentOS/RHEL
sudo yum install tesseract tesseract-langpack-eng python3-pip
```

## 🔒 Security Features

### Application Security
- HTTPS enforcement (when SSL configured)
- Session security with secure cookies
- CSRF protection
- XSS protection headers
- Content Security Policy
- File upload validation
- Environment variable protection

### Server Security
- `.htaccess` security headers
- Hidden sensitive files (.env, logs)
- File permission restrictions
- Input validation and sanitization

## 🧪 Testing

### Automated Testing
Run the test script after deployment:
```bash
python3 test_deployment.py
```

Tests include:
- Basic connectivity
- Query parameter handling
- Application endpoints
- Static resource loading

### Manual Testing
1. **Basic Access**: Visit https://ai.erpabsolute.net/
2. **Query Parameters**: Try https://ai.erpabsolute.net/?regid=test&uid=testuser
3. **Image Upload**: Upload a test image with text
4. **Text Extraction**: Verify OCR functionality
5. **Download**: Test file download feature

## 📊 Monitoring

### Application Logs
- **Location**: `/var/www/vhosts/ai.erpabsolute.net/httpdocs/logs/solutionai.log`
- **Rotation**: 10MB max, 5 backup files
- **View**: `tail -f logs/solutionai.log`

### Plesk Logs
- Access via Plesk Panel > Logs
- Error logs for debugging
- Access logs for monitoring

## 🆘 Troubleshooting

### Common Issues
1. **Tesseract not found**: Install Tesseract OCR and update path
2. **OpenAI API errors**: Verify API key and billing
3. **File permissions**: Check chmod settings
4. **Python dependencies**: Verify all packages installed
5. **Query parameters not working**: Check session configuration

### Debug Mode
For temporary debugging:
```bash
# In .env file
FLASK_DEBUG=1
FLASK_ENV=development
```
**⚠️ Important**: Always disable debug mode in production!

## 📞 Support

For deployment issues:
1. Check application logs: `logs/solutionai.log`
2. Check Plesk error logs
3. Run test script: `python3 test_deployment.py`
4. Review `PLESK_DEPLOYMENT_GUIDE.md` for detailed instructions

## ✅ Deployment Checklist

- [ ] Environment variables configured
- [ ] Files uploaded to server
- [ ] File permissions set correctly
- [ ] Python dependencies installed
- [ ] Tesseract OCR installed
- [ ] Plesk Python app configured
- [ ] SSL certificate configured (recommended)
- [ ] Application tested with query parameters
- [ ] Monitoring and logging verified

---

**Deployment Target**: ai.erpabsolute.net  
**Server**: 156.67.110.254:15987  
**Panel**: http://156.67.110.254:8880/