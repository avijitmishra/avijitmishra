# Deployment Guide for Plesk Server

This guide will help you deploy the Solution.AI application on your Plesk server at `http://156.67.110.254:8880/` for the domain `ai.erpabsolute.net`.

## Prerequisites

1. Access to Plesk control panel
2. Python 3.8+ installed on the server
3. Tesseract OCR installed on the server
4. Required Python packages installed

## Deployment Steps

### 1. Server Preparation

1. Log in to your Plesk control panel
2. Navigate to the domain: `ai.erpabsolute.net`
3. Go to "Hosting Settings" and ensure Python support is enabled

### 2. Application Setup

1. Upload all project files to your server (e.g., via FTP/SFTP or Git deployment)
2. Recommended directory structure:
   ```
   /var/www/vhosts/ai.erpabsolute.net/httpdocs/
   ├── app.py
   ├── requirements.txt
   ├── .env
   └── wsgi.py (create this file)
   ```

### 3. Create WSGI Entry Point

Create a new file `wsgi.py` in your project root with the following content:

```python
import sys
import os
from app import app as application

# Add the project directory to the Python path
sys.path.insert(0, os.path.dirname(__file__))

# Set environment variables
os.environ['FLASK_ENV'] = 'production'
```

### 4. Configure Python App in Plesk

1. In Plesk, go to "Python" under your domain
2. Set the following:
   - Application Root: `/var/www/vhosts/ai.erpabsolute.net/httpdocs`
   - Application Startup File: `wsgi.py`
   - Application Entry Point: `application`
   - Application URL: `http://ai.erpabsolute.net`
   - Environment Variables:
     ```
     TESSERACT_CMD=/usr/bin/tesseract
     SECRET_KEY=your_secure_key_here
     ```

### 5. Install Dependencies

SSH into your server and run:

```bash
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs
pip install -r requirements.txt
```

### 6. Install Tesseract OCR

On the server, install Tesseract:

```bash
# For Ubuntu/Debian
sudo apt update
sudo apt install tesseract-ocr

# For CentOS/RHEL
sudo yum install tesseract
```

### 7. Configure Nginx (if needed)

Add this to your Nginx configuration to handle query parameters:

```nginx
location / {
    proxy_pass http://127.0.0.1:8000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-Query $query_string;
}
```

### 8. Restart the Application

1. In Plesk, go to the Python app settings
2. Click "Restart application"

## Accessing the Application

Your application will be accessible at:
```
http://ai.erpabsolute.net?regid=YOUR_REG_ID&uid=YOUR_USER_ID
```

## Environment Variables

Create a `.env` file in your project root with:

```
TESSERACT_CMD=/usr/bin/tesseract
SECRET_KEY=your_secure_key_here
```

## Troubleshooting

1. Check Plesk error logs: `/var/log/plesk/`
2. Check application logs in Plesk Python settings
3. Verify Tesseract installation: `which tesseract`
4. Check file permissions: `chmod -R 755 /var/www/vhosts/ai.erpabsolute.net/httpdocs`

## Security Considerations

1. Keep your `.env` file secure and never commit it to version control
2. Use HTTPS for production
3. Set appropriate file permissions
4. Regularly update dependencies

## Backup

Regularly back up:
- Your application code
- Environment variables
- Any uploaded files (if storing locally)

## Updates

To update the application:
1. Upload new files
2. Install new dependencies if any
3. Restart the application in Plesk
