import os
import sys
from PIL import Image, ImageDraw
import tempfile

# Add the current directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_application():
    print("Testing Solution.AI application...\n")
    
    # Test if we can import the application
    try:
        from app import extract_text_with_ocr
        print("✅ Application imports successfully")
    except ImportError as e:
        print(f"❌ Error importing application: {e}")
        return
    
    # Test Tesseract status
    print("\n🔍 Checking Tesseract installation...")
    try:
        import pytesseract
        try:
            pytesseract.get_tesseract_version()
            print("✅ Tesseract is installed and accessible")
        except pytesseract.TesseractNotFoundError:
            print("❌ Tesseract is not installed or not in PATH")
            print("   Please install Tesseract from: https://github.com/UB-Mannheim/tesseract/wiki")
    except ImportError:
        print("❌ pytesseract package is not installed")
    
    # Test complete - no external APIs needed
    print("\n✅ All required dependencies verified!")
    print("🚀 Solution.AI uses pattern recognition (no OpenAI required)!")
    
    # Test creating a sample image
    print("\n🖼️ Creating a test image...")
    try:
        img = Image.new('RGB', (400, 200), color='white')
        d = ImageDraw.Draw(img)
        d.text((10, 10), "This is a test image for Solution.AI", fill='black')
        
        test_image_path = os.path.join(tempfile.gettempdir(), 'test_image.png')
        img.save(test_image_path)
        print(f"✅ Created test image at: {test_image_path}")
    except Exception as e:
        print(f"❌ Error creating test image: {e}")
        return
    
    # Test OCR functionality
    print("\n🔍 Testing OCR functionality...")
    try:
        text = extract_text_with_ocr(test_image_path)
        if "Error" in text:
            print(f"⚠️  {text}")
        else:
            print(f"✅ Extracted text: {text[:100]}...")
    except Exception as e:
        print(f"❌ Error testing OCR: {e}")
    
    # Clean up
    try:
        os.remove(test_image_path)
    except:
        pass

if __name__ == "__main__":
    test_application()
