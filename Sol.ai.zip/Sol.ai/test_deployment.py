#!/usr/bin/env python3
"""
Test script for Solution.AI Plesk deployment
Tests basic functionality and query parameter support
"""

import requests
import sys
import time
from urllib.parse import urlencode

# Test configuration
BASE_URL = "https://ai.erpabsolute.net"
TEST_PARAMS = {
    'regid': 'TEST123',
    'uid': 'testuser001'
}

def test_basic_connection():
    """Test basic connectivity to the application"""
    print("🔍 Testing basic connection...")
    try:
        response = requests.get(BASE_URL, timeout=10)
        if response.status_code == 200:
            print("✅ Basic connection successful")
            print(f"   Status Code: {response.status_code}")
            print(f"   Content Length: {len(response.content)} bytes")
            return True
        else:
            print(f"❌ Connection failed with status code: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Connection error: {e}")
        return False

def test_query_parameters():
    """Test query parameter handling"""
    print("\n🔍 Testing query parameters...")
    try:
        url_with_params = f"{BASE_URL}?{urlencode(TEST_PARAMS)}"
        print(f"   Testing URL: {url_with_params}")
        
        response = requests.get(url_with_params, timeout=10)
        if response.status_code == 200:
            print("✅ Query parameters test successful")
            # Check if the response contains expected session tracking
            if 'regid' in response.text.lower() or 'uid' in response.text.lower():
                print("✅ Session tracking appears to be working")
            else:
                print("⚠️  Session tracking not detected in response")
            return True
        else:
            print(f"❌ Query parameters test failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Query parameters test error: {e}")
        return False

def test_application_endpoints():
    """Test specific application endpoints"""
    print("\n🔍 Testing application endpoints...")
    endpoints = [
        ('/', 'Main page'),
        ('/process', 'Image processing endpoint (should require POST)')
    ]
    
    results = []
    for endpoint, description in endpoints:
        try:
            url = f"{BASE_URL}{endpoint}"
            response = requests.get(url, timeout=10)
            print(f"   {description}: {response.status_code}")
            
            if endpoint == '/' and response.status_code == 200:
                results.append(True)
            elif endpoint == '/process' and response.status_code in [405, 400]:  # Method not allowed or bad request is expected
                results.append(True)
            else:
                results.append(False)
                
        except requests.exceptions.RequestException as e:
            print(f"   {description}: Error - {e}")
            results.append(False)
    
    return all(results)

def test_static_resources():
    """Test if static resources are loading"""
    print("\n🔍 Testing static resources...")
    try:
        response = requests.get(BASE_URL, timeout=10)
        if response.status_code == 200:
            content = response.text.lower()
            # Check for common static resource indicators
            if 'tailwindcss' in content or 'font-awesome' in content:
                print("✅ Static resources (CSS/JS) appear to be referenced")
                return True
            else:
                print("⚠️  Static resources not detected (may still work)")
                return True  # Not critical
        return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Static resources test error: {e}")
        return False

def run_comprehensive_test():
    """Run all tests and provide summary"""
    print("=" * 50)
    print("🚀 Solution.AI Plesk Deployment Test Suite")
    print("=" * 50)
    print(f"Target URL: {BASE_URL}")
    print(f"Test Parameters: {TEST_PARAMS}")
    print("-" * 50)
    
    tests = [
        ("Basic Connection", test_basic_connection),
        ("Query Parameters", test_query_parameters),
        ("Application Endpoints", test_application_endpoints),
        ("Static Resources", test_static_resources)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ Test '{test_name}' failed with exception: {e}")
            results.append((test_name, False))
        
        time.sleep(1)  # Small delay between tests
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 50)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:.<30} {status}")
        if result:
            passed += 1
    
    print("-" * 50)
    print(f"Total: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Deployment appears successful.")
        return True
    elif passed >= total * 0.7:  # 70% pass rate
        print("⚠️  Most tests passed. Check failed tests above.")
        return True
    else:
        print("❌ Multiple test failures. Check deployment configuration.")
        return False

if __name__ == "__main__":
    success = run_comprehensive_test()
    sys.exit(0 if success else 1)