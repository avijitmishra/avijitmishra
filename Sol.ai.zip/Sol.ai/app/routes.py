from flask import render_template, request, jsonify, send_file, session
from app import app
import os
import pytesseract
from PIL import Image
import tempfile
import io
import pandas as pd
from io import BytesIO
import openpyxl
from docx import Document
from docx.shared import Inches
from datetime import datetime

def get_tesseract_status():
    """Check if Tesseract is installed and accessible"""
    try:
        pytesseract.get_tesseract_version()
        return True, "Tesseract is installed and accessible"
    except pytesseract.TesseractNotFoundError:
        return False, "Tesseract is not installed or not in PATH"

def extract_text_with_ocr(image_path):
    """Extract text from image using Tesseract OCR"""
    try:
        # Check if Tesseract is installed
        tesseract_installed, _ = get_tesseract_status()
        if not tesseract_installed:
            return False, "Tesseract is not installed. Please install it from https://github.com/UB-Mannheim/tesseract/wiki"
            
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img)
        
        if not text.strip():
            return False, "No text could be extracted from the image. Please try with a clearer image."
            
        return True, text.strip()
    except Exception as e:
        return False, f"Error in OCR processing: {str(e)}"

def process_with_structured_analysis(text):
    """Process extracted text and organize into detailed structured format without AI"""
    try:
        if not text.strip():
            return False, None  # Return False, None instead of error message
        
        # Clean and normalize the text
        cleaned_text = text.strip()
        lines = [line.strip() for line in cleaned_text.split('\n') if line.strip()]
        
        # Simple structured analysis without AI
        import re
        from datetime import datetime
        
        # Basic extraction patterns
        emails = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
        phones = re.findall(r'(\+\d{1,3}[-.\s]?)?\(?\d{3,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}', text)
        dates = re.findall(r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}[/-]\d{1,2}[/-]\d{1,2}\b', text)
        
        # Format analysis
        analysis = f"""📊 Information Analysis Results

📋 Document Summary:
- Total Characters: {len(cleaned_text):,}
- Total Words: {len(cleaned_text.split()):,}  
- Total Lines: {len(lines):,}
- Analysis Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

🔍 Extracted Data:
- Emails Found: {len(emails)} ({'Yes' if emails else 'None'})
- Phone Numbers: {len(phones)} ({'Yes' if phones else 'None'})
- Dates Found: {len(dates)} ({'Yes' if dates else 'None'})

📝 Content Preview:
{cleaned_text[:300]}{'...' if len(cleaned_text) > 300 else ''}

✅ Processing completed using pattern recognition analysis."""
        
        return True, analysis
        
    except Exception:
        # Return False, None to hide the entire section if unable to process
        return False, None

@app.route('/')
def index():
    """Render the main page"""
    # Get query parameters
    regid = request.args.get('regid', '')
    uid = request.args.get('uid', '')
    
    # Store in session
    session['regid'] = regid
    session['uid'] = uid
    
    # Check Tesseract status
    tesseract_installed, tesseract_status = get_tesseract_status()
    
    return render_template('index.html', 
                         tesseract_installed=tesseract_installed,
                         tesseract_status=tesseract_status,
                         regid=regid,
                         uid=uid)

@app.route('/process', methods=['POST'])
def process_image():
    """Process uploaded image"""
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No file selected'}), 400
    
    try:
        # Save uploaded file to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file:
            file.save(tmp_file.name)
            
            # Extract text using OCR
            success, result = extract_text_with_ocr(tmp_file.name)
            
            if not success:
                return jsonify({
                    'success': False,
                    'message': result,
                    'extracted_text': '',
                    'processed_text': ''
                })
            
            extracted_text = result
            
            # Process with structured analysis
            success, result = process_with_structured_analysis(extracted_text)
            
            # Only return results if processing was successful
            if success and result is not None:
                return jsonify({
                    'success': True,
                    'message': 'Processing complete',
                    'extracted_text': extracted_text,
                    'processed_text': result
                })
            else:
                # If processing failed, don't show results section
                return jsonify({
                    'success': False,
                    'message': 'Unable to process image content',
                    'extracted_text': '',
                    'processed_text': ''
                })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error processing image: {str(e)}',
            'extracted_text': '',
            'processed_text': ''
        }), 500
    
    finally:
        # Clean up temporary file
        if 'tmp_file' in locals() and os.path.exists(tmp_file.name):
            os.unlink(tmp_file.name)

@app.route('/download')
def download():
    """Download processed text"""
    text = request.args.get('text', '')
    filename = request.args.get('filename', 'output.txt')
    
    # Add session info if available
    session_info = []
    if 'uid' in session and session['uid']:
        session_info.append(f"User ID: {session['uid']}")
    if 'regid' in session and session['regid']:
        session_info.append(f"Registration ID: {session['regid']}")
    
    if session_info:
        text = f"{' | '.join(session_info)}\n\n{text}"
    
    # Create a file-like object in memory
    file_like = io.BytesIO(text.encode('utf-8'))
    
    return send_file(
        file_like,
        as_attachment=True,
        download_name=filename,
        mimetype='text/plain'
    )
