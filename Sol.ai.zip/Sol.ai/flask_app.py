#!/usr/bin/env python3
"""
Simple Flask version of Solution.AI for localhost testing
"""

from flask import Flask, render_template_string, request, jsonify
import os
import sys
from PIL import Image
import pytesseract
import re
from datetime import datetime

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__)

# Import the OCR processing function from app.py
try:
    from app import process_with_structured_analysis
    print("✅ Imported OCR processing function from app.py")
except ImportError:
    print("❌ Could not import from app.py, using fallback")
    
    def process_with_structured_analysis(text):
        """Fallback processing function"""
        return {
            "emails": re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text),
            "phones": re.findall(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', text),
            "dates": re.findall(r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b', text),
            "numbers": re.findall(r'\b\d+\b', text)
        }

# HTML Template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Image Text Extraction</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f0f2f6;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .upload-area {
            border: 2px dashed #ccc;
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            margin-bottom: 20px;
            transition: border-color 0.3s;
        }
        .upload-area:hover {
            border-color: #ff6b6b;
        }
        .upload-area input[type="file"] {
            margin: 10px 0;
        }
        .btn {
            background: #ff6b6b;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background: #e74c3c;
        }
        .results {
            margin-top: 20px;
        }
        .result-section {
            background: #f8f9fa;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            border-left: 4px solid #ff6b6b;
        }
        .extracted-text {
            background: #e8f5e8;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            white-space: pre-wrap;
            font-family: monospace;
        }
        .status {
            text-align: center;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
        }
        .status.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .status.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 Solution.AI</h1>
            <h2>Image Text Extraction Service</h2>
            <p><strong>Status:</strong> Running on Localhost</p>
            <p><strong>Features:</strong> OCR Text Extraction + Pattern Recognition</p>
        </div>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="upload-area">
                <h3>📤 Upload Image for Text Extraction</h3>
                <p>Select an image file (PNG, JPG, JPEG, BMP, TIFF)</p>
                <input type="file" name="image" accept="image/*" required>
                <br><br>
                <button type="submit" class="btn">🔍 Extract Text</button>
            </div>
        </form>
        
        {% if status %}
        <div class="status {{ status_type }}">
            {{ status }}
        </div>
        {% endif %}
        
        {% if extracted_text %}
        <div class="results">
            <h3>📄 Extracted Text:</h3>
            <div class="extracted-text">{{ extracted_text }}</div>
            
            {% if analysis %}
            <h3>🔍 Pattern Analysis:</h3>
            
            {% if analysis.emails %}
            <div class="result-section">
                <h4>📧 Email Addresses:</h4>
                <ul>
                {% for email in analysis.emails %}
                    <li>{{ email }}</li>
                {% endfor %}
                </ul>
            </div>
            {% endif %}
            
            {% if analysis.phones %}
            <div class="result-section">
                <h4>📞 Phone Numbers:</h4>
                <ul>
                {% for phone in analysis.phones %}
                    <li>{{ phone }}</li>
                {% endfor %}
                </ul>
            </div>
            {% endif %}
            
            {% if analysis.dates %}
            <div class="result-section">
                <h4>📅 Dates:</h4>
                <ul>
                {% for date in analysis.dates %}
                    <li>{{ date }}</li>
                {% endfor %}
                </ul>
            </div>
            {% endif %}
            
            {% if analysis.numbers %}
            <div class="result-section">
                <h4>🔢 Numbers:</h4>
                <ul>
                {% for number in analysis.numbers[:10] %}
                    <li>{{ number }}</li>
                {% endfor %}
                {% if analysis.numbers|length > 10 %}
                    <li><em>... and {{ analysis.numbers|length - 10 }} more numbers</em></li>
                {% endif %}
                </ul>
            </div>
            {% endif %}
            {% endif %}
        </div>
        {% endif %}
        
        <div class="container">
            <h3>ℹ️ Application Information</h3>
            <p><strong>Version:</strong> Solution.AI v2.0 (OpenAI-Free)</p>
            <p><strong>OCR Engine:</strong> Pytesseract</p>
            <p><strong>Pattern Recognition:</strong> Custom regex-based analysis</p>
            <p><strong>Supported Formats:</strong> PNG, JPG, JPEG, BMP, TIFF</p>
            <p><strong>Local Access:</strong> http://localhost:5000</p>
            <p><strong>Streamlit Version:</strong> http://localhost:8501</p>
        </div>
    </div>
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        return render_template_string(HTML_TEMPLATE)
    
    try:
        # Handle file upload
        if 'image' not in request.files:
            return render_template_string(HTML_TEMPLATE, 
                status="No image file selected", 
                status_type="error")
        
        file = request.files['image']
        if file.filename == '':
            return render_template_string(HTML_TEMPLATE, 
                status="No image file selected", 
                status_type="error")
        
        # Process the image
        image = Image.open(file.stream)
        
        # Extract text using OCR
        extracted_text = pytesseract.image_to_string(image)
        
        if not extracted_text.strip():
            return render_template_string(HTML_TEMPLATE, 
                status="No text could be extracted from the image", 
                status_type="error")
        
        # Analyze the extracted text
        analysis = process_with_structured_analysis(extracted_text)
        
        return render_template_string(HTML_TEMPLATE,
            extracted_text=extracted_text,
            analysis=analysis,
            status=f"Successfully extracted {len(extracted_text)} characters of text",
            status_type="success")
            
    except Exception as e:
        return render_template_string(HTML_TEMPLATE,
            status=f"Error processing image: {str(e)}",
            status_type="error")

@app.route('/health')
def health():
    return jsonify({
        "status": "healthy",
        "service": "Solution.AI Flask Version",
        "ocr_engine": "pytesseract",
        "timestamp": datetime.now().isoformat()
    })

if __name__ == '__main__':
    print("🚀 Starting Solution.AI Flask Server...")
    print("📱 Access the application at: http://localhost:5000")
    print("🔍 Health check at: http://localhost:5000/health")
    print("⚡ Streamlit version also running at: http://localhost:8501")
    print("")
    
    app.run(debug=True, host='localhost', port=5000)