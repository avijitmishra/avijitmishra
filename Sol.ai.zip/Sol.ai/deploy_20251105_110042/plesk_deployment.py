#!/usr/bin/env python3
"""
Plesk Server Deployment Configuration
Server: ai.erpabsolute.net
IP: 156.67.110.254
Port: 15987
Plesk Panel: http://156.67.110.254:8880/
"""

import logging
import os
from logging.handlers import RotatingFileHandler

from flask import request, session

from app import app as application

# Server Configuration
SERVER_CONFIG = {
    'host': '0.0.0.0',  # Listen on all interfaces for Plesk
    'port': int(os.environ.get('PORT', 15987)),  # Use environment PORT or default
    'debug': False,  # Never use debug in production
    'threaded': True,  # Enable threading for better performance
}

# Production Environment Setup
os.environ['FLASK_ENV'] = 'production'
os.environ['FLASK_DEBUG'] = '0'

# Configure application for production
application.config.update({
    'ENV': 'production',
    'DEBUG': False,
    'TESTING': False,
    'SECRET_KEY': os.environ.get('SECRET_KEY', 'production-secret-key-change-this'),
    'SESSION_COOKIE_SECURE': True,  # Use HTTPS cookies
    'SESSION_COOKIE_HTTPONLY': True,  # Prevent XSS
    'SESSION_COOKIE_SAMESITE': 'Lax',  # CSRF protection
    'PERMANENT_SESSION_LIFETIME': 1800,  # 30 minutes
})

# Set up logging for production
if not os.path.exists('logs'):
    os.makedirs('logs')

# Configure file logging
file_handler = RotatingFileHandler(
    'logs/solutionai.log', 
    maxBytes=10240000,  # 10MB
    backupCount=5
)
file_handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
))
file_handler.setLevel(logging.INFO)
application.logger.addHandler(file_handler)
application.logger.setLevel(logging.INFO)
application.logger.info('Solution.AI startup')

# Query string parameter handling
def get_query_params():
    """Extract query parameters for session tracking"""
    regid = request.args.get('regid', '')
    uid = request.args.get('uid', '')
    
    # Store in session if provided
    if regid:
        session['regid'] = regid
    if uid:
        session['uid'] = uid
    
    return {
        'regid': session.get('regid', ''),
        'uid': session.get('uid', '')
    }

# Add query parameter utility to app context
@application.context_processor
def inject_query_params():
    """Make query parameters available to all templates"""
    return dict(get_query_params=get_query_params)

if __name__ == '__main__':
    # For direct execution (development/testing)
    application.run(**SERVER_CONFIG)
else:
    # For WSGI server deployment
    # This will be used by Plesk's Python app hosting
    application.logger.info('Application loaded for WSGI')