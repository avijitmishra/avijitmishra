"""Passenger Configuration for Plesk."""
import os
import sys

from plesk_deployment import application

# Add the application directory to Python path
sys.path.insert(0, os.path.dirname(__file__))

# This is the WSGI callable that Passenger will use
if __name__ == "__main__":
    application.run()