# 🔧 Fixing 404 Error on ai.erpabsolute.net

## 🚨 Current Issue
The domain `https://ai.erpabsolute.net` is returning a **404 Not Found** error, which means the application files haven't been properly deployed or configured.

## ✅ Good News
- ✅ Domain is active and pointing to the server
- ✅ Apache server is running (Port 443)
- ✅ SSL certificate is working (HTTPS)
- ✅ Server is accessible

## 🔍 Possible Causes & Solutions

### 1. **Files Not Uploaded**
**Symptoms**: 404 error, no application files on server
**Solution**: Upload all deployment files

```bash
# Files that need to be uploaded to /var/www/vhosts/ai.erpabsolute.net/httpdocs/
- plesk_deployment.py
- passenger_wsgi.py  
- app/ (entire directory)
- requirements-plesk.txt
- .env
- .htaccess
```

### 2. **Wrong Directory**
**Symptoms**: Files uploaded but still 404
**Check**: Files must be in the correct directory
```bash
# Correct path for Plesk
/var/www/vhosts/ai.erpabsolute.net/httpdocs/

# NOT in subdirectories like:
/var/www/vhosts/ai.erpabsolute.net/httpdocs/app/
/var/www/vhosts/ai.erpabsolute.net/subdomains/
```

### 3. **Python App Not Configured in Plesk**
**Symptoms**: Files uploaded but Python not running
**Solution**: Configure Python application in Plesk Panel

#### Steps:
1. Access Plesk: http://156.67.110.254:8880/
2. Go to **Websites & Domains** > **Python**
3. Click **Enable Python**
4. Configure:
   - **Application Type**: Python 3.9+
   - **Application Root**: `/httpdocs`
   - **Application URL**: `/`
   - **Startup File**: `plesk_deployment.py`

### 4. **Missing Environment Variables**
**Symptoms**: App starts but errors occur
**Solution**: Set environment variables in Plesk

```bash
# Required variables:
OPENAI_API_KEY=your_openai_api_key_here
SECRET_KEY=your_production_secret_key
FLASK_ENV=production
FLASK_DEBUG=0
PORT=15987
TESSERACT_CMD=/usr/bin/tesseract
```

### 5. **File Permissions**
**Symptoms**: Permission denied errors
**Solution**: Set correct file permissions

```bash
# SSH to server and run:
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs
chmod 755 .
chmod -R 644 *
chmod 755 plesk_deployment.py
chmod 755 passenger_wsgi.py
chmod 755 logs
find . -type d -exec chmod 755 {} \;
```

### 6. **Missing Dependencies**
**Symptoms**: ImportError or ModuleNotFoundError
**Solution**: Install Python packages

```bash
# SSH to server and run:
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs
pip3 install -r requirements-plesk.txt
```

## 🚀 Quick Fix Checklist

### Step 1: Verify File Upload
```bash
# SSH to server and check:
ls -la /var/www/vhosts/ai.erpabsolute.net/httpdocs/
```
**Expected files:**
- plesk_deployment.py
- passenger_wsgi.py
- app/ (directory)
- requirements-plesk.txt
- .env
- .htaccess

### Step 2: Check Python App Status
1. Login to Plesk Panel
2. Go to **Websites & Domains**
3. Check if **Python** is enabled
4. Verify application configuration

### Step 3: Test with Simple HTML
Create a test file to verify basic connectivity:

```html
<!-- Create: /var/www/vhosts/ai.erpabsolute.net/httpdocs/test.html -->
<!DOCTYPE html>
<html>
<head><title>Test Page</title></head>
<body>
    <h1>Server Test</h1>
    <p>If you see this, the server is working!</p>
    <p>Current time: <?php echo date('Y-m-d H:i:s'); ?></p>
</body>
</html>
```

Test: https://ai.erpabsolute.net/test.html

### Step 4: Check Logs
```bash
# Application logs
tail -f /var/www/vhosts/ai.erpabsolute.net/httpdocs/logs/solutionai.log

# Apache error logs (via Plesk Panel)
Websites & Domains > Logs > Error Logs
```

## 🔧 Emergency Deployment Script

If manual deployment is needed, use this script:

```bash
#!/bin/bash
# Emergency deployment script

# Set variables
DOMAIN_PATH="/var/www/vhosts/ai.erpabsolute.net/httpdocs"

# Create directory if it doesn't exist
mkdir -p $DOMAIN_PATH
cd $DOMAIN_PATH

# Set permissions
chmod 755 .

# Install dependencies (if files are uploaded)
if [ -f "requirements-plesk.txt" ]; then
    pip3 install -r requirements-plesk.txt
fi

# Set file permissions
chmod -R 644 *
chmod 755 plesk_deployment.py
chmod 755 passenger_wsgi.py
chmod 755 logs
find . -type d -exec chmod 755 {} \;

echo "Emergency deployment completed!"
```

## 🧪 Test After Fix

After implementing fixes, test:

1. **Basic connectivity**: https://ai.erpabsolute.net/
2. **With parameters**: https://ai.erpabsolute.net/?regid=test&uid=testuser
3. **Run test script**: `python3 test_deployment.py`

## 📞 Need Help?

### Common Solutions by Error:
- **404 Not Found**: Files not uploaded or wrong directory
- **500 Internal Server Error**: Check error logs, usually missing dependencies
- **Permission Denied**: Fix file permissions with chmod commands
- **Module Not Found**: Install Python dependencies

### Quick Commands:
```bash
# Check if files exist
ls -la /var/www/vhosts/ai.erpabsolute.net/httpdocs/

# Check Python version
python3 --version

# Check if dependencies installed
pip3 list | grep -E "(flask|pytesseract|openai)"

# View recent errors
tail -20 /var/log/apache2/error.log
```

---

**Next Step**: Follow the checklist above to identify and fix the specific issue causing the 404 error.