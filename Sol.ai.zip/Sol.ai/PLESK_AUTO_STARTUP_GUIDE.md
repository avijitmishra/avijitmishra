# 🚀 Plesk Auto-Startup Deployment Guide for Solution.AI

## 📋 Overview

This guide ensures your Streamlit application **automatically starts and keeps running** on your Plesk server, with automatic restart capabilities and health monitoring.

## ✨ Auto-Startup Features

- **🔄 Automatic Boot Startup**: Starts when server reboots
- **💪 Auto-Restart**: Restarts if application crashes
- **📊 Health Monitoring**: Continuous health checks
- **📝 Comprehensive Logging**: Full activity tracking
- **🔧 Service Management**: Easy start/stop/restart commands

---

## 🛠️ Deployment Steps

### **Step 1: Upload Files with Auto-Startup Configuration**

```bash
# Use the enhanced deployment script
chmod +x deploy_to_plesk_enhanced.sh
./deploy_to_plesk_enhanced.sh
```

This script will:
- ✅ Upload all application files
- ✅ Configure systemd service for auto-startup
- ✅ Setup health monitoring
- ✅ Configure Nginx reverse proxy
- ✅ Start services automatically

### **Step 2: Verify Auto-Startup Configuration**

SSH into your server and check service status:

```bash
ssh -p 15987 ai.erpabsolute.net@156.67.110.254

# Check if Streamlit service is running
sudo systemctl status solution-ai-streamlit

# Check if monitoring is active
sudo systemctl status streamlit-monitor

# Verify auto-startup is enabled
sudo systemctl is-enabled solution-ai-streamlit
sudo systemctl is-enabled streamlit-monitor
```

### **Step 3: Test Auto-Restart Functionality**

```bash
# Test auto-restart by stopping the process
sudo systemctl stop solution-ai-streamlit

# Wait 30 seconds - it should restart automatically
sleep 30

# Check if it restarted
sudo systemctl status solution-ai-streamlit
```

---

## 🔧 Service Management Commands

### **Systemd Service Control**

```bash
# Start Streamlit service
sudo systemctl start solution-ai-streamlit

# Stop Streamlit service
sudo systemctl stop solution-ai-streamlit

# Restart Streamlit service
sudo systemctl restart solution-ai-streamlit

# Check service status
sudo systemctl status solution-ai-streamlit

# View service logs
sudo journalctl -u solution-ai-streamlit -f

# Enable/disable auto-startup
sudo systemctl enable solution-ai-streamlit   # Enable auto-start
sudo systemctl disable solution-ai-streamlit  # Disable auto-start
```

### **Manual Script Control**

```bash
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs

# Start application
./start_streamlit.sh start

# Stop application
./start_streamlit.sh stop

# Restart application
./start_streamlit.sh restart

# Check status
./start_streamlit.sh status

# Force restart (kills all processes)
./start_streamlit.sh force-restart
```

---

## 📊 Monitoring and Logging

### **Log Files Location**

```bash
LOG_DIR="/var/www/vhosts/ai.erpabsolute.net/logs"

# Application logs
tail -f $LOG_DIR/streamlit.log        # Streamlit output
tail -f $LOG_DIR/streamlit-error.log  # Error logs
tail -f $LOG_DIR/health.log           # Health monitoring
tail -f $LOG_DIR/startup.log          # Startup logs
```

### **Real-Time Monitoring**

```bash
# Monitor all logs simultaneously
multitail \
  /var/www/vhosts/ai.erpabsolute.net/logs/streamlit.log \
  /var/www/vhosts/ai.erpabsolute.net/logs/health.log

# Watch service status
watch -n 5 'sudo systemctl status solution-ai-streamlit'

# Monitor process activity
htop -p $(pgrep -f "streamlit run app.py")
```

---

## 🔄 Auto-Startup Configuration Details

### **Systemd Service Configuration**

The service file `/etc/systemd/system/solution-ai-streamlit.service` includes:

```ini
[Unit]
Description=Solution.AI Streamlit Application
After=network.target
Wants=network.target

[Service]
Type=simple
User=psacln
Group=psaserv
WorkingDirectory=/var/www/vhosts/ai.erpabsolute.net/httpdocs
ExecStart=/var/www/vhosts/ai.erpabsolute.net/venv/bin/streamlit run app.py --server.port=8501 --server.address=0.0.0.0 --server.headless=true
Restart=always
RestartSec=10
StartLimitInterval=0

[Install]
WantedBy=multi-user.target
```

### **Health Monitoring Features**

- **Process Monitoring**: Checks if Streamlit process is running
- **HTTP Health Checks**: Tests if port 8501 responds
- **Automatic Restart**: Restarts on failure (max 5 attempts)
- **Email Alerts**: Sends alerts on repeated failures (if configured)
- **Restart Delays**: Waits 30 seconds between restart attempts

---

## 🌐 Nginx Reverse Proxy Configuration

The deployment configures Nginx to proxy requests to Streamlit:

```nginx
server {
    listen 80;
    server_name ai.erpabsolute.net;

    location / {
        proxy_pass http://127.0.0.1:8501;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Query $query_string;
        
        # WebSocket support for Streamlit
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
        proxy_send_timeout 86400;
        
        # Handle large file uploads
        client_max_body_size 50M;
    }
}
```

---

## 🛡️ Security and Performance

### **Security Features**

- **Process Isolation**: Runs under restricted user account
- **Private Temp**: Isolated temporary directories
- **System Protection**: Read-only system access
- **No New Privileges**: Prevents privilege escalation

### **Performance Optimization**

- **Headless Mode**: No GUI overhead
- **Optimized Restart**: Quick restart on failure
- **Log Rotation**: Automatic log management
- **Resource Limits**: Memory and CPU constraints

---

## 🔍 Troubleshooting Auto-Startup

### **Service Won't Start**

```bash
# Check service status and logs
sudo systemctl status solution-ai-streamlit
sudo journalctl -u solution-ai-streamlit -n 50

# Check if dependencies are installed
which streamlit
which tesseract
python3 -c "import streamlit; print('OK')"

# Verify file permissions
ls -la /var/www/vhosts/ai.erpabsolute.net/httpdocs/app.py
```

### **Service Starts But Stops Immediately**

```bash
# Check application logs
tail -50 /var/www/vhosts/ai.erpabsolute.net/logs/streamlit-error.log

# Test manual startup
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs
source ../venv/bin/activate
streamlit run app.py --server.port=8501 --server.address=0.0.0.0
```

### **Health Monitor Not Working**

```bash
# Check monitor service
sudo systemctl status streamlit-monitor
sudo journalctl -u streamlit-monitor -n 50

# Test health check manually
curl -s http://localhost:8501
```

### **Port 8501 Not Accessible**

```bash
# Check if port is listening
netstat -tlnp | grep 8501
ss -tlnp | grep 8501

# Test firewall
sudo ufw status
iptables -L | grep 8501

# Check Nginx configuration
sudo nginx -t
sudo systemctl status nginx
```

---

## 📋 Maintenance Tasks

### **Regular Maintenance**

```bash
# Weekly log cleanup (add to crontab)
0 2 * * 0 find /var/www/vhosts/ai.erpabsolute.net/logs -name "*.log" -size +100M -delete

# Daily health check (add to crontab)
0 9 * * * /var/www/vhosts/ai.erpabsolute.net/httpdocs/start_streamlit.sh status | mail -s "Daily Streamlit Status" admin@erpabsolute.net

# Update dependencies monthly
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs
source ../venv/bin/activate
pip install --upgrade -r requirements.txt
sudo systemctl restart solution-ai-streamlit
```

### **Backup Configuration**

```bash
# Backup service files
sudo cp /etc/systemd/system/solution-ai-streamlit.service ~/backups/
sudo cp /etc/systemd/system/streamlit-monitor.service ~/backups/
sudo cp /etc/nginx/sites-available/streamlit-ai ~/backups/

# Backup application
tar -czf ~/backups/solution-ai-$(date +%Y%m%d).tar.gz \
  /var/www/vhosts/ai.erpabsolute.net/httpdocs
```

---

## ✅ Verification Checklist

After deployment, verify the following:

- [ ] **Service Auto-Start**: `sudo systemctl is-enabled solution-ai-streamlit`
- [ ] **Service Running**: `sudo systemctl is-active solution-ai-streamlit`
- [ ] **Monitor Active**: `sudo systemctl is-active streamlit-monitor`
- [ ] **Port Listening**: `netstat -tlnp | grep 8501`
- [ ] **HTTP Response**: `curl -s http://localhost:8501`
- [ ] **External Access**: Visit `http://ai.erpabsolute.net`
- [ ] **Logs Writing**: Check log files are being updated
- [ ] **Auto-Restart**: Stop service and verify it restarts

---

## 🎯 Success Indicators

When properly configured, you should see:

```bash
✅ solution-ai-streamlit.service - Solution.AI Streamlit Application
   Loaded: loaded (/etc/systemd/system/solution-ai-streamlit.service; enabled; vendor preset: enabled)
   Active: active (running) since [timestamp]
   
✅ streamlit-monitor.service - Streamlit Health Monitor
   Loaded: loaded (/etc/systemd/system/streamlit-monitor.service; enabled; vendor preset: enabled)
   Active: active (running) since [timestamp]
```

**🎉 Your Streamlit application is now configured for automatic startup and will remain running continuously!**

---

## 📞 Support

If you encounter issues with auto-startup:

1. **Check logs**: All services log to `/var/www/vhosts/ai.erpabsolute.net/logs/`
2. **Test manually**: Use `./start_streamlit.sh` for manual control
3. **Verify services**: Use `systemctl status` to check service health
4. **Review configuration**: Ensure all files are properly uploaded and configured

**🚀 Your Solution.AI application will now run continuously with automatic startup and restart capabilities!**