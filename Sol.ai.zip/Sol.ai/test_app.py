import unittest
import os
import sys
from PIL import Image, ImageDraw
import tempfile

# Add the current directory to the path so we can import app
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class TestSolutionAI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Create a test image with some text
        cls.test_image = Image.new('RGB', (400, 200), color='white')
        d = ImageDraw.Draw(cls.test_image)
        d.text((10, 10), "This is a test image", fill='black')
        
        # Save the test image
        cls.test_image_path = os.path.join(tempfile.gettempdir(), 'test_image.png')
        cls.test_image.save(cls.test_image_path)
        
        # Set up test environment (no API keys needed)
        
    @classmethod
    def tearDownClass(cls):
        # Clean up test image
        if os.path.exists(cls.test_image_path):
            os.remove(cls.test_image_path)
    
    def test_extract_text_with_ocr(self):
        from app import extract_text_with_ocr
        
        # Test with a valid image
        result = extract_text_with_ocr(self.test_image_path)
        self.assertIsInstance(result, str)
        self.assertIn('test image', result.lower())
        
        # Test with non-existent file
        with self.assertRaises(Exception):
            extract_text_with_ocr('non_existent_file.png')
    
    def test_process_with_structured_analysis(self):
        from app import process_with_structured_analysis
        
        # Test with sample text
        result = process_with_structured_analysis("Sample text with email test@example.com")
        self.assertIsNotNone(result)
        self.assertIn("Comprehensive Information Analysis", result)
        
        # Test with empty text
        result = process_with_structured_analysis("")
        self.assertIsNone(result)
    
    def test_get_download_link(self):
        from app import get_download_link
        
        # Test with sample data
        link = get_download_link("test data", "test.txt", "Download Test")
        self.assertIn('href="data:file/txt;base64', link)
        self.assertIn('download="test.txt"', link)
        self.assertIn('>Download Test<', link)

if __name__ == '__main__':
    unittest.main()
