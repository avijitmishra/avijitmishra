#!/usr/bin/env python3
"""
Robust Passenger WSGI application for Plesk
This serves as a reliable Streamlit launcher with extensive error handling
"""

import sys
import os
import subprocess
import time
import threading
import traceback
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Add the application directory to Python path
app_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, app_dir)

# Environment setup
os.environ['STREAMLIT_SERVER_HEADLESS'] = 'true'
os.environ['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'

class StreamlitApp:
    def __init__(self):
        self.process = None
        self.is_starting = True
        self.start_time = time.time()
        self.max_startup_time = 120  # 2 minutes
        self.start_streamlit()
    
    def start_streamlit(self):
        """Start Streamlit process with error handling"""
        def run():
            try:
                # Change to app directory
                os.chdir(app_dir)
                logger.info(f"Starting Streamlit in directory: {app_dir}")
                
                # Find Python executable
                python_exe = sys.executable
                logger.info(f"Using Python: {python_exe}")
                
                # Start Streamlit
                cmd = [
                    python_exe, '-m', 'streamlit', 'run', 'app.py',
                    '--server.port=8501',
                    '--server.address=127.0.0.1',
                    '--server.headless=true',
                    '--browser.gatherUsageStats=false',
                    '--server.enableCORS=false',
                    '--server.enableXsrfProtection=false'
                ]
                
                logger.info(f"Starting command: {' '.join(cmd)}")
                
                self.process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=app_dir,
                    env=os.environ.copy()
                )
                
                logger.info(f"Streamlit process started with PID: {self.process.pid}")
                
                # Wait for startup
                time.sleep(5)
                self.is_starting = False
                logger.info("Streamlit startup phase completed")
                
            except Exception as e:
                logger.error(f"Error starting Streamlit: {e}")
                logger.error(traceback.format_exc())
                self.is_starting = False
        
        # Start in background thread
        thread = threading.Thread(target=run, daemon=True)
        thread.start()
    
    def is_running(self):
        """Check if Streamlit process is still running"""
        if self.process is None:
            return False
        return self.process.poll() is None
    
    def is_startup_timeout(self):
        """Check if startup has timed out"""
        return (time.time() - self.start_time) > self.max_startup_time

# Global Streamlit app instance
try:
    streamlit_app = StreamlitApp()
    logger.info("StreamlitApp instance created successfully")
except Exception as e:
    logger.error(f"Error creating StreamlitApp: {e}")
    streamlit_app = None

def create_html_response(title, content, refresh_seconds=None):
    """Create a standardized HTML response"""
    refresh_meta = f'<meta http-equiv="refresh" content="{refresh_seconds}">' if refresh_seconds else ''
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>{title}</title>
    {refresh_meta}
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            margin: 50px; 
            text-align: center; 
            background: #f0f2f6; 
        }}
        .container {{ 
            max-width: 600px; 
            margin: 0 auto; 
            padding: 40px; 
            background: white; 
            border-radius: 10px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
        }}
        .loading {{ 
            font-size: 18px; 
            margin: 20px 0; 
            color: #555; 
        }}
        .error {{ 
            color: #e74c3c; 
            margin: 20px 0; 
        }}
        .spinner {{ 
            border: 4px solid #f3f3f3; 
            border-top: 4px solid #ff6b6b; 
            border-radius: 50%; 
            width: 60px; 
            height: 60px; 
            animation: spin 1s linear infinite; 
            margin: 20px auto; 
        }}
        @keyframes spin {{ 
            0% {{ transform: rotate(0deg); }} 
            100% {{ transform: rotate(360deg); }} 
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Solution.AI</h1>
        {content}
    </div>
</body>
</html>"""
    return html.encode('utf-8')

def application(environ, start_response):
    """WSGI application function with comprehensive error handling"""
    
    try:
        # If no StreamlitApp instance, show error
        if streamlit_app is None:
            error_content = '''
                <div class="error">Application initialization failed</div>
                <p>The application could not start properly.</p>
                <p>Please check the server logs for more information.</p>
            '''
            response_body = create_html_response("Solution.AI - Error", error_content, 30)
            
            start_response('503 Service Unavailable', [
                ('Content-Type', 'text/html'),
                ('Content-Length', str(len(response_body)))
            ])
            return [response_body]
        
        # If Streamlit is still starting and not timed out
        if streamlit_app.is_starting and not streamlit_app.is_startup_timeout():
            loading_content = '''
                <div class="spinner"></div>
                <div class="loading">Starting image text extraction application...</div>
                <p>This may take up to 2 minutes for first startup.</p>
                <p>The page will refresh automatically.</p>
            '''
            response_body = create_html_response("Solution.AI - Starting...", loading_content, 10)
            
            start_response('200 OK', [
                ('Content-Type', 'text/html'),
                ('Content-Length', str(len(response_body)))
            ])
            return [response_body]
        
        # If startup timed out
        if streamlit_app.is_startup_timeout():
            timeout_content = '''
                <div class="error">Startup timeout occurred</div>
                <p>The application is taking longer than expected to start.</p>
                <p>This may be due to server resource constraints.</p>
                <p>Please try again in a few minutes.</p>
            '''
            response_body = create_html_response("Solution.AI - Timeout", timeout_content, 60)
            
            start_response('503 Service Unavailable', [
                ('Content-Type', 'text/html'),
                ('Content-Length', str(len(response_body)))
            ])
            return [response_body]
        
        # Check if Streamlit process is running
        if streamlit_app.is_running():
            # Try to proxy to Streamlit
            try:
                import urllib.request
                import urllib.error
                
                # Build URL for Streamlit
                path_info = environ.get('PATH_INFO', '/')
                query_string = environ.get('QUERY_STRING', '')
                
                url = f"http://127.0.0.1:8501{path_info}"
                if query_string:
                    url += f"?{query_string}"
                
                # Create request
                req = urllib.request.Request(url)
                
                # Copy important headers
                for key, value in environ.items():
                    if key.startswith('HTTP_'):
                        header_name = key[5:].replace('_', '-')
                        if header_name.lower() not in ['host', 'connection']:
                            req.add_header(header_name, value)
                
                # Make request to Streamlit
                try:
                    response = urllib.request.urlopen(req, timeout=30)
                    
                    # Get response data
                    content = response.read()
                    
                    # Prepare headers
                    headers = []
                    for header, value in response.headers.items():
                        if header.lower() not in ['server', 'date']:
                            headers.append((header, value))
                    
                    start_response(f"{response.getcode()} {response.reason}", headers)
                    return [content]
                    
                except urllib.error.URLError as e:
                    logger.error(f"Streamlit connection error: {e}")
                    raise Exception("Streamlit not responding")
                    
            except Exception as e:
                logger.error(f"Proxy error: {e}")
                # Return connection error page
                error_content = f'''
                    <div class="error">Connection error occurred</div>
                    <p>The application is running but not responding properly.</p>
                    <p>Attempting to restart the service...</p>
                    <p><small>Error: {str(e)}</small></p>
                '''
                response_body = create_html_response("Solution.AI - Connection Error", error_content, 15)
                
                start_response('503 Service Unavailable', [
                    ('Content-Type', 'text/html'),
                    ('Content-Length', str(len(response_body)))
                ])
                return [response_body]
        
        else:
            # Streamlit process died, restart it
            logger.info("Streamlit process not running, restarting...")
            streamlit_app.is_starting = True
            streamlit_app.start_time = time.time()
            streamlit_app.start_streamlit()
            
            restart_content = '''
                <div class="spinner"></div>
                <div class="loading">Application is restarting...</div>
                <p>Please wait while the service recovers.</p>
                <p>This page will refresh automatically.</p>
            '''
            response_body = create_html_response("Solution.AI - Restarting", restart_content, 15)
            
            start_response('503 Service Unavailable', [
                ('Content-Type', 'text/html'),
                ('Content-Length', str(len(response_body)))
            ])
            return [response_body]
            
    except Exception as e:
        # Catch-all error handler
        logger.error(f"WSGI application error: {e}")
        logger.error(traceback.format_exc())
        
        error_content = f'''
            <div class="error">Unexpected error occurred</div>
            <p>An unexpected error has occurred in the application.</p>
            <p>Please try again in a few moments.</p>
            <p><small>Error: {str(e)}</small></p>
        '''
        response_body = create_html_response("Solution.AI - Error", error_content, 30)
        
        start_response('500 Internal Server Error', [
            ('Content-Type', 'text/html'),
            ('Content-Length', str(len(response_body)))
        ])
        return [response_body]

# Health check endpoint
def health_check():
    """Simple health check for debugging"""
    if streamlit_app and streamlit_app.is_running():
        return "Healthy: Streamlit running"
    elif streamlit_app and streamlit_app.is_starting:
        return "Starting: Streamlit initializing"
    else:
        return "Unhealthy: Streamlit not running"

# Initialize logging
logger.info("passenger_wsgi.py loaded successfully")
logger.info(f"Working directory: {app_dir}")
logger.info(f"Python executable: {sys.executable}")
logger.info(f"Python path: {sys.path[:3]}...")  # Show first 3 entries