import sys
import os
from app import app as application

# Add the project directory to the Python path
sys.path.insert(0, os.path.dirname(__file__))

# Set production environment
os.environ['FLASK_ENV'] = 'production'
os.environ['FLASK_DEBUG'] = '0'

# Disable Werkzeug's development server banner
import werkzeug.serving
import werkzeug._internal
werkzeug.serving.WSGIRequestHandler.log = lambda *args, **kwargs: None
werkzeug._internal._log = lambda *args, **kwargs: None

# If you're using a virtual environment, add its site-packages
site_packages = os.path.join(os.path.dirname(__file__), 'venv/lib/python3.9/site-packages')
if os.path.exists(site_packages):
    sys.path.append(site_packages)

# Set the secret key for session management
application.secret_key = os.getenv('SECRET_KEY', 'your-secret-key-here')

# Configure logging
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    filename=os.path.join(os.path.dirname(__file__), 'app.log')
)
