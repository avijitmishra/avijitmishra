# PowerShell script to fix Plesk deployment
Write-Host "🔧 Plesk Fix for Solution.AI - PowerShell Version" -ForegroundColor Green
Write-Host ""

# Get current directory
$CurrentDir = Get-Location
Write-Host "📍 Working directory: $CurrentDir" -ForegroundColor Cyan

# Backup existing passenger_wsgi.py if it exists
if (Test-Path "passenger_wsgi.py") {
    Write-Host "💾 Backing up existing passenger_wsgi.py..." -ForegroundColor Yellow
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    Copy-Item "passenger_wsgi.py" "passenger_wsgi.py.backup.$timestamp"
    Write-Host "✅ Backup created: passenger_wsgi.py.backup.$timestamp" -ForegroundColor Green
}

# Check if the file already has Streamlit launcher content
$content = Get-Content "passenger_wsgi.py" -Raw -ErrorAction SilentlyContinue
if ($content -match "StreamlitApp") {
    Write-Host "✅ passenger_wsgi.py already contains Streamlit launcher" -ForegroundColor Green
    Write-Host "🔄 Triggering application restart..." -ForegroundColor Yellow
    
    # Touch the file to trigger restart
    (Get-Item "passenger_wsgi.py").LastWriteTime = Get-Date
    Write-Host "✅ Application restart triggered" -ForegroundColor Green
}
else {
    Write-Host "❌ passenger_wsgi.py needs updating" -ForegroundColor Red
    Write-Host "Please upload the correct passenger_wsgi_streamlit.py file" -ForegroundColor Yellow
    Read-Host "Press Enter to continue"
    exit 1
}

# Kill any existing Python processes related to the app
Write-Host "🔄 Stopping existing processes..." -ForegroundColor Yellow
try {
    Get-Process | Where-Object { $_.ProcessName -eq "python" -and $_.CommandLine -like "*streamlit*" } | Stop-Process -Force -ErrorAction SilentlyContinue
    Get-Process | Where-Object { $_.ProcessName -eq "python" -and $_.CommandLine -like "*passenger_wsgi*" } | Stop-Process -Force -ErrorAction SilentlyContinue
    Write-Host "✅ Existing processes stopped" -ForegroundColor Green
}
catch {
    Write-Host "ℹ️ No existing processes found to stop" -ForegroundColor Gray
}

Write-Host ""
Write-Host "🎉 Fix completed!" -ForegroundColor Green
Write-Host ""
Write-Host "📋 What was done:" -ForegroundColor Cyan
Write-Host "   ✅ Backed up existing passenger_wsgi.py" -ForegroundColor Green
Write-Host "   ✅ Verified Streamlit launcher is in place" -ForegroundColor Green
Write-Host "   ✅ Triggered application restart" -ForegroundColor Green
Write-Host "   ✅ Stopped existing processes" -ForegroundColor Green
Write-Host ""
Write-Host "🌐 Your Streamlit app should now be accessible at:" -ForegroundColor Cyan
Write-Host "   https://ai.erpabsolute.net" -ForegroundColor White
Write-Host ""
Write-Host "⏰ Note: It may take 30-60 seconds for Streamlit to fully start" -ForegroundColor Yellow
Write-Host "📝 Check the application in your browser in a few moments" -ForegroundColor Yellow
Write-Host ""
Write-Host "✨ Fix completed successfully!" -ForegroundColor Green

# Wait for user input
Read-Host "Press Enter to continue"