#!/bin/bash
# Enhanced Plesk Deployment Script for Solution.AI with Streamlit Auto-Startup
# This script deploys and configures automatic Streamlit startup

set -e

# Configuration
SERVER_HOST="ai.erpabsolute.net"
SERVER_IP="156.67.110.254"
SERVER_PORT="15987"
SERVER_USER="ai.erpabsolute.net"
REMOTE_PATH="/var/www/vhosts/ai.erpabsolute.net/httpdocs"
VENV_PATH="/var/www/vhosts/ai.erpabsolute.net/venv"
LOG_PATH="/var/www/vhosts/ai.erpabsolute.net/logs"

echo "🚀 Starting Enhanced Plesk Deployment with Streamlit Auto-Startup..."

# Step 1: Upload files
echo "Step 1: Uploading application files..."
scp -P $SERVER_PORT -r \
    app.py \
    requirements.txt \
    passenger_wsgi.py \
    start_streamlit.sh \
    streamlit_monitor.sh \
    solution-ai-streamlit.service \
    .env.plesk \
    app/ \
    $SERVER_USER@$SERVER_IP:$REMOTE_PATH/

echo "Files uploaded successfully."

# Step 2: Setup server environment
echo "Step 2: Configuring server environment..."
ssh -p $SERVER_PORT $SERVER_USER@$SERVER_IP << 'ENDSSH'
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs

# Create necessary directories
mkdir -p logs
mkdir -p temp

# Set permissions
chown -R psacln:psaserv .
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;

# Make scripts executable
chmod +x start_streamlit.sh
chmod +x streamlit_monitor.sh

# Setup environment file
if [ -f .env.plesk ]; then
    cp .env.plesk .env
    chmod 600 .env
fi

echo "✅ Server environment configured"
ENDSSH

# Step 3: Setup Python virtual environment
echo "Step 3: Setting up Python virtual environment..."
ssh -p $SERVER_PORT $SERVER_USER@$SERVER_IP << 'ENDSSH'
cd /var/www/vhosts/ai.erpabsolute.net

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi

# Activate virtual environment and install dependencies
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install application dependencies
cd httpdocs
pip install -r requirements.txt

# Install system dependencies
sudo apt-get update
sudo apt-get install -y tesseract-ocr curl

echo "✅ Dependencies installed"
ENDSSH

# Step 4: Setup systemd service
echo "Step 4: Setting up Streamlit systemd service..."
ssh -p $SERVER_PORT $SERVER_USER@$SERVER_IP << 'ENDSSH'
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs

# Copy service file to systemd
sudo cp solution-ai-streamlit.service /etc/systemd/system/

# Reload systemd
sudo systemctl daemon-reload

# Enable service to start on boot
sudo systemctl enable solution-ai-streamlit

echo "✅ Systemd service configured"
ENDSSH

# Step 5: Setup health monitoring
echo "Step 5: Setting up health monitoring..."
ssh -p $SERVER_PORT $SERVER_USER@$SERVER_IP << 'ENDSSH'
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs

# Create monitoring service
cat << 'EOF' | sudo tee /etc/systemd/system/streamlit-monitor.service
[Unit]
Description=Streamlit Health Monitor for Solution.AI
After=solution-ai-streamlit.service
Wants=solution-ai-streamlit.service

[Service]
Type=simple
User=psacln
Group=psaserv
WorkingDirectory=/var/www/vhosts/ai.erpabsolute.net/httpdocs
ExecStart=/var/www/vhosts/ai.erpabsolute.net/httpdocs/streamlit_monitor.sh
Restart=always
RestartSec=30

[Install]
WantedBy=multi-user.target
EOF

# Enable monitoring service
sudo systemctl daemon-reload
sudo systemctl enable streamlit-monitor

echo "✅ Health monitoring configured"
ENDSSH

# Step 6: Setup Nginx reverse proxy
echo "Step 6: Configuring Nginx reverse proxy..."
ssh -p $SERVER_PORT $SERVER_USER@$SERVER_IP << 'ENDSSH'
# Create Nginx configuration for Streamlit
cat << 'EOF' | sudo tee /etc/nginx/sites-available/streamlit-ai
server {
    listen 80;
    server_name ai.erpabsolute.net;

    location / {
        proxy_pass http://127.0.0.1:8501;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Query $query_string;
        
        # WebSocket support
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
        proxy_send_timeout 86400;
        
        # Handle large uploads
        client_max_body_size 50M;
    }
}
EOF

# Enable the site
sudo ln -sf /etc/nginx/sites-available/streamlit-ai /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

echo "✅ Nginx reverse proxy configured"
ENDSSH

# Step 7: Start services
echo "Step 7: Starting Streamlit services..."
ssh -p $SERVER_PORT $SERVER_USER@$SERVER_IP << 'ENDSSH'
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs

# Start Streamlit service
sudo systemctl start solution-ai-streamlit

# Wait a moment for startup
sleep 10

# Start monitoring service
sudo systemctl start streamlit-monitor

# Check service status
echo "=== Service Status ==="
sudo systemctl status solution-ai-streamlit --no-pager
echo ""
sudo systemctl status streamlit-monitor --no-pager

echo "✅ Services started"
ENDSSH

# Step 8: Test deployment
echo "Step 8: Testing deployment..."
echo "Testing application accessibility..."

# Test local connection
ssh -p $SERVER_PORT $SERVER_USER@$SERVER_IP << 'ENDSSH'
# Test if Streamlit is responding locally
if curl -s --max-time 10 http://localhost:8501 > /dev/null; then
    echo "✅ Streamlit is responding locally"
else
    echo "❌ Streamlit local test failed"
fi
ENDSSH

# Test external connection
if curl -s --max-time 10 "http://$SERVER_HOST/" > /dev/null; then
    echo "✅ External access working"
else
    echo "⚠️  External access may need additional configuration"
fi

echo ""
echo "🎉 Enhanced Deployment Complete!"
echo ""
echo "=== Service Information ==="
echo "🌐 Application URL: http://$SERVER_HOST/"
echo "🔧 Service Management:"
echo "   Start:   sudo systemctl start solution-ai-streamlit"
echo "   Stop:    sudo systemctl stop solution-ai-streamlit"
echo "   Restart: sudo systemctl restart solution-ai-streamlit"
echo "   Status:  sudo systemctl status solution-ai-streamlit"
echo ""
echo "📊 Monitoring:"
echo "   Monitor Service: sudo systemctl status streamlit-monitor"
echo "   Health Logs:     tail -f /var/www/vhosts/ai.erpabsolute.net/logs/health.log"
echo "   App Logs:        tail -f /var/www/vhosts/ai.erpabsolute.net/logs/streamlit.log"
echo ""
echo "🔄 Manual Control:"
echo "   Start Script:    ./start_streamlit.sh start"
echo "   Stop Script:     ./start_streamlit.sh stop"
echo "   Status Check:    ./start_streamlit.sh status"
echo ""
echo "=== Auto-Startup Features ==="
echo "✅ Systemd service enabled (starts on boot)"
echo "✅ Health monitoring active (auto-restart on failure)"
echo "✅ Nginx reverse proxy configured"
echo "✅ Process management scripts installed"
echo ""
echo "🎯 Your Streamlit application will now:"
echo "   • Start automatically when server boots"
echo "   • Restart automatically if it crashes"
echo "   • Be monitored continuously for health"
echo "   • Log all activities for debugging"

echo ""
echo "📋 Next Steps:"
echo "1. Test the application: http://$SERVER_HOST/"
echo "2. Monitor logs: ssh -p $SERVER_PORT $SERVER_USER@$SERVER_IP 'tail -f /var/www/vhosts/ai.erpabsolute.net/logs/streamlit.log'"
echo "3. Check service status: ssh -p $SERVER_PORT $SERVER_USER@$SERVER_IP 'sudo systemctl status solution-ai-streamlit'"
echo ""
echo "🎉 Deployment with auto-startup complete!"