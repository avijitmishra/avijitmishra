# Plesk Server Deployment Guide
# Solution.AI - Image Text Extraction Application

## Server Details
- **Domain**: ai.erpabsolute.net
- **Server IP**: 156.67.110.254

## UPDATED: Always-Running Server Configuration

### Current Status
- ✅ OpenAI dependency removed (no more import errors)
- ✅ "Extracted Information" section removed (as requested)
- ✅ Server configured for continuous operation on Plesk

### Production Files Ready for Upload
- **Application Port**: 15987
- **Plesk Panel**: http://156.67.110.254:8880/

## Pre-Deployment Setup

### 1. Plesk Python Environment
1. Access Plesk Panel at http://156.67.110.254:8880/
2. Navigate to "Websites & Domains" > "Python"
3. Create a new Python application:
   - **Application Type**: Python 3.9+ (or latest available)
   - **Application Root**: `/httpdocs`
   - **Application URL**: `/` (root domain)
   - **Application Startup File**: `plesk_deployment.py`

### 2. Environment Variables
Set these in Plesk Python app settings:
```
OPENAI_API_KEY=your_openai_api_key_here
SECRET_KEY=your_production_secret_key_here
FLASK_ENV=production
FLASK_DEBUG=0
PORT=15987
TESSERACT_CMD=/usr/bin/tesseract
```

### 3. Install System Dependencies
SSH into server and install Tesseract OCR:
```bash
# For Ubuntu/Debian
sudo apt update
sudo apt install tesseract-ocr tesseract-ocr-eng

# For CentOS/RHEL
sudo yum install tesseract tesseract-langpack-eng

# Verify installation
tesseract --version
```

## Deployment Steps

### 1. Upload Files
Upload these files to the domain's `httpdocs` directory:
```
httpdocs/
├── plesk_deployment.py          # Main WSGI entry point
├── app/
│   ├── __init__.py
│   ├── routes.py
│   └── templates/
│       ├── base.html
│       └── index.html
├── requirements-plesk.txt       # Python dependencies
├── .env                        # Environment variables
└── logs/                       # Create empty logs directory
```

### 2. Install Python Dependencies
In Plesk Python app settings:
1. Go to "Package Management"
2. Upload `requirements-plesk.txt`
3. Click "Install Dependencies"

Or via SSH:
```bash
cd /var/www/vhosts/ai.erpabsolute.net/httpdocs
pip install -r requirements-plesk.txt
```

### 3. Configure Web Server
In Plesk, set:
- **Document Root**: `/httpdocs`
- **Application Startup File**: `plesk_deployment.py`
- **Enable Application**: Yes
- **Passenger Ruby**: No
- **Passenger Python**: Yes

### 4. File Permissions
Set proper permissions:
```bash
chmod 755 /var/www/vhosts/ai.erpabsolute.net/httpdocs
chmod -R 644 /var/www/vhosts/ai.erpabsolute.net/httpdocs/*
chmod 755 /var/www/vhosts/ai.erpabsolute.net/httpdocs/plesk_deployment.py
mkdir -p /var/www/vhosts/ai.erpabsolute.net/httpdocs/logs
chmod 755 /var/www/vhosts/ai.erpabsolute.net/httpdocs/logs
```

## URL Structure with Query Parameters

### Base URLs
- **Production**: https://ai.erpabsolute.net/
- **With Query Parameters**: https://ai.erpabsolute.net/?regid=REG123&uid=USER456

### Query Parameter Support
The application supports these query parameters:
- `regid`: Registration ID for tracking
- `uid`: User ID for session management

Example URLs:
```
https://ai.erpabsolute.net/
https://ai.erpabsolute.net/?regid=12345
https://ai.erpabsolute.net/?uid=user_001
https://ai.erpabsolute.net/?regid=12345&uid=user_001
```

## Testing Deployment

### 1. Test Application Loading
```bash
curl -I https://ai.erpabsolute.net/
```

### 2. Test Query Parameters
```bash
curl "https://ai.erpabsolute.net/?regid=test&uid=testuser"
```

### 3. Test Image Upload
Use the web interface to upload a test image and verify:
- OCR text extraction works
- Session tracking with query parameters
- File download functionality

## Monitoring & Logs

### Application Logs
- Location: `/var/www/vhosts/ai.erpabsolute.net/httpdocs/logs/solutionai.log`
- Rotation: 10MB max, 5 backup files
- View logs: `tail -f logs/solutionai.log`

### Error Logs
- Plesk Error Logs: Websites & Domains > Logs
- Python Application Logs: Available in Plesk panel

## Security Considerations

### 1. HTTPS Configuration
- Enable SSL certificate in Plesk
- Force HTTPS redirects
- Update cookie settings for secure connections

### 2. File Upload Security
- Validate file types and sizes
- Implement rate limiting
- Regular security updates

### 3. API Key Security
- Store OpenAI API key in environment variables
- Regular key rotation
- Monitor API usage

## Troubleshooting

### Common Issues
1. **Tesseract not found**: Verify installation and path in environment variables
2. **OpenAI API errors**: Check API key and billing status
3. **File permissions**: Ensure proper chmod settings
4. **Python dependencies**: Verify all packages installed correctly

### Debug Mode
For debugging (temporarily), set in `.env`:
```
FLASK_DEBUG=1
FLASK_ENV=development
```
**Important**: Always disable debug mode in production!

## Support
- Application logs: `logs/solutionai.log`
- Server logs: Plesk Panel > Logs
- Contact: Technical support for ai.erpabsolute.net