#!/bin/bash
# Solution.AI Streamlit Startup Script
# This script ensures Streamlit starts properly with all dependencies

# Script location: /var/www/vhosts/ai.erpabsolute.net/httpdocs/start_streamlit.sh

set -e

# Configuration
APP_DIR="/var/www/vhosts/ai.erpabsolute.net/httpdocs"
VENV_DIR="/var/www/vhosts/ai.erpabsolute.net/venv"
LOG_DIR="/var/www/vhosts/ai.erpabsolute.net/logs"
PID_FILE="/var/www/vhosts/ai.erpabsolute.net/streamlit.pid"

# Create logs directory if it doesn't exist
mkdir -p "$LOG_DIR"

# Function to log messages
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_DIR/startup.log"
}

# Function to check if Streamlit is running
is_streamlit_running() {
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE")
        if ps -p "$pid" > /dev/null 2>&1; then
            return 0
        else
            rm -f "$PID_FILE"
            return 1
        fi
    fi
    return 1
}

# Function to stop existing Streamlit
stop_streamlit() {
    if is_streamlit_running; then
        local pid=$(cat "$PID_FILE")
        log_message "Stopping existing Streamlit process (PID: $pid)"
        kill -TERM "$pid" 2>/dev/null || true
        sleep 5
        if ps -p "$pid" > /dev/null 2>&1; then
            kill -KILL "$pid" 2>/dev/null || true
        fi
        rm -f "$PID_FILE"
    fi
    
    # Kill any remaining streamlit processes
    pkill -f "streamlit run app.py" 2>/dev/null || true
    sleep 2
}

# Function to start Streamlit
start_streamlit() {
    log_message "Starting Solution.AI Streamlit application..."
    
    # Change to application directory
    cd "$APP_DIR"
    
    # Activate virtual environment
    source "$VENV_DIR/bin/activate"
    
    # Check if required files exist
    if [ ! -f "app.py" ]; then
        log_message "ERROR: app.py not found in $APP_DIR"
        exit 1
    fi
    
    # Check if Tesseract is installed
    if ! command -v tesseract &> /dev/null; then
        log_message "WARNING: Tesseract OCR not found. Installing..."
        sudo apt-get update && sudo apt-get install -y tesseract-ocr
    fi
    
    # Set environment variables
    export STREAMLIT_SERVER_PORT=8501
    export STREAMLIT_SERVER_ADDRESS=0.0.0.0
    export STREAMLIT_SERVER_HEADLESS=true
    export STREAMLIT_BROWSER_GATHER_USAGE_STATS=false
    export PYTHONPATH="$APP_DIR"
    
    # Start Streamlit in background
    nohup streamlit run app.py \
        --server.port=8501 \
        --server.address=0.0.0.0 \
        --server.headless=true \
        --browser.gatherUsageStats=false \
        > "$LOG_DIR/streamlit.log" 2>&1 &
    
    # Save PID
    echo $! > "$PID_FILE"
    
    log_message "Streamlit started with PID: $(cat $PID_FILE)"
    
    # Wait a moment and check if it's still running
    sleep 5
    if is_streamlit_running; then
        log_message "✅ Streamlit is running successfully on http://localhost:8501"
        return 0
    else
        log_message "❌ Failed to start Streamlit"
        return 1
    fi
}

# Function to restart Streamlit
restart_streamlit() {
    log_message "Restarting Streamlit application..."
    stop_streamlit
    sleep 3
    start_streamlit
}

# Function to check status
status_streamlit() {
    if is_streamlit_running; then
        local pid=$(cat "$PID_FILE")
        echo "✅ Streamlit is running (PID: $pid)"
        echo "🌐 Access URL: http://ai.erpabsolute.net:8501"
        return 0
    else
        echo "❌ Streamlit is not running"
        return 1
    fi
}

# Main script logic
case "${1:-start}" in
    start)
        if is_streamlit_running; then
            log_message "Streamlit is already running"
            status_streamlit
        else
            start_streamlit
        fi
        ;;
    stop)
        stop_streamlit
        log_message "Streamlit stopped"
        ;;
    restart)
        restart_streamlit
        ;;
    status)
        status_streamlit
        ;;
    force-restart)
        log_message "Force restarting Streamlit..."
        pkill -9 -f "streamlit" 2>/dev/null || true
        rm -f "$PID_FILE"
        sleep 3
        start_streamlit
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|force-restart}"
        echo ""
        echo "Commands:"
        echo "  start         - Start Streamlit if not running"
        echo "  stop          - Stop Streamlit"
        echo "  restart       - Restart Streamlit"
        echo "  status        - Check if Streamlit is running"
        echo "  force-restart - Force kill and restart"
        exit 1
        ;;
esac

exit $?