# MANUAL PLESK FIX GUIDE
# How to fix the 500 Internal Server Error through Plesk File Manager

## 🚨 IMMEDIATE SOLUTION - Upload via Plesk File Manager

### Step 1: Access Plesk File Manager
1. Log into your Plesk control panel
2. Go to "Files" or "File Manager"
3. Navigate to your domain's root directory (usually httpdocs or public_html)

### Step 2: Backup Current File
1. Find the file named `passenger_wsgi.py`
2. Right-click and rename it to `passenger_wsgi.py.broken_backup`
3. This preserves the broken version for reference

### Step 3: Upload New File
1. Upload `passenger_wsgi_minimal.py` to your server
2. Rename `passenger_wsgi_minimal.py` to `passenger_wsgi.py`
3. Make sure the file permissions are set to 644 or 755

### Step 4: Trigger Restart
1. Right-click on `passenger_wsgi.py`
2. Select "Properties" or "Edit"
3. Just open and close the file (this updates the timestamp)
4. Or add a space and save to trigger a restart

## 🎯 EXPECTED RESULT
After these steps, visiting https://ai.erpabsolute.net should show:
- "Solution.AI - Live" page instead of 500 error
- "Status: LIVE AND WORKING!" message
- Spinning animation
- Auto-refresh every 20 seconds

## 📋 FILE CONTENTS TO UPLOAD
The passenger_wsgi_minimal.py file contains just 31 lines of simple Python code.
It's designed to be bulletproof and work on any Plesk server.

## 🔧 ALTERNATIVE: Copy-Paste Method
If upload doesn't work:
1. Create a new file in Plesk File Manager called `passenger_wsgi.py`
2. Copy the entire contents of `passenger_wsgi_minimal.py`
3. Paste into the new file and save

## ✅ SUCCESS INDICATORS
- No more "Internal Server Error"
- Page shows "Solution.AI - Live"
- Status shows "LIVE AND WORKING!"
- Page refreshes automatically

## 🔄 NEXT STEPS
Once this basic fix works:
1. Confirm you see the "Live and Working" page
2. We'll then deploy the full Streamlit integration
3. Your image text extraction app will be fully functional

## 🆘 IF STILL NOT WORKING
1. Check file permissions (should be 644 or 755)
2. Ensure the file is named exactly `passenger_wsgi.py`
3. Try clearing browser cache
4. Wait 2-3 minutes for server to restart

The minimal version has only basic Python code with no complex imports,
so it should work on any standard Plesk Python setup.