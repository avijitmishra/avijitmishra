with open('app.py', 'r', encoding='utf-8', errors='ignore') as f:
    content = f.read()

# Remove any lines with openai imports
lines = content.split('\n')
filtered_lines = [line for line in lines if 'import openai' not in line and 'from openai' not in line]

with open('app_clean.py', 'w', encoding='utf-8') as f:
    f.write('\n'.join(filtered_lines))

print('Created cleaned app_clean.py')