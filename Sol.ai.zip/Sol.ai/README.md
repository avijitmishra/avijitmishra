# 🚀 Solution.AI - Advanced Image Text Extraction System

A powerful, self-contained application that extracts and analyzes text from images using advanced OCR and pattern recognition technology. **100% OpenAI-free** with local processing for privacy and reliability.

![Solution.AI Interface](screenshot.png)

## ✨ Features

- **🔍 Advanced OCR** - Extract text from any image using Tesseract OCR
- **📊 Pattern Recognition** - Automatic email, phone, date, and currency detection
- **📥 Multiple Exports** - Download results in Text, Excel, and Word formats
- **🔒 Privacy-First** - 100% local processing, no external APIs
- **⚡ High Performance** - Instant results with no API delays
- **🌐 Web Interface** - Clean, responsive Streamlit UI
- **💸 Cost-Free** - No subscription or usage fees
- **🔧 Production-Ready** - Optimized for Plesk server deployment

## 🚀 Quick Start

### **Local Development**

1. **Clone and Setup**
   ```bash
   git clone <repository-url>
   cd Solution.AI
   python -m venv venv
   .\venv\Scripts\activate  # Windows
   # OR
   source venv/bin/activate  # Linux/Mac
   ```

2. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Install Tesseract OCR**
   - **Windows**: Download from https://github.com/UB-Mannheim/tesseract/wiki
   - **macOS**: `brew install tesseract`
   - **Linux**: `sudo apt install tesseract-ocr`

4. **Run Application**
   ```bash
   # Streamlit (recommended)
   streamlit run app.py
   
   # Flask API (optional)
   python wsgi.py
   ```
   
   **Access**: 
   - Streamlit: http://localhost:8501
   - Flask API: http://localhost:5000

### **Query Parameters**
Track users with these optional parameters:
- `regid`: Registration ID  
- `uid`: User ID

**Example**: `http://localhost:8501/?regid=12345&uid=67890`

## 🏗️ Plesk Production Deployment

### Prerequisites
- Plesk server with Python support
- SSH access to the server
- Domain configured in Plesk (ai.erpabsolute.net)

### 1. Server Setup

```bash
# Connect to your server via SSH
ssh user@156.67.110.254

# Navigate to Plesk domain directory
cd /var/www/vhosts/ai.erpabsolute.net/

# Create and activate virtual environment
python -m venv venv
source venv/bin/activate

# Install system dependencies
sudo apt-get update
sudo apt-get install -y tesseract-ocr

# Install Python dependencies
pip install -r httpdocs/requirements.txt gunicorn
```

### 2. Configure Application

1. Upload your project files to `/var/www/vhosts/ai.erpabsolute.net/httpdocs/`
2. Set up `.env` file with production settings:
   ```ini
   FLASK_APP=wsgi:application
   FLASK_ENV=production
   SECRET_KEY=your-secure-key-here
   TESSERACT_CMD=/usr/bin/tesseract
   SERVER_NAME=ai.erpabsolute.net
   PREFERRED_URL_SCHEME=https
   ```

### 3. Set Up Systemd Service

```bash
# Copy service file
sudo cp httpdocs/solution-ai.service /etc/systemd/system/

# Reload systemd and enable service
sudo systemctl daemon-reload
sudo systemctl enable solution-ai
sudo systemctl start solution-ai
```

### 4. Configure Plesk

1. Go to Plesk > Websites & Domains > ai.erpabsolute.net > Hosting Settings
2. Set Document Root to `/httpdocs`
3. Enable "Additional directives for HTTP" and add:
   ```nginx
   location / {
       proxy_pass http://127.0.0.1:5000;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
   }
   ```

## 🔍 Using the Application

### Accessing the Application
- Production URL: https://ai.erpabsolute.net
- Development URL: http://localhost:5000

### Query Parameters
Track users with these optional parameters:
- `regid`: Registration ID
- `uid`: User ID

Example:
```
https://ai.erpabsolute.net/?regid=12345&uid=67890
```

## 🛠️ Troubleshooting

### View Logs
```bash
# Check service status
sudo systemctl status solution-ai

# View logs in real-time
sudo journalctl -u solution-ai -f

# Check Nginx error logs
sudo tail -f /var/log/nginx/error.log
```

### Common Issues

1. **Tesseract Not Found**
   ```bash
   # Verify installation
   which tesseract
   
   # Update path in .env if needed
   TESSERACT_CMD=/usr/bin/tesseract
   ```

2. **Permission Issues**
   ```bash
   # Set correct ownership
   sudo chown -R psacln:psaserv /var/www/vhosts/ai.erpabsolute.net
   
   # Set directory permissions
   find /var/www/vhosts/ai.erpabsolute.net -type d -exec chmod 755 {} \;
   find /var/www/vhosts/ai.erpabsolute.net -type f -exec chmod 644 {} \;
   ```

3. **Service Fails to Start**
   - Check virtual environment activation in service file
   - Verify Python path in `solution-ai.service`
   - Ensure `.env` file exists and is readable

## 🔄 Maintenance

### Updating the Application
1. Upload new files
2. Restart the service:
   ```bash
   sudo systemctl restart solution-ai
   ```

### Monitoring
- Check resource usage: `htop`
- Monitor disk space: `df -h`
- Check Python processes: `ps aux | grep python`

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📞 Support

For technical support, please contact your system administrator or open an issue in the repository.
