import os
import streamlit as st
import pytesseract
from PIL import Image
import openai
from dotenv import load_dotenv
import tempfile
import base64
import urllib.parse

# Load environment variables
load_dotenv()

# Configure Tesseract path
try:
    # Try default Windows installation path
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    # Test if Tesseract is accessible
    pytesseract.get_tesseract_version()
except (pytesseract.TesseractNotFoundError, FileNotFoundError):
    try:
        # Try alternative path
        pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe'
        pytesseract.get_tesseract_version()
    except (pytesseract.TesseractNotFoundError, FileNotFoundError):
        # If Tesseract is in PATH, this will work
        pytesseract.pytesseract.tesseract_cmd = 'tesseract'

# Set OpenAI API key
openai.api_key = os.getenv('OPENAI_API_KEY')

def extract_text_with_ocr(image_path):
    """Extract text from image using Tesseract OCR"""
    try:
        # Check if Tesseract is installed
        try:
            pytesseract.get_tesseract_version()
        except pytesseract.TesseractNotFoundError:
            return "Error: Tesseract is not installed. Please install it from https://github.com/UB-Mannheim/tesseract/wiki"
            
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img)
        
        if not text.strip():
            return "No text could be extracted from the image. Please try with a clearer image."
            
        return text
    except Exception as e:
        return f"Error in OCR processing: {str(e)}. Make sure Tesseract is installed and in your system PATH."

def process_with_gpt(text):
    """Process extracted text with GPT to organize information"""
    try:
        from openai import OpenAI
        client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
        
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system", 
                    "content": "You are a helpful assistant that organizes extracted text from images into a structured format. Extract key information and present it in an organized manner."
                },
                {
                    "role": "user", 
                    "content": f"Please organize the following text extracted from an image into a structured format. Include all important information:\n\n{text}"
                }
            ]
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"Error in GPT processing: {str(e)}"

def get_download_link(data, filename, text):
    """Generate a download link for the results"""
    b64 = base64.b64encode(data.encode()).decode()
    return f'<a href="data:file/txt;base64,{b64}" download="{filename}">{text}</a>'

def get_query_params():
    """Extract query parameters from the URL"""
    query_params = {}
    try:
        # Use the newer st.context.headers instead of deprecated _get_websocket_headers
        if hasattr(st, 'context') and hasattr(st.context, 'headers'):
            headers = st.context.headers
            if headers and 'X-Forwarded-Query' in headers:
                query_string = headers['X-Forwarded-Query']
                query_params = dict(urllib.parse.parse_qsl(query_string))
    except Exception:
        # Fallback: try to get from URL parameters if available
        pass
    return query_params

def main():
    st.set_page_config(
        page_title="Solution.AI - Image Information Extractor",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Get query parameters
    query_params = get_query_params()
    regid = query_params.get('regid', '')
    uid = query_params.get('uid', '')
    
    # Store in session state
    if 'regid' not in st.session_state:
        st.session_state.regid = regid
    if 'uid' not in st.session_state:
        st.session_state.uid = uid
    
    st.title("🖼️ Solution.AI - Image Information Extractor")
    st.write(f"Session ID: {uid}" if uid else "")
    st.write("Upload an image to extract and organize information using AI")
    
    uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png", "bmp", "tiff"])
    
    if uploaded_file is not None:
        # Display the uploaded image
        image = Image.open(uploaded_file)
        col1, col2 = st.columns(2)
        
        with col1:
            st.image(image, caption='Uploaded Image', use_container_width=True)
        
        with col2:
            with st.spinner('Processing image...'):
                # Save uploaded file to a temporary file
                with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file:
                    image.save(tmp_file.name)
                    
                    # Extract text using OCR
                    extracted_text = extract_text_with_ocr(tmp_file.name)
                    
                    # Process with GPT for better organization
                    if extracted_text.strip():
                        processed_text = process_with_gpt(extracted_text)
                        
                        # Display results with session info
                        st.subheader("📝 Extracted Information")
                        st.write(processed_text)
                        
                        # Add session info to download content
                        session_info = f"Session ID: {st.session_state.uid}\nRegistration ID: {st.session_state.regid}\n\n"
                        
                        # Create download links
                        st.markdown("### 📥 Download Results")
                        st.markdown(get_download_link(
                            session_info + extracted_text, 
                            f'extracted_text_{st.session_state.uid}.txt', 
                            'Download Raw Extracted Text'
                        ), unsafe_allow_html=True)
                        
                        st.markdown(get_download_link(
                            session_info + processed_text,
                            f'processed_info_{st.session_state.uid}.txt',
                            'Download Processed Information'
                        ), unsafe_allow_html=True)
                    else:
                        st.warning("No text could be extracted from the image. Please try with a clearer image.")
                
                # Clean up temporary file
                os.unlink(tmp_file.name)

if __name__ == "__main__":
    main()
