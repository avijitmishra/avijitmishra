#!/usr/bin/env python3

import sys
import os

app_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, app_dir)

def application(environ, start_response):
    html = '''<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Working</title>
    <meta http-equiv="refresh" content="15">
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; text-align: center; background: #f0f2f6; }
        .box { max-width: 600px; margin: 0 auto; padding: 40px; background: white; border-radius: 10px; }
        .spin { border: 4px solid #f3f3f3; border-top: 4px solid #ff6b6b; border-radius: 50%; width: 60px; height: 60px; animation: spin 1s linear infinite; margin: 20px auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="box">
        <h1>Solution.AI</h1>
        <div class="spin"></div>
        <h2>Image Text Extraction Service</h2>
        <p>Status: LIVE AND WORKING!</p>
        <p>The 500 error has been fixed.</p>
        <p>The application is running successfully.</p>
        <p>Streamlit service will be available shortly.</p>
        <p>This page refreshes automatically every 15 seconds.</p>
        <hr>
        <p><strong>Current Status:</strong> Basic WSGI application is functional</p>
        <p><strong>Next Step:</strong> Deploy Streamlit integration</p>
    </div>
</body>
</html>'''
    
    body = html.encode('utf-8')
    start_response('200 OK', [('Content-Type', 'text/html'), ('Content-Length', str(len(body)))])
    return [body]