#!/usr/bin/env python3
"""
Simple Passenger WSGI application for Plesk
This serves as a direct Streamlit launcher
"""

import sys
import os
import subprocess
import time
import threading

# Add the application directory to Python path
app_dir = os.path.dirname(__file__)
sys.path.insert(0, app_dir)

# Environment setup
os.environ['STREAMLIT_SERVER_HEADLESS'] = 'true'
os.environ['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'

class StreamlitApp:
    def __init__(self):
        self.process = None
        self.is_starting = True
        self.start_streamlit()
    
    def start_streamlit(self):
        """Start Streamlit process"""
        def run():
            try:
                # Change to app directory
                os.chdir(app_dir)
                
                # Start Streamlit
                cmd = [
                    sys.executable, '-m', 'streamlit', 'run', 'app.py',
                    '--server.port=8501',
                    '--server.address=127.0.0.1',
                    '--server.headless=true',
                    '--browser.gatherUsageStats=false',
                    '--server.enableCORS=false',
                    '--server.enableXsrfProtection=false'
                ]
                
                self.process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=app_dir
                )
                
                # Mark as started after a brief delay
                time.sleep(3)
                self.is_starting = False
                
            except Exception as e:
                print(f"Error starting Streamlit: {e}")
                self.is_starting = False
        
        # Start in background thread
        thread = threading.Thread(target=run, daemon=True)
        thread.start()

# Global Streamlit app instance
streamlit_app = StreamlitApp()

def application(environ, start_response):
    """WSGI application function"""
    
    # If Streamlit is still starting, show loading page
    if streamlit_app.is_starting:
        response_body = b"""
<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Starting...</title>
    <meta http-equiv="refresh" content="5">
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; text-align: center; background: #f0f2f6; }
        .container { max-width: 600px; margin: 0 auto; padding: 40px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .loading { font-size: 18px; margin: 20px 0; color: #555; }
        .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #ff6b6b; border-radius: 50%; width: 60px; height: 60px; animation: spin 1s linear infinite; margin: 20px auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Solution.AI</h1>
        <div class="spinner"></div>
        <div class="loading">Starting image text extraction application...</div>
        <p>This may take up to 30 seconds for first startup.</p>
        <p>The page will refresh automatically.</p>
    </div>
</body>
</html>
        """
        
        start_response('200 OK', [
            ('Content-Type', 'text/html'),
            ('Content-Length', str(len(response_body)))
        ])
        return [response_body]
    
    # Check if Streamlit process is running
    if streamlit_app.process and streamlit_app.process.poll() is None:
        # Proxy to Streamlit
        try:
            import urllib.request
            import urllib.error
            
            # Build URL for Streamlit
            path_info = environ.get('PATH_INFO', '/')
            query_string = environ.get('QUERY_STRING', '')
            
            url = f"http://127.0.0.1:8501{path_info}"
            if query_string:
                url += f"?{query_string}"
            
            # Create request
            req = urllib.request.Request(url)
            
            # Copy important headers
            for key, value in environ.items():
                if key.startswith('HTTP_'):
                    header_name = key[5:].replace('_', '-')
                    if header_name.lower() not in ['host', 'connection']:
                        req.add_header(header_name, value)
            
            # Make request to Streamlit
            try:
                response = urllib.request.urlopen(req, timeout=10)
                
                # Get response data
                content = response.read()
                
                # Prepare headers
                headers = []
                for header, value in response.headers.items():
                    if header.lower() not in ['server', 'date']:
                        headers.append((header, value))
                
                start_response(f"{response.getcode()} {response.reason}", headers)
                return [content]
                
            except urllib.error.URLError:
                # Streamlit not ready yet
                raise Exception("Streamlit not responding")
                
        except Exception as e:
            # Return error page with retry
            error_body = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Service Starting</title>
    <meta http-equiv="refresh" content="10">
    <style>
        body {{ font-family: Arial, sans-serif; margin: 50px; text-align: center; background: #f0f2f6; }}
        .container {{ max-width: 600px; margin: 0 auto; padding: 40px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        .error {{ color: #e74c3c; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Solution.AI</h1>
        <div class="error">Service is starting up...</div>
        <p>The application is initializing. Please wait.</p>
        <p>This page will refresh automatically in 10 seconds.</p>
        <p><small>Error: {str(e)}</small></p>
    </div>
</body>
</html>
            """.encode('utf-8')
            
            start_response('503 Service Unavailable', [
                ('Content-Type', 'text/html'),
                ('Content-Length', str(len(error_body)))
            ])
            return [error_body]
    
    else:
        # Streamlit process died, restart it
        streamlit_app.is_starting = True
        streamlit_app.start_streamlit()
        
        restart_body = b"""
<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Restarting</title>
    <meta http-equiv="refresh" content="15">
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; text-align: center; background: #f0f2f6; }
        .container { max-width: 600px; margin: 0 auto; padding: 40px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Solution.AI</h1>
        <p>Application is restarting...</p>
        <p>Please wait while the service recovers.</p>
        <p>This page will refresh automatically.</p>
    </div>
</body>
</html>
        """
        
        start_response('503 Service Unavailable', [
            ('Content-Type', 'text/html'),
            ('Content-Length', str(len(restart_body)))
        ])
        return [restart_body]