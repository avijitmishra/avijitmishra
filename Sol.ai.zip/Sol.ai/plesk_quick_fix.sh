#!/bin/bash

# Plesk Quick Fix for Solution.AI Streamlit Deployment
# This script quickly replaces the problematic passenger_wsgi.py with a working Streamlit launcher

echo "🔧 Plesk Quick Fix for Solution.AI - Starting..."

# Get current directory
CURRENT_DIR=$(pwd)
echo "📍 Working directory: $CURRENT_DIR"

# Backup existing passenger_wsgi.py if it exists
if [ -f "passenger_wsgi.py" ]; then
    echo "💾 Backing up existing passenger_wsgi.py..."
    cp passenger_wsgi.py "passenger_wsgi.py.backup.$(date +%Y%m%d_%H%M%S)"
fi

# Copy the new Streamlit WSGI launcher
if [ -f "passenger_wsgi_streamlit.py" ]; then
    echo "🚀 Installing new Streamlit WSGI launcher..."
    cp passenger_wsgi_streamlit.py passenger_wsgi.py
    echo "✅ New passenger_wsgi.py installed"
else
    echo "❌ passenger_wsgi_streamlit.py not found"
    exit 1
fi

# Set proper permissions
chmod 644 passenger_wsgi.py
echo "✅ Permissions set"

# Kill any existing Python processes to force restart
echo "🔄 Restarting application..."
pkill -f "streamlit\|passenger_wsgi" 2>/dev/null || true

# Touch passenger_wsgi.py to trigger reload
touch passenger_wsgi.py

echo ""
echo "🎉 Quick fix completed!"
echo ""
echo "📋 What was done:"
echo "   ✅ Backed up old passenger_wsgi.py"
echo "   ✅ Installed new Streamlit WSGI launcher"
echo "   ✅ Set proper permissions"
echo "   ✅ Triggered application restart"
echo ""
echo "🌐 Your Streamlit app should now be accessible at:"
echo "   https://ai.erpabsolute.net"
echo ""
echo "⏰ Note: It may take 30-60 seconds for Streamlit to fully start"
echo "📝 Check the application in your browser in a few moments"
echo ""

# Optional: Display recent application logs if available
if [ -f "streamlit.log" ]; then
    echo "📊 Recent application logs:"
    tail -10 streamlit.log
fi

echo "✨ Quick fix completed successfully!"