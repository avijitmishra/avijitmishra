#!/usr/bin/env python3
"""
Direct Flask-to-Streamlit Bridge for Plesk
This creates a Flask app that proxies all requests to Streamlit
"""

import os
import sys
import subprocess
import threading
import time
import requests
from flask import Flask, request, Response

# Add app directory to path
app_dir = os.path.dirname(__file__)
sys.path.insert(0, app_dir)

# Flask app
app = Flask(__name__)

# Streamlit configuration
STREAMLIT_URL = "http://127.0.0.1:8501"
streamlit_process = None
streamlit_starting = True

def start_streamlit():
    """Start Streamlit in background"""
    global streamlit_process, streamlit_starting
    
    try:
        # Change to app directory
        os.chdir(app_dir)
        
        # Environment setup
        env = os.environ.copy()
        env['STREAMLIT_SERVER_HEADLESS'] = 'true'
        env['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'
        
        # Start Streamlit
        cmd = [
            sys.executable, '-m', 'streamlit', 'run', 'app.py',
            '--server.port=8501',
            '--server.address=127.0.0.1',
            '--server.headless=true',
            '--browser.gatherUsageStats=false',
            '--server.enableCORS=false',
            '--server.enableXsrfProtection=false'
        ]
        
        streamlit_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            cwd=app_dir
        )
        
        # Wait a moment for startup
        time.sleep(5)
        streamlit_starting = False
        
        print(f"✅ Streamlit started with PID: {streamlit_process.pid}")
        
    except Exception as e:
        print(f"❌ Error starting Streamlit: {e}")
        streamlit_starting = False

def is_streamlit_running():
    """Check if Streamlit is responding"""
    try:
        response = requests.get(f"{STREAMLIT_URL}/healthz", timeout=2)
        return response.status_code == 200
    except:
        try:
            response = requests.get(STREAMLIT_URL, timeout=2)
            return response.status_code == 200
        except:
            return False

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def proxy_to_streamlit(path):
    """Proxy all requests to Streamlit"""
    global streamlit_starting
    
    # If Streamlit is starting, show loading page
    if streamlit_starting:
        loading_html = """
<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Starting...</title>
    <meta http-equiv="refresh" content="5">
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; text-align: center; background: #f0f2f6; }
        .container { max-width: 600px; margin: 0 auto; padding: 40px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .loading { font-size: 18px; margin: 20px 0; color: #555; }
        .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #ff6b6b; border-radius: 50%; width: 60px; height: 60px; animation: spin 1s linear infinite; margin: 20px auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Solution.AI</h1>
        <div class="spinner"></div>
        <div class="loading">Starting image text extraction application...</div>
        <p>This may take up to 30 seconds for first startup.</p>
        <p>The page will refresh automatically.</p>
    </div>
</body>
</html>
        """
        return loading_html
    
    # Check if Streamlit is running
    if not is_streamlit_running():
        # Try to restart Streamlit
        if streamlit_process is None or streamlit_process.poll() is not None:
            streamlit_starting = True
            threading.Thread(target=start_streamlit, daemon=True).start()
            
        error_html = """
<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Service Starting</title>
    <meta http-equiv="refresh" content="10">
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; text-align: center; background: #f0f2f6; }
        .container { max-width: 600px; margin: 0 auto; padding: 40px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .error { color: #e74c3c; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Solution.AI</h1>
        <div class="error">Service is starting up...</div>
        <p>The application is initializing. Please wait.</p>
        <p>This page will refresh automatically in 10 seconds.</p>
    </div>
</body>
</html>
        """
        return error_html, 503
    
    # Proxy the request to Streamlit
    try:
        # Build target URL
        target_url = f"{STREAMLIT_URL}/{path}"
        if request.query_string:
            target_url += f"?{request.query_string.decode()}"
        
        # Prepare headers
        headers = dict(request.headers)
        headers.pop('Host', None)
        
        # Make request to Streamlit
        if request.method == 'GET':
            resp = requests.get(target_url, headers=headers, stream=True, timeout=30)
        elif request.method == 'POST':
            resp = requests.post(target_url, headers=headers, data=request.get_data(), stream=True, timeout=30)
        else:
            resp = requests.request(request.method, target_url, headers=headers, data=request.get_data(), stream=True, timeout=30)
        
        # Prepare response headers
        response_headers = []
        for key, value in resp.headers.items():
            if key.lower() not in ['content-encoding', 'content-length', 'transfer-encoding', 'connection']:
                response_headers.append((key, value))
        
        # Return proxied response
        return Response(
            resp.content,
            status=resp.status_code,
            headers=response_headers
        )
        
    except Exception as e:
        print(f"Proxy error: {e}")
        error_html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Connection Error</title>
    <meta http-equiv="refresh" content="15">
    <style>
        body {{ font-family: Arial, sans-serif; margin: 50px; text-align: center; background: #f0f2f6; }}
        .container {{ max-width: 600px; margin: 0 auto; padding: 40px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Solution.AI</h1>
        <p>Connection error occurred.</p>
        <p>Attempting to restart the service...</p>
        <p>This page will refresh automatically.</p>
        <p><small>Error: {str(e)}</small></p>
    </div>
</body>
</html>
        """
        return error_html, 503

@app.route('/health')
def health_check():
    """Health check endpoint"""
    if is_streamlit_running():
        return {"status": "healthy", "streamlit": "running"}
    else:
        return {"status": "unhealthy", "streamlit": "not running"}, 503

# Start Streamlit when module loads
threading.Thread(target=start_streamlit, daemon=True).start()

if __name__ == "__main__":
    # For development
    app.run(debug=True, host="127.0.0.1", port=5000)

# WSGI application for production
application = app