# Emergency Fix Script for Plesk Deployment
Write-Host "🚨 EMERGENCY FIX - Resolving 500 Internal Server Error" -ForegroundColor Red
Write-Host ""

# Create backup
if (Test-Path "passenger_wsgi.py") {
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    Copy-Item "passenger_wsgi.py" "passenger_wsgi.py.error_backup.$timestamp"
    Write-Host "✅ Backup created: passenger_wsgi.py.error_backup.$timestamp" -ForegroundColor Green
}

# Deploy emergency fix
if (Test-Path "passenger_wsgi_emergency.py") {
    Copy-Item "passenger_wsgi_emergency.py" "passenger_wsgi.py"
    Write-Host "✅ Emergency fix deployed" -ForegroundColor Green
}
else {
    Write-Host "❌ Emergency fix file not found" -ForegroundColor Red
    exit 1
}

# Trigger restart
(Get-Item "passenger_wsgi.py").LastWriteTime = Get-Date
Write-Host "✅ Application restart triggered" -ForegroundColor Green

Write-Host ""
Write-Host "🎯 EMERGENCY FIX COMPLETED" -ForegroundColor Green
Write-Host ""
Write-Host "📋 What was done:" -ForegroundColor Cyan
Write-Host "   ✅ Backed up problematic passenger_wsgi.py" -ForegroundColor Green
Write-Host "   ✅ Deployed minimal working WSGI application" -ForegroundColor Green
Write-Host "   ✅ Triggered server restart" -ForegroundColor Green
Write-Host ""
Write-Host "🌐 Check your site now:" -ForegroundColor Cyan
Write-Host "   https://ai.erpabsolute.net" -ForegroundColor White
Write-Host ""
Write-Host "✅ You should see 'Solution.AI - Working' instead of 500 error" -ForegroundColor Green
Write-Host "⏰ Wait 30 seconds then refresh the page" -ForegroundColor Yellow
Write-Host ""
Write-Host "🔄 Next step: Once this works, we'll deploy the full Streamlit version" -ForegroundColor Cyan

Read-Host "Press Enter to continue"