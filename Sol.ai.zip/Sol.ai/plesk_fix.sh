#!/bin/bash
# Plesk Fix Script for Solution.AI Streamlit Application
# This script fixes common deployment issues on Plesk servers

set -e

echo "🔧 Plesk Fix Script for Solution.AI"
echo "=================================="
echo ""

# Configuration
DOMAIN_PATH="/var/www/vhosts/ai.erpabsolute.net"
HTTPDOCS_PATH="$DOMAIN_PATH/httpdocs"
VENV_PATH="$DOMAIN_PATH/venv"
BACKUP_PATH="$DOMAIN_PATH/backup_$(date +%Y%m%d_%H%M%S)"

echo "📁 Using paths:"
echo "   Domain: $DOMAIN_PATH"
echo "   Web files: $HTTPDOCS_PATH"
echo "   Virtual env: $VENV_PATH"
echo "   Backup: $BACKUP_PATH"
echo ""

# Function to log steps
log_step() {
    echo "🔹 $1"
}

# Function to create backup
create_backup() {
    log_step "Creating backup of existing files..."
    mkdir -p "$BACKUP_PATH"
    if [ -d "$HTTPDOCS_PATH" ]; then
        cp -r "$HTTPDOCS_PATH"/* "$BACKUP_PATH/" 2>/dev/null || true
        echo "   ✅ Backup created at: $BACKUP_PATH"
    fi
}

# Function to stop existing applications
stop_existing_apps() {
    log_step "Stopping existing applications..."
    
    # Kill any existing Streamlit processes
    pkill -f "streamlit run" 2>/dev/null || true
    pkill -f "python.*app.py" 2>/dev/null || true
    
    # Stop any systemd services
    sudo systemctl stop solution-ai-streamlit 2>/dev/null || true
    sudo systemctl stop streamlit-monitor 2>/dev/null || true
    
    echo "   ✅ Existing applications stopped"
}

# Function to install system dependencies
install_system_deps() {
    log_step "Installing system dependencies..."
    
    # Update package list
    sudo apt-get update -qq
    
    # Install required packages
    sudo apt-get install -y \
        python3 \
        python3-pip \
        python3-venv \
        tesseract-ocr \
        curl \
        wget \
        git \
        nginx
    
    echo "   ✅ System dependencies installed"
}

# Function to create virtual environment
setup_virtual_env() {
    log_step "Setting up Python virtual environment..."
    
    # Remove existing virtual environment if it exists
    if [ -d "$VENV_PATH" ]; then
        rm -rf "$VENV_PATH"
    fi
    
    # Create new virtual environment
    python3 -m venv "$VENV_PATH"
    
    # Activate and upgrade pip
    source "$VENV_PATH/bin/activate"
    pip install --upgrade pip
    
    echo "   ✅ Virtual environment created"
}

# Function to install Python dependencies
install_python_deps() {
    log_step "Installing Python dependencies..."
    
    source "$VENV_PATH/bin/activate"
    
    if [ -f "$HTTPDOCS_PATH/requirements.txt" ]; then
        pip install -r "$HTTPDOCS_PATH/requirements.txt"
        echo "   ✅ Dependencies installed from requirements.txt"
    else
        # Install essential packages
        pip install streamlit pytesseract Pillow python-dotenv pandas openpyxl python-docx
        echo "   ✅ Essential packages installed"
    fi
}

# Function to configure Plesk for Streamlit
configure_plesk_streamlit() {
    log_step "Configuring Plesk for Streamlit application..."
    
    # Create new passenger_wsgi.py specifically for Streamlit
    cat > "$HTTPDOCS_PATH/passenger_wsgi.py" << 'EOF'
#!/usr/bin/env python3
"""
Passenger WSGI file for Streamlit on Plesk
This file starts Streamlit as a WSGI application
"""

import sys
import os
import subprocess
import threading
import time
from wsgiref.simple_server import make_server

# Add the application directory to Python path
sys.path.insert(0, os.path.dirname(__file__))

# Set environment variables
os.environ['STREAMLIT_SERVER_PORT'] = '8501'
os.environ['STREAMLIT_SERVER_ADDRESS'] = '0.0.0.0'
os.environ['STREAMLIT_SERVER_HEADLESS'] = 'true'
os.environ['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'

# Global variable to store Streamlit process
streamlit_process = None

def start_streamlit():
    """Start Streamlit in a separate process"""
    global streamlit_process
    try:
        cmd = [
            sys.executable, '-m', 'streamlit', 'run', 'app.py',
            '--server.port=8501',
            '--server.address=0.0.0.0',
            '--server.headless=true',
            '--browser.gatherUsageStats=false'
        ]
        
        streamlit_process = subprocess.Popen(
            cmd,
            cwd=os.path.dirname(__file__),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Wait a moment for Streamlit to start
        time.sleep(5)
        
        return streamlit_process.poll() is None
    except Exception as e:
        print(f"Error starting Streamlit: {e}")
        return False

def proxy_request(environ, start_response):
    """Proxy requests to Streamlit"""
    try:
        import urllib.request
        import urllib.parse
        
        # Build the Streamlit URL
        query_string = environ.get('QUERY_STRING', '')
        path_info = environ.get('PATH_INFO', '/')
        
        streamlit_url = f"http://localhost:8501{path_info}"
        if query_string:
            streamlit_url += f"?{query_string}"
        
        # Make request to Streamlit
        request = urllib.request.Request(streamlit_url)
        
        # Copy headers
        for key, value in environ.items():
            if key.startswith('HTTP_'):
                header_name = key[5:].replace('_', '-').title()
                request.add_header(header_name, value)
        
        response = urllib.request.urlopen(request, timeout=30)
        
        # Return response
        status = f"{response.getcode()} {response.reason}"
        headers = list(response.headers.items())
        
        start_response(status, headers)
        return [response.read()]
        
    except Exception as e:
        # Return error page
        error_html = f"""
        <html>
        <head><title>Solution.AI - Starting...</title></head>
        <body>
            <h1>Solution.AI is starting...</h1>
            <p>Please wait a moment and refresh the page.</p>
            <p>If this error persists, the application may be starting up.</p>
            <p>Error: {str(e)}</p>
            <script>
                setTimeout(function(){{ window.location.reload(); }}, 5000);
            </script>
        </body>
        </html>
        """
        
        start_response('503 Service Unavailable', [
            ('Content-Type', 'text/html'),
            ('Content-Length', str(len(error_html)))
        ])
        return [error_html.encode('utf-8')]

# Start Streamlit when the module is loaded
threading.Thread(target=start_streamlit, daemon=True).start()

# WSGI application
application = proxy_request
EOF

    echo "   ✅ passenger_wsgi.py configured for Streamlit"
}

# Function to create startup script
create_startup_script() {
    log_step "Creating startup script..."
    
    cat > "$HTTPDOCS_PATH/start_app.py" << 'EOF'
#!/usr/bin/env python3
"""
Direct Streamlit startup script for Plesk
"""

import sys
import os

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(__file__))

# Set environment variables for Streamlit
os.environ['STREAMLIT_SERVER_PORT'] = '8501'
os.environ['STREAMLIT_SERVER_ADDRESS'] = '0.0.0.0'
os.environ['STREAMLIT_SERVER_HEADLESS'] = 'true'
os.environ['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'

if __name__ == "__main__":
    import streamlit.web.cli as stcli
    sys.argv = [
        "streamlit",
        "run",
        "app.py",
        "--server.port=8501",
        "--server.address=0.0.0.0",
        "--server.headless=true",
        "--browser.gatherUsageStats=false"
    ]
    sys.exit(stcli.main())
EOF

    chmod +x "$HTTPDOCS_PATH/start_app.py"
    echo "   ✅ Startup script created"
}

# Function to set correct permissions
set_permissions() {
    log_step "Setting correct file permissions..."
    
    # Set directory permissions
    find "$HTTPDOCS_PATH" -type d -exec chmod 755 {} \;
    
    # Set file permissions
    find "$HTTPDOCS_PATH" -type f -exec chmod 644 {} \;
    
    # Make scripts executable
    chmod +x "$HTTPDOCS_PATH/passenger_wsgi.py" 2>/dev/null || true
    chmod +x "$HTTPDOCS_PATH/start_app.py" 2>/dev/null || true
    chmod +x "$HTTPDOCS_PATH"/*.sh 2>/dev/null || true
    
    # Set ownership (if running as root)
    if [ "$EUID" -eq 0 ]; then
        chown -R psacln:psaserv "$HTTPDOCS_PATH"
        chown -R psacln:psaserv "$VENV_PATH"
    fi
    
    echo "   ✅ Permissions set correctly"
}

# Function to test the application
test_application() {
    log_step "Testing the application..."
    
    cd "$HTTPDOCS_PATH"
    source "$VENV_PATH/bin/activate"
    
    # Test Python imports
    python3 -c "
import sys
sys.path.insert(0, '.')
try:
    import streamlit
    print('✅ Streamlit import: OK')
    import pytesseract
    print('✅ Pytesseract import: OK')
    from PIL import Image
    print('✅ PIL import: OK')
    print('✅ All critical imports successful')
except ImportError as e:
    print(f'❌ Import error: {e}')
    sys.exit(1)
"
    
    # Test if app.py exists and is valid
    if [ -f "app.py" ]; then
        python3 -m py_compile app.py
        echo "   ✅ app.py syntax is valid"
    else
        echo "   ❌ app.py not found"
        return 1
    fi
    
    echo "   ✅ Application tests passed"
}

# Function to start the application
start_application() {
    log_step "Starting the Streamlit application..."
    
    cd "$HTTPDOCS_PATH"
    source "$VENV_PATH/bin/activate"
    
    # Start Streamlit in background
    nohup python3 start_app.py > logs/streamlit.log 2>&1 &
    STREAMLIT_PID=$!
    
    # Wait a moment for startup
    sleep 5
    
    # Check if process is still running
    if kill -0 $STREAMLIT_PID 2>/dev/null; then
        echo "   ✅ Streamlit started successfully (PID: $STREAMLIT_PID)"
        echo $STREAMLIT_PID > streamlit.pid
        
        # Test if it's responding
        sleep 5
        if curl -s --max-time 10 http://localhost:8501 >/dev/null 2>&1; then
            echo "   ✅ Streamlit is responding on port 8501"
        else
            echo "   ⚠️  Streamlit may still be starting up"
        fi
    else
        echo "   ❌ Failed to start Streamlit"
        return 1
    fi
}

# Function to create simple index.html for immediate testing
create_test_page() {
    log_step "Creating test page..."
    
    cat > "$HTTPDOCS_PATH/index.html" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Loading...</title>
    <meta http-equiv="refresh" content="3;url=/app">
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; text-align: center; }
        .loading { font-size: 24px; margin: 20px; }
        .status { margin: 10px; padding: 10px; border-radius: 5px; }
        .success { background-color: #d4edda; border: 1px solid #c3e6cb; }
        .info { background-color: #d1ecf1; border: 1px solid #bee5eb; }
    </style>
</head>
<body>
    <h1>🚀 Solution.AI</h1>
    <div class="loading">Loading application...</div>
    <div class="status info">
        <p>The Streamlit application is starting up.</p>
        <p>You will be redirected automatically.</p>
        <p>If redirect doesn't work, <a href="/app">click here</a>.</p>
    </div>
    
    <script>
        // Check if Streamlit is available
        function checkStreamlit() {
            fetch('/app')
                .then(response => {
                    if (response.ok) {
                        window.location.href = '/app';
                    }
                })
                .catch(() => {
                    // Try again in 2 seconds
                    setTimeout(checkStreamlit, 2000);
                });
        }
        
        // Start checking after 3 seconds
        setTimeout(checkStreamlit, 3000);
    </script>
</body>
</html>
EOF

    echo "   ✅ Test page created"
}

# Main execution
main() {
    echo "Starting Plesk fix process..."
    echo ""
    
    # Create logs directory
    mkdir -p "$HTTPDOCS_PATH/logs"
    
    # Execute fix steps
    create_backup
    stop_existing_apps
    install_system_deps
    setup_virtual_env
    install_python_deps
    configure_plesk_streamlit
    create_startup_script
    create_test_page
    set_permissions
    test_application
    start_application
    
    echo ""
    echo "=========================================="
    echo "🎉 Fix Process Complete!"
    echo ""
    echo "📋 Summary:"
    echo "✅ System dependencies installed"
    echo "✅ Virtual environment created"
    echo "✅ Python packages installed"
    echo "✅ Plesk configuration updated"
    echo "✅ Application started"
    echo ""
    echo "🌐 Access your application:"
    echo "   Primary URL: http://ai.erpabsolute.net"
    echo "   Direct access: http://ai.erpabsolute.net/app"
    echo "   Test page: http://ai.erpabsolute.net/index.html"
    echo ""
    echo "📊 Monitoring:"
    echo "   Logs: $HTTPDOCS_PATH/logs/streamlit.log"
    echo "   PID file: $HTTPDOCS_PATH/streamlit.pid"
    echo ""
    echo "🔧 Management commands:"
    echo "   Check status: ps aux | grep streamlit"
    echo "   View logs: tail -f $HTTPDOCS_PATH/logs/streamlit.log"
    echo "   Restart: pkill -f streamlit && cd $HTTPDOCS_PATH && python3 start_app.py &"
    echo ""
    echo "If you still see issues, wait 1-2 minutes for full startup."
    echo "=========================================="
}

# Run main function
main