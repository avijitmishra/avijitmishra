from flask import Flask
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Create Flask application
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'dev-secret-key')

# Disable debug mode and development server banner
app.config.update(
    DEBUG=False,
    PROPAGATE_EXCEPTIONS=True
)

# Import routes after app creation to avoid circular imports
from app import routes
