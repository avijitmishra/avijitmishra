from flask import render_template, request, jsonify, send_file, session
from app import app
import os
import pytesseract
from PIL import Image
import tempfile
import io
import openai

def get_tesseract_status():
    """Check if Tesseract is installed and accessible"""
    try:
        pytesseract.get_tesseract_version()
        return True, "Tesseract is installed and accessible"
    except pytesseract.TesseractNotFoundError:
        return False, "Tesseract is not installed or not in PATH"

def extract_text_with_ocr(image_path):
    """Extract text from image using Tesseract OCR"""
    try:
        # Check if Tesseract is installed
        tesseract_installed, _ = get_tesseract_status()
        if not tesseract_installed:
            return False, "Tesseract is not installed. Please install it from https://github.com/UB-Mannheim/tesseract/wiki"
            
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img)
        
        if not text.strip():
            return False, "No text could be extracted from the image. Please try with a clearer image."
            
        return True, text.strip()
    except Exception as e:
        return False, f"Error in OCR processing: {str(e)}"

def process_with_gpt(text):
    """Process extracted text with GPT to organize information into detailed structure"""
    try:
        if not text.strip():
            return True, "No text was detected in the image. Please try with a clearer image containing text."
        
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system", 
                    "content": """You are an expert data extraction specialist. Extract and organize ALL information from the provided text into a detailed, structured format. 

IMPORTANT INSTRUCTIONS:
1. Extract EVERY piece of information, no matter how small
2. Organize into clear categories (Personal Info, Dates, Numbers, Addresses, etc.)
3. Create tables for structured data when applicable
4. Include confidence levels for extracted data
5. Provide detailed analysis and insights
6. Format the output in clear sections with headers
7. If it's a document, identify the document type
8. Extract any metadata or context clues

Format your response with clear headers and organize all information systematically."""
                },
                {
                    "role": "user", 
                    "content": f"""Please analyze and extract ALL information from this text in a comprehensive, structured format:

TEXT TO ANALYZE:
{text}

Please provide:
1. Document/Content Type Identification
2. Complete Information Extraction (organized by categories)
3. Structured Data Tables (if applicable)
4. Key Insights and Analysis
5. Data Quality Assessment
6. Any Additional Context or Recommendations"""
                }
            ],
            max_tokens=2000,
            temperature=0.1
        )
        return True, response.choices[0].message['content']
    except Exception:
        # Return detailed fallback analysis if AI processing fails
        fallback_analysis = f"""📄 EXTRACTED TEXT CONTENT

🔍 Raw Extracted Text:
{text}

📋 Basic Analysis:
- Total Characters: {len(text)}
- Total Words: {len(text.split())}
- Contains Numbers: {'Yes' if any(char.isdigit() for char in text) else 'No'}
- Contains Email: {'Yes' if '@' in text else 'No'}
- Contains Phone: {'Yes' if any(char.isdigit() for char in text.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')) and len([c for c in text if c.isdigit()]) >= 7 else 'No'}

⚠️ Note: Advanced AI analysis was not available. This is the raw extracted text with basic analysis."""
        return True, fallback_analysis

@app.route('/')
def index():
    """Render the main page"""
    # Get query parameters
    regid = request.args.get('regid', '')
    uid = request.args.get('uid', '')
    
    # Store in session
    session['regid'] = regid
    session['uid'] = uid
    
    # Check Tesseract status
    tesseract_installed, tesseract_status = get_tesseract_status()
    
    return render_template('index.html', 
                         tesseract_installed=tesseract_installed,
                         tesseract_status=tesseract_status,
                         regid=regid,
                         uid=uid)

@app.route('/process', methods=['POST'])
def process_image():
    """Process uploaded image"""
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No file selected'}), 400
    
    try:
        # Save uploaded file to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file:
            file.save(tmp_file.name)
            
            # Extract text using OCR
            success, result = extract_text_with_ocr(tmp_file.name)
            
            if not success:
                return jsonify({
                    'success': False,
                    'message': result,
                    'extracted_text': '',
                    'processed_text': ''
                })
            
            extracted_text = result
            
            # Process with GPT
            success, result = process_with_gpt(extracted_text)
            processed_text = result if success else ""
            
            return jsonify({
                'success': True,
                'message': 'Processing complete',
                'extracted_text': extracted_text,
                'processed_text': processed_text
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error processing image: {str(e)}',
            'extracted_text': '',
            'processed_text': ''
        }), 500
    
    finally:
        # Clean up temporary file
        if 'tmp_file' in locals() and os.path.exists(tmp_file.name):
            os.unlink(tmp_file.name)

@app.route('/download')
def download():
    """Download processed text"""
    text = request.args.get('text', '')
    filename = request.args.get('filename', 'output.txt')
    
    # Add session info if available
    session_info = []
    if 'uid' in session and session['uid']:
        session_info.append(f"User ID: {session['uid']}")
    if 'regid' in session and session['regid']:
        session_info.append(f"Registration ID: {session['regid']}")
    
    if session_info:
        text = f"{' | '.join(session_info)}\n\n{text}"
    
    # Create a file-like object in memory
    file_like = io.BytesIO(text.encode('utf-8'))
    
    return send_file(
        file_like,
        as_attachment=True,
        download_name=filename,
        mimetype='text/plain'
    )
