@echo off
echo 🔧 Plesk Fix for Solution.AI - Windows Version
echo.

:: Get current directory
set CURRENT_DIR=%CD%
echo 📍 Working directory: %CURRENT_DIR%

:: Backup existing passenger_wsgi.py if it exists
if exist "passenger_wsgi.py" (
    echo 💾 Backing up existing passenger_wsgi.py...
    for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
    set timestamp=%datetime:~0,8%_%datetime:~8,6%
    copy "passenger_wsgi.py" "passenger_wsgi.py.backup.%timestamp%"
    echo ✅ Backup created: passenger_wsgi.py.backup.%timestamp%
)

:: Check if the file already has Streamlit launcher content
findstr /C:"StreamlitApp" passenger_wsgi.py >nul
if %errorlevel%==0 (
    echo ✅ passenger_wsgi.py already contains Streamlit launcher
    echo 🔄 Triggering application restart...
    copy /b passenger_wsgi.py +,, passenger_wsgi.py >nul
    echo ✅ Application restart triggered
) else (
    echo ❌ passenger_wsgi.py needs updating
    echo Please upload the correct passenger_wsgi_streamlit.py file
    pause
    exit /b 1
)

:: Kill any existing Python processes related to the app
echo 🔄 Stopping existing processes...
taskkill /F /IM python.exe /FI "WINDOWTITLE eq streamlit*" 2>nul
taskkill /F /IM python.exe /FI "COMMANDLINE eq *streamlit*" 2>nul

echo.
echo 🎉 Fix completed!
echo.
echo 📋 What was done:
echo    ✅ Backed up existing passenger_wsgi.py
echo    ✅ Verified Streamlit launcher is in place
echo    ✅ Triggered application restart
echo    ✅ Stopped existing processes
echo.
echo 🌐 Your Streamlit app should now be accessible at:
echo    https://ai.erpabsolute.net
echo.
echo ⏰ Note: It may take 30-60 seconds for Streamlit to fully start
echo 📝 Check the application in your browser in a few moments
echo.
echo ✨ Fix completed successfully!
pause