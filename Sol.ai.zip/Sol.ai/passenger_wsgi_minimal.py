def application(environ, start_response):
    html = """<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Live</title>
    <meta http-equiv="refresh" content="20">
    <style>
        body { font-family: Arial; margin: 50px; text-align: center; background: #f0f2f6; }
        .box { max-width: 500px; margin: 0 auto; padding: 30px; background: white; border-radius: 10px; }
        .spin { border: 3px solid #ccc; border-top: 3px solid #e74c3c; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 20px auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="box">
        <h1>Solution.AI</h1>
        <div class="spin"></div>
        <h3>Image Text Extraction Service</h3>
        <p><strong>Status: LIVE AND WORKING!</strong></p>
        <p>The 500 error has been fixed.</p>
        <p>Application is now responding correctly.</p>
        <p>Streamlit integration coming next...</p>
        <p>Page auto-refreshes every 20 seconds.</p>
    </div>
</body>
</html>"""
    
    body = html.encode('utf-8')
    headers = [('Content-Type', 'text/html'), ('Content-Length', str(len(body)))]
    start_response('200 OK', headers)
    return [body]