with open('app.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()
    for i, line in enumerate(lines[:10], 1):
        print(f"Line {i}: {repr(line)}")