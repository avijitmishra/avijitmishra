#!/usr/bin/env python3
"""
Simple fallback Passenger WSGI application for Plesk
Minimal version that should work reliably
"""

import sys
import os

# Add the application directory to Python path
app_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, app_dir)

def application(environ, start_response):
    """Simple WSGI application that returns a basic page"""
    
    # Simple HTML response
    html = """<!DOCTYPE html>
<html>
<head>
    <title>Solution.AI - Service</title>
    <meta http-equiv="refresh" content="10">
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; text-align: center; background: #f0f2f6; }
        .container { max-width: 600px; margin: 0 auto; padding: 40px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .loading { font-size: 18px; margin: 20px 0; color: #555; }
        .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #ff6b6b; border-radius: 50%; width: 60px; height: 60px; animation: spin 1s linear infinite; margin: 20px auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="container">
        <h1>Solution.AI</h1>
        <div class="spinner"></div>
        <div class="loading">Image Text Extraction Service</div>
        <p>The application is initializing...</p>
        <p>Please wait while we start the service.</p>
        <p>This page will refresh automatically.</p>
        <hr>
        <h3>Service Information</h3>
        <p><strong>Status:</strong> Starting</p>
        <p><strong>Application:</strong> Streamlit Image OCR</p>
        <p><strong>Features:</strong> Text extraction from images using Pytesseract</p>
        <p><strong>No AI dependencies:</strong> Pure pattern recognition</p>
    </div>
</body>
</html>"""
    
    response_body = html.encode('utf-8')
    
    start_response('200 OK', [
        ('Content-Type', 'text/html'),
        ('Content-Length', str(len(response_body)))
    ])
    
    return [response_body]