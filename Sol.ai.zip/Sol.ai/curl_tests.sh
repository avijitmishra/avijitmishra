# Solution.AI - Curl Test Commands for QueryString Testing

## Basic Application Testing

### 1. Test Application Health
curl -I https://ai.erpabsolute.net/

### 2. Test Application Response
curl -v https://ai.erpabsolute.net/

## QueryString Parameter Testing

### 3. Test with Registration ID and User ID
curl "https://ai.erpabsolute.net/?regid=test123&uid=testuser456"

### 4. Test with only Registration ID
curl "https://ai.erpabsolute.net/?regid=REG001"

### 5. Test with only User ID
curl "https://ai.erpabsolute.net/?uid=USER001"

### 6. Test with Special Characters in QueryString
curl "https://ai.erpabsolute.net/?regid=REG%40001&uid=user%2Btest"

### 7. Test with Multiple Parameters
curl "https://ai.erpabsolute.net/?regid=test&uid=user&source=mobile&version=1.0"

## Local Testing (if running locally)

### 8. Test Local Streamlit App
curl "http://localhost:8501/?regid=test&uid=localuser"

### 9. Test Local Flask App (if available)
curl "http://localhost:5000/?regid=test&uid=localuser"

## Advanced Testing

### 10. Test with POST Request (for file upload simulation)
curl -X POST \
  -H "Content-Type: multipart/form-data" \
  -F "regid=test123" \
  -F "uid=testuser" \
  https://ai.erpabsolute.net/

### 11. Test Headers and QueryString
curl -H "User-Agent: Solution.AI-Test/1.0" \
     -H "Accept: text/html,application/json" \
     "https://ai.erpabsolute.net/?regid=CURL_TEST&uid=HEADER_TEST"

### 12. Test with Verbose Output
curl -v -L "https://ai.erpabsolute.net/?regid=verbose_test&uid=debug_user"

## Response Testing

### 13. Save Response to File
curl -o response_test.html "https://ai.erpabsolute.net/?regid=file_test&uid=save_test"

### 14. Test Response Time
curl -w "@curl-format.txt" -o /dev/null -s "https://ai.erpabsolute.net/?regid=time_test&uid=perf_test"

## SSL/HTTPS Testing

### 15. Test SSL Certificate
curl -I --insecure https://ai.erpabsolute.net/

### 16. Test with SSL Verification
curl --cacert /etc/ssl/certs/ca-certificates.crt "https://ai.erpabsolute.net/?regid=ssl_test&uid=cert_test"

## Notes:
# - Replace ai.erpabsolute.net with your actual domain
# - For local testing, use localhost:8501 for Streamlit or localhost:5000 for Flask
# - QueryString parameters (regid, uid) should be URL-encoded for special characters
# - Use -v flag for verbose output to debug issues
# - Use -I flag for headers-only requests
# - Use -o flag to save responses to files