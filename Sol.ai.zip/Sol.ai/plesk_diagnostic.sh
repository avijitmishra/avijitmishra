#!/bin/bash
# Plesk Server Diagnostic Script for Solution.AI
# Run this script to diagnose deployment issues

echo "🔍 Plesk Server Diagnostic for Solution.AI"
echo "=========================================="
echo ""

# Configuration
DOMAIN_PATH="/var/www/vhosts/ai.erpabsolute.net"
HTTPDOCS_PATH="$DOMAIN_PATH/httpdocs"
VENV_PATH="$DOMAIN_PATH/venv"

echo "📁 Checking file structure..."
echo "Domain path: $DOMAIN_PATH"
echo "Web files: $HTTPDOCS_PATH"
echo "Virtual env: $VENV_PATH"
echo ""

# Check if directories exist
if [ -d "$DOMAIN_PATH" ]; then
    echo "✅ Domain directory exists"
else
    echo "❌ Domain directory missing: $DOMAIN_PATH"
fi

if [ -d "$HTTPDOCS_PATH" ]; then
    echo "✅ Web directory exists"
    echo "   Files in httpdocs:"
    ls -la "$HTTPDOCS_PATH" | head -20
else
    echo "❌ Web directory missing: $HTTPDOCS_PATH"
fi

if [ -d "$VENV_PATH" ]; then
    echo "✅ Virtual environment exists"
else
    echo "❌ Virtual environment missing: $VENV_PATH"
fi

echo ""
echo "🔍 Checking required files..."

# Check for main application files
FILES_TO_CHECK=("app.py" "requirements.txt" "passenger_wsgi.py" ".env")
for file in "${FILES_TO_CHECK[@]}"; do
    if [ -f "$HTTPDOCS_PATH/$file" ]; then
        echo "✅ $file exists"
        if [ "$file" = "app.py" ]; then
            echo "   Size: $(stat -c%s "$HTTPDOCS_PATH/$file") bytes"
            echo "   First 5 lines:"
            head -5 "$HTTPDOCS_PATH/$file" | sed 's/^/      /'
        fi
    else
        echo "❌ $file missing"
    fi
done

echo ""
echo "🐍 Checking Python environment..."

# Check Python version
python3_version=$(python3 --version 2>/dev/null || echo "Not found")
echo "System Python3: $python3_version"

# Check virtual environment Python
if [ -f "$VENV_PATH/bin/python" ]; then
    venv_python_version=$("$VENV_PATH/bin/python" --version 2>/dev/null || echo "Error")
    echo "Virtual env Python: $venv_python_version"
    
    echo ""
    echo "🔍 Checking installed packages in virtual environment..."
    "$VENV_PATH/bin/pip" list | grep -E "(streamlit|flask|pytesseract|pillow)" || echo "No relevant packages found"
else
    echo "❌ Virtual environment Python not found"
fi

echo ""
echo "🌐 Checking web server processes..."

# Check for running Python processes
echo "Python processes:"
ps aux | grep python | grep -v grep | head -10 || echo "No Python processes found"

echo ""
echo "Streamlit processes:"
ps aux | grep streamlit | grep -v grep || echo "No Streamlit processes found"

echo ""
echo "🔌 Checking ports..."

# Check if common ports are in use
echo "Port 8501 (Streamlit default):"
netstat -tlnp 2>/dev/null | grep :8501 || echo "Port 8501 not in use"

echo ""
echo "Port 5000 (Flask default):"
netstat -tlnp 2>/dev/null | grep :5000 || echo "Port 5000 not in use"

echo ""
echo "All listening ports:"
netstat -tlnp 2>/dev/null | grep LISTEN | head -10

echo ""
echo "🔍 Checking Plesk Python app configuration..."

# Check Plesk Python app settings
PLESK_PYTHON_CONF="$DOMAIN_PATH/conf/python_webapp.conf"
if [ -f "$PLESK_PYTHON_CONF" ]; then
    echo "✅ Plesk Python config exists:"
    cat "$PLESK_PYTHON_CONF" | sed 's/^/   /'
else
    echo "❌ Plesk Python config not found: $PLESK_PYTHON_CONF"
fi

echo ""
echo "🔍 Checking passenger_wsgi.py configuration..."
if [ -f "$HTTPDOCS_PATH/passenger_wsgi.py" ]; then
    echo "✅ passenger_wsgi.py exists:"
    cat "$HTTPDOCS_PATH/passenger_wsgi.py" | sed 's/^/   /'
else
    echo "❌ passenger_wsgi.py missing"
fi

echo ""
echo "📝 Checking logs..."

# Check for log files
LOG_LOCATIONS=(
    "/var/log/apache2/error.log"
    "/var/log/nginx/error.log"
    "$DOMAIN_PATH/logs"
    "/var/www/vhosts/system/ai.erpabsolute.net/logs"
)

for log_path in "${LOG_LOCATIONS[@]}"; do
    if [ -f "$log_path" ]; then
        echo "📄 Found log: $log_path"
        echo "   Last 5 lines:"
        tail -5 "$log_path" 2>/dev/null | sed 's/^/      /' || echo "      Cannot read log"
    elif [ -d "$log_path" ]; then
        echo "📁 Log directory: $log_path"
        ls -la "$log_path" | head -5 | sed 's/^/   /'
    fi
done

echo ""
echo "🔧 Checking system dependencies..."

# Check for Tesseract
if command -v tesseract &> /dev/null; then
    tesseract_version=$(tesseract --version 2>&1 | head -1)
    echo "✅ Tesseract installed: $tesseract_version"
else
    echo "❌ Tesseract not installed"
fi

# Check for other dependencies
for cmd in curl wget git; do
    if command -v $cmd &> /dev/null; then
        echo "✅ $cmd available"
    else
        echo "❌ $cmd not available"
    fi
done

echo ""
echo "🌐 Testing web connectivity..."

# Test local connectivity
echo "Testing localhost connections:"
for port in 80 8501 5000; do
    if curl -s --max-time 5 "http://localhost:$port" >/dev/null 2>&1; then
        echo "✅ Port $port responding"
    else
        echo "❌ Port $port not responding"
    fi
done

echo ""
echo "🔍 Current working directory and permissions..."
echo "Current directory: $(pwd)"
echo "Current user: $(whoami)"
echo "User groups: $(groups)"

if [ -d "$HTTPDOCS_PATH" ]; then
    echo ""
    echo "File permissions in httpdocs:"
    ls -la "$HTTPDOCS_PATH" | head -10
fi

echo ""
echo "=========================================="
echo "🎯 Diagnostic Summary:"
echo ""

# Summary recommendations
echo "📋 Recommendations based on findings:"
echo ""

if [ ! -f "$HTTPDOCS_PATH/app.py" ]; then
    echo "❗ CRITICAL: app.py missing - upload your Streamlit application"
fi

if [ ! -d "$VENV_PATH" ]; then
    echo "❗ CRITICAL: Virtual environment missing - create and configure Python environment"
fi

if ! command -v tesseract &> /dev/null; then
    echo "❗ CRITICAL: Tesseract not installed - install OCR dependencies"
fi

ps aux | grep streamlit | grep -v grep >/dev/null
if [ $? -ne 0 ]; then
    echo "❗ ISSUE: Streamlit not running - start the Streamlit application"
fi

echo ""
echo "🔧 Next steps:"
echo "1. Fix any CRITICAL issues above"
echo "2. Run the fix script if available"
echo "3. Check Plesk Python application configuration"
echo "4. Restart the application"
echo ""
echo "=========================================="