from PIL import Image
import os

# Source image
source_image = r"C:\Users\user\.gemini\antigravity\brain\c851e247-d7b2-40ed-bbe8-2ff9c0e2cda2\uploaded_image_1767332996787.png"

# Output directory
output_dir = r"C:\Users\user\.gemini\antigravity\brain\c851e247-d7b2-40ed-bbe8-2ff9c0e2cda2\icons"

# Create output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

# Icon sizes needed
icon_sizes = [
    20, 29, 40, 58, 60, 76, 80, 87, 120, 152, 167, 180, 1024
]

# Open source image
print(f"Opening source image: {source_image}")
img = Image.open(source_image)

# Convert to RGBA if not already
if img.mode != 'RGBA':
    img = img.convert('RGBA')

print(f"Source image size: {img.size}")
print(f"Source image mode: {img.mode}")

# Generate all icon sizes
for size in icon_sizes:
    output_path = os.path.join(output_dir, f"icon-{size}.png")
    
    # Resize with high-quality resampling
    resized = img.resize((size, size), Image.Resampling.LANCZOS)
    
    # Save as PNG
    resized.save(output_path, "PNG", optimize=True)
    print(f"Generated: icon-{size}.png ({size}x{size})")

print(f"\nAll icons generated successfully in: {output_dir}")
