#!/bin/bash

# Build script for AbsoluteERP iOS App
# This script should be run on macOS with Xcode installed

echo "================================================================"
echo "Absolute ERP - iOS Build Script"
echo "================================================================"
echo ""

# Check if running on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "ERROR: This script must be run on macOS with Xcode installed."
    echo "Please transfer this project to a Mac to build the IPA."
    exit 1
fi

# Check if Xcode is installed
if ! command -v xcodebuild &> /dev/null; then
    echo "ERROR: Xcode is not installed or xcodebuild is not in PATH."
    echo "Please install Xcode from the Mac App Store."
    exit 1
fi

echo "Xcode found: $(xcodebuild -version | head -n 1)"
echo ""

# Project configuration
PROJECT_NAME="AbsoluteERP"
SCHEME="AbsoluteERP"
CONFIGURATION="Release"
WORKSPACE_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_PATH="$WORKSPACE_DIR/$PROJECT_NAME.xcodeproj"
BUILD_DIR="$WORKSPACE_DIR/build"
ARCHIVE_PATH="$BUILD_DIR/$PROJECT_NAME.xcarchive"
EXPORT_PATH="$BUILD_DIR/ipa"

echo "Project path: $PROJECT_PATH"
echo "Build directory: $BUILD_DIR"
echo ""

# Clean previous builds
echo "Cleaning previous builds..."
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

# Build and archive
echo ""
echo "Building and archiving project..."
echo "This may take a few minutes..."
echo ""

xcodebuild clean archive \
    -project "$PROJECT_PATH" \
    -scheme "$SCHEME" \
    -configuration "$CONFIGURATION" \
    -archivePath "$ARCHIVE_PATH" \
    -destination "generic/platform=iOS" \
    CODE_SIGN_IDENTITY="" \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGNING_ALLOWED=NO

if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: Build failed. Please check the errors above."
    echo ""
    echo "Common issues:"
    echo "1. Code signing: You need an Apple Developer account and valid certificates"
    echo "2. Provisioning profiles: Ensure you have the correct provisioning profile"
    echo "3. Bundle ID: Make sure com.absoluteerp.app is available or change it in project settings"
    echo ""
    echo "To build with proper code signing:"
    echo "1. Open $PROJECT_NAME.xcodeproj in Xcode"
    echo "2. Select the project in the navigator"
    echo "3. Go to 'Signing & Capabilities' tab"
    echo "4. Select your development team"
    echo "5. Xcode will automatically manage signing"
    echo "6. Then use Xcode's Product > Archive menu to create IPA"
    exit 1
fi

echo ""
echo "================================================================"
echo "Archive created successfully!"
echo "Location: $ARCHIVE_PATH"
echo "================================================================"
echo ""
echo "To create an IPA file:"
echo "1. Open Xcode"
echo "2. Go to Window > Organizer"
echo "3. Select the archive you just created"
echo "4. Click 'Distribute App'"
echo "5. Choose distribution method (App Store, Ad Hoc, Enterprise, or Development)"
echo "6. Follow the prompts to export the IPA"
echo ""
echo "Alternatively, you can use xcodebuild with an export options plist:"
echo "xcodebuild -exportArchive -archivePath \"$ARCHIVE_PATH\" -exportPath \"$EXPORT_PATH\" -exportOptionsPlist ExportOptions.plist"
echo ""
echo "Note: You need valid Apple Developer credentials and certificates for distribution."
echo "================================================================"
