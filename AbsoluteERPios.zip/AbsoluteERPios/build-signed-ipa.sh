#!/bin/bash

################################################################################
# AbsoluteERP iOS - Comprehensive Signed IPA Build Script
################################################################################
# 
# This script builds, archives, and exports a signed IPA for the AbsoluteERP
# iOS application with support for multiple distribution methods.
#
# Usage:
#   ./build-signed-ipa.sh [method] [team_id]
#
# Arguments:
#   method   - Distribution method: appstore, adhoc, development, or enterprise
#            - If not provided, script will prompt for selection
#   team_id  - Your Apple Developer Team ID (10-character ID)
#            - If not provided, script will prompt for input
#
# Examples:
#   ./build-signed-ipa.sh appstore ABCDE12345
#   ./build-signed-ipa.sh adhoc
#   ./build-signed-ipa.sh
#
################################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print functions
print_header() {
    echo ""
    echo "================================================================"
    echo "$1"
    echo "================================================================"
    echo ""
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

################################################################################
# Check Requirements
################################################################################

print_header "AbsoluteERP iOS - Signed IPA Build Script"

# Check if running on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    print_error "This script must be run on macOS with Xcode installed."
    print_info "Please transfer this project to a Mac to build the IPA."
    exit 1
fi

# Check if Xcode is installed
if ! command -v xcodebuild &> /dev/null; then
    print_error "Xcode is not installed or xcodebuild is not in PATH."
    print_info "Please install Xcode from the Mac App Store."
    exit 1
fi

XCODE_VERSION=$(xcodebuild -version | head -n 1)
print_success "Found $XCODE_VERSION"

################################################################################
# Project Configuration
################################################################################

PROJECT_NAME="AbsoluteERP"
SCHEME="AbsoluteERP"
CONFIGURATION="Release"
WORKSPACE_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_PATH="$WORKSPACE_DIR/$PROJECT_NAME.xcodeproj"
BUILD_DIR="$WORKSPACE_DIR/build"
ARCHIVE_PATH="$BUILD_DIR/$PROJECT_NAME.xcarchive"
EXPORT_DIR="$BUILD_DIR/ipa"

print_info "Project: $PROJECT_NAME"
print_info "Location: $PROJECT_PATH"

################################################################################
# Get Distribution Method
################################################################################

DISTRIBUTION_METHOD="$1"

if [ -z "$DISTRIBUTION_METHOD" ]; then
    echo ""
    echo "Select distribution method:"
    echo "  1) App Store      - For App Store submission"
    echo "  2) Ad Hoc         - For testing on registered devices"
    echo "  3) Development    - For development/internal testing"
    echo "  4) Enterprise     - For in-house distribution"
    echo ""
    read -p "Enter choice [1-4]: " choice
    
    case $choice in
        1) DISTRIBUTION_METHOD="appstore" ;;
        2) DISTRIBUTION_METHOD="adhoc" ;;
        3) DISTRIBUTION_METHOD="development" ;;
        4) DISTRIBUTION_METHOD="enterprise" ;;
        *) 
            print_error "Invalid choice"
            exit 1
            ;;
    esac
fi

# Convert to lowercase
DISTRIBUTION_METHOD=$(echo "$DISTRIBUTION_METHOD" | tr '[:upper:]' '[:lower:]')

# Validate distribution method
case $DISTRIBUTION_METHOD in
    appstore|app-store)
        DISTRIBUTION_METHOD="appstore"
        EXPORT_OPTIONS="ExportOptions-AppStore.plist"
        ;;
    adhoc|ad-hoc)
        DISTRIBUTION_METHOD="adhoc"
        EXPORT_OPTIONS="ExportOptions-AdHoc.plist"
        ;;
    development|dev)
        DISTRIBUTION_METHOD="development"
        EXPORT_OPTIONS="ExportOptions-Development.plist"
        ;;
    enterprise|ent)
        DISTRIBUTION_METHOD="enterprise"
        EXPORT_OPTIONS="ExportOptions-Enterprise.plist"
        ;;
    *)
        print_error "Invalid distribution method: $DISTRIBUTION_METHOD"
        print_info "Valid options: appstore, adhoc, development, enterprise"
        exit 1
        ;;
esac

print_success "Distribution method: $DISTRIBUTION_METHOD"

################################################################################
# Get Team ID
################################################################################

TEAM_ID="$2"

if [ -z "$TEAM_ID" ]; then
    echo ""
    print_warning "Apple Developer Team ID is required for code signing"
    print_info "Find your Team ID at: https://developer.apple.com/account/#!/membership/"
    print_info "Or in Xcode: Preferences → Accounts → Your Apple ID → Team"
    echo ""
    read -p "Enter your Team ID (10-character ID): " TEAM_ID
fi

# Validate Team ID format (should be 10 alphanumeric characters)
if [[ ! "$TEAM_ID" =~ ^[A-Z0-9]{10}$ ]]; then
    print_warning "Team ID should be 10 alphanumeric characters"
    print_info "Continuing anyway, but build may fail if Team ID is incorrect"
fi

print_success "Team ID: $TEAM_ID"

################################################################################
# Check Export Options File
################################################################################

EXPORT_OPTIONS_PATH="$WORKSPACE_DIR/$EXPORT_OPTIONS"

if [ ! -f "$EXPORT_OPTIONS_PATH" ]; then
    print_error "Export options file not found: $EXPORT_OPTIONS_PATH"
    exit 1
fi

# Update Team ID in export options file
print_info "Updating Team ID in export options..."
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS sed syntax
    sed -i '' "s/YOUR_TEAM_ID/$TEAM_ID/g" "$EXPORT_OPTIONS_PATH"
    sed -i '' "s/YOUR_ENTERPRISE_TEAM_ID/$TEAM_ID/g" "$EXPORT_OPTIONS_PATH"
else
    # Linux sed syntax
    sed -i "s/YOUR_TEAM_ID/$TEAM_ID/g" "$EXPORT_OPTIONS_PATH"
    sed -i "s/YOUR_ENTERPRISE_TEAM_ID/$TEAM_ID/g" "$EXPORT_OPTIONS_PATH"
fi

print_success "Export options configured"

################################################################################
# Clean Previous Builds
################################################################################

print_info "Cleaning previous builds..."
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
mkdir -p "$EXPORT_DIR"
print_success "Build directory cleaned"

################################################################################
# Build and Archive
################################################################################

print_header "Building and Archiving"

print_info "This may take a few minutes..."
echo ""

xcodebuild clean archive \
    -project "$PROJECT_PATH" \
    -scheme "$SCHEME" \
    -configuration "$CONFIGURATION" \
    -archivePath "$ARCHIVE_PATH" \
    -destination "generic/platform=iOS" \
    DEVELOPMENT_TEAM="$TEAM_ID" \
    | xcpretty || true

if [ ${PIPESTATUS[0]} -ne 0 ]; then
    print_error "Archive failed"
    echo ""
    print_info "Common issues:"
    print_info "1. Invalid Team ID - Check your Apple Developer account"
    print_info "2. Missing certificates - Install required certificates in Keychain"
    print_info "3. Missing provisioning profile - Create profile at developer.apple.com"
    print_info "4. Bundle ID not registered - Register com.absoluteerp.app on developer portal"
    echo ""
    exit 1
fi

print_success "Archive created successfully"

################################################################################
# Export IPA
################################################################################

print_header "Exporting IPA"

xcodebuild -exportArchive \
    -archivePath "$ARCHIVE_PATH" \
    -exportPath "$EXPORT_DIR" \
    -exportOptionsPlist "$EXPORT_OPTIONS_PATH" \
    | xcpretty || true

if [ ${PIPESTATUS[0]} -ne 0 ]; then
    print_error "Export failed"
    echo ""
    print_info "Common issues:"
    print_info "1. Export options plist misconfigured"
    print_info "2. Provisioning profile doesn't match distribution method"
    print_info "3. Code signing certificate not found"
    echo ""
    exit 1
fi

################################################################################
# Success
################################################################################

IPA_FILE="$EXPORT_DIR/$PROJECT_NAME.ipa"

print_header "Build Successful!"

print_success "IPA created: $IPA_FILE"

if [ -f "$IPA_FILE" ]; then
    IPA_SIZE=$(du -h "$IPA_FILE" | cut -f1)
    print_info "IPA size: $IPA_SIZE"
fi

echo ""
print_info "Archive location: $ARCHIVE_PATH"
print_info "Export location: $EXPORT_DIR"
echo ""

case $DISTRIBUTION_METHOD in
    appstore)
        print_header "Next Steps - App Store Distribution"
        echo "1. Upload to App Store Connect:"
        echo "   - Use Xcode: Window → Organizer → Select Archive → Distribute App"
        echo "   - Or use Transporter app"
        echo ""
        echo "2. Alternatively, use command line:"
        echo "   xcrun altool --upload-app --type ios --file \"$IPA_FILE\" \\"
        echo "     --username \"your@email.com\" --password \"app-specific-password\""
        ;;
    adhoc)
        print_header "Next Steps - Ad Hoc Distribution"
        echo "1. Distribute IPA to registered test devices"
        echo "2. Install via:"
        echo "   - Xcode Devices window (drag & drop)"
        echo "   - iTunes/Finder"
        echo "   - OTA (over-the-air) using manifest plist"
        echo ""
        echo "3. For OTA distribution, update URLs in $EXPORT_OPTIONS_PATH"
        ;;
    development)
        print_header "Next Steps - Development Distribution"
        echo "1. Install on development devices via:"
        echo "   - Xcode Devices window"
        echo "   - Direct cable installation"
        echo ""
        echo "2. For debugging, use Xcode to run directly on device"
        ;;
    enterprise)
        print_header "Next Steps - Enterprise Distribution"
        echo "1. Upload IPA to your enterprise server"
        echo "2. Create distribution manifest plist"
        echo "3. Distribute download link to users"
        echo ""
        echo "4. Update URLs in $EXPORT_OPTIONS_PATH for OTA distribution"
        ;;
esac

echo ""
print_success "Done!"
