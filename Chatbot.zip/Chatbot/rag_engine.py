import json
from typing import List, Dict, Any
try:
    from sentence_transformers import SentenceTransformer
    EMBEDDINGS_AVAILABLE = True
except ImportError:
    EMBEDDINGS_AVAILABLE = False
    print("Warning: sentence-transformers not available, using basic search")
import numpy as np
from database import DatabaseManager
from config import Config


class RAGEngine:
    """Retrieval Augmented Generation Engine for Aerp.ai"""

    def __init__(self):
        self.config = Config()
        self.db_manager = DatabaseManager()
        self.embedding_model = None
        self.knowledge_base = []
        self.kb_ready = False
        self.embeddings = None

    def initialize(self):
        """Initialize the RAG engine"""
        print("Initializing RAG Engine...")

        # Load embedding model
        if EMBEDDINGS_AVAILABLE:
            try:
                self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
                print("Embedding model loaded")
            except Exception as e:
                print(f"Warning: Failed to load embedding model: {str(e)}")
                print("Continuing with basic search functionality")
                self.embedding_model = None
        else:
            print("Using basic search (embeddings not available)")
            self.embedding_model = None

        # Connect to database
        if not self.db_manager.connect():
            return False

        # Try to build knowledge base, but don't fail startup if it cannot be created
        try:
            self.build_knowledge_base()
        except Exception as e:
            # build_knowledge_base should be defensive already; this is a last-resort guard
            print(f"RAG KB build failed during initialize: {str(e)}")
            self.kb_ready = False

        return True

    def build_knowledge_base(self):
        """Build knowledge base from database schema and sample data"""
        print("Building knowledge base...")
        # Reset KB
        self.knowledge_base = []
        self.embeddings = None
        self.kb_ready = False

        # Get table schema and sample data. If the target table doesn't exist or
        # returns empty schema, don't raise — treat as 'KB unavailable' and continue.
        table_name = self.config.TARGET_TABLE
        schema = []
        try:
            schema = self.db_manager.get_table_schema(table_name) or []
        except Exception as e:
            # db layer already logs concise errors; record state and return
            print(f"KB: schema query failed for {table_name}: {str(e)}")

        if not schema:
            # No schema found — don't attempt to create KB from the configured table
            print(
                f"KB: no schema found for configured table '{table_name}'. Skipping KB build.")
            self.kb_ready = False
            # Provide a minimal hint entry so other parts of the app can show helpful help text
            hint = {
                'type': 'hint',
                'content': f"No schema available for {table_name}. RAG features are disabled until the table exists.",
                'metadata': {'table': table_name}
            }
            self.knowledge_base.append(hint)
            return

        # Get sample data (may be empty) — safe to call
        try:
            sample_data = self.db_manager.get_sample_data(
                table_name, limit=10) or []
        except Exception as e:
            print(f"KB: sample data query failed for {table_name}: {str(e)}")
            sample_data = []

        # Add schema information
        schema_text = f"Table {table_name} has the following columns: "
        try:
            schema_text += ", ".join(
                [f"{col.get('COLUMN_NAME')} ({col.get('DATA_TYPE')})" for col in schema])
        except Exception:
            # defensive join
            schema_text += str(schema)

        self.knowledge_base.append({
            'type': 'schema',
            'content': schema_text,
            'metadata': {'table': table_name}
        })

        # Add column descriptions
        for col in schema:
            try:
                col_name = col.get('COLUMN_NAME')
                data_type = col.get('DATA_TYPE')
                col_text = f"Column {col_name} in table {table_name} is of type {data_type}"
                self.knowledge_base.append({
                    'type': 'column',
                    'content': col_text,
                    'metadata': {'column': col_name, 'table': table_name}
                })
            except Exception:
                continue

        # Add sample data context
        if sample_data:
            sample_text = f"Sample data from {table_name}: {json.dumps(sample_data[:3], default=str)}"
            self.knowledge_base.append({
                'type': 'sample',
                'content': sample_text,
                'metadata': {'table': table_name}
            })

        # Generate embeddings if model available
        if self.embedding_model:
            try:
                texts = [entry['content'] for entry in self.knowledge_base]
                self.embeddings = self.embedding_model.encode(texts)
            except Exception as e:
                print(f"KB: failed to create embeddings: {str(e)}")
                self.embeddings = None

        self.kb_ready = True
        print(f"Knowledge base built with {len(self.knowledge_base)} entries")

    def retrieve_context(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """Retrieve relevant context from knowledge base"""
        if not self.embeddings or not self.knowledge_base:
            return []

        try:
            # Generate query embedding
            query_embedding = self.embedding_model.encode([query])[0]

            # Calculate cosine similarity
            similarities = np.dot(self.embeddings, query_embedding) / (
                np.linalg.norm(self.embeddings, axis=1) *
                np.linalg.norm(query_embedding)
            )

            # Get top-k most similar entries
            top_indices = np.argsort(similarities)[-top_k:][::-1]

            relevant_context = [self.knowledge_base[i] for i in top_indices]

            return relevant_context

        except Exception as e:
            print(f"Context retrieval failed: {str(e)}")
            return []

    def generate_response(self, user_query: str) -> Dict[str, Any]:
        """Generate intelligent response using RAG with real-time database queries"""
        try:
            # Check for conversational greetings
            if self._is_greeting(user_query):
                return self._generate_greeting_response(user_query)

            # Check for help/connectivity questions
            if self._is_help_query(user_query):
                return self._generate_help_response(user_query)

            # Check for quick action queries (View recent entries, etc.)
            if self._is_quick_action(user_query):
                return self._handle_quick_action(user_query)

            # Retrieve relevant context
            context = self.retrieve_context(user_query)

            # Execute real-time database query
            db_results = self.db_manager.execute_natural_language_query(
                user_query)

            # Generate intelligent summary based on query type and results
            summary = self._generate_intelligent_summary(
                user_query, db_results, context)

            # Format response
            response = {
                'success': True,
                'query': user_query,
                'context': context,
                'data': db_results,
                'summary': summary
            }

            return response

        except Exception as e:
            return {
                'success': False,
                'query': user_query,
                'error': str(e),
                'summary': f"I encountered an error while processing your query: {str(e)}",
                'data': []
            }

    def _is_greeting(self, query: str) -> bool:
        """Check if query is a greeting or casual conversation"""
        query_lower = query.lower().strip()
        greetings = [
            'hi', 'hello', 'hey', 'hiya', 'greetings', 'good morning', 'good afternoon',
            'good evening', 'howdy', 'hola', 'what\'s up', 'whats up', 'sup',
            'yo', 'hi there', 'hello there', 'hey there'
        ]

        # Casual responses
        casual = [
            'thanks', 'thank you', 'thankyou', 'thanku', 'thx', 'ty', 'appreciate',
            'bye', 'goodbye', 'regards', 'see you', 'later', 'cya',
            'ok', 'okay', 'cool', 'nice', 'great', 'awesome',
            'how are you', 'hows it going', 'whats new'
        ]

        # Check exact matches or if query starts with greeting/casual phrase
        all_patterns = greetings + casual
        # If the user typed a short greeting (1-4 words) treat as greeting.
        # If the input contains greeting words but also other content (e.g. "hello, how many leads"),
        # prefer to treat it as a data query so the bot can answer both.

        token_count = len(query_lower.split())
        if query_lower in all_patterns:
            return True

        # If the user typed a very short greeting (1-2 words) treat as greeting.
        if token_count <= 2 and any(query_lower.startswith(g) for g in all_patterns):
            return True

        # Otherwise don't classify as a pure greeting
        return False

    def _generate_greeting_response(self, query: str) -> Dict[str, Any]:
        """Generate friendly greeting response with database info"""
        import random

        query_lower = query.lower().strip()

        # Thank you responses
        if any(word in query_lower for word in ['thank', 'thx', 'ty', 'appreciate']):
            responses = [
                "You're welcome!",
                "Happy to help!",
                "Anytime! Let me know if you need anything else.",
                "My pleasure! Feel free to ask more questions."
            ]
            summary = random.choice(responses)

        # Goodbye responses
        elif any(word in query_lower for word in ['bye', 'goodbye', 'regards', 'see you', 'later', 'cya']):
            responses = [
                "Goodbye! Come back anytime!",
                "See you later! Have a great day!",
                "Take care! I'll be here when you need me!",
                "Bye! Feel free to return whenever you need help!",
                "Best regards! Happy to help anytime!"
            ]
            summary = random.choice(responses)

        # How are you responses
        elif any(word in query_lower for word in ['how are you', 'hows it going', 'whats new']):
            summary = "I'm doing great, thanks for asking! I'm ready to help you with your database queries. How can I assist you today?"

        # Positive feedback
        elif any(word in query_lower for word in ['ok', 'okay', 'cool', 'nice', 'great', 'awesome']):
            summary = "Glad to hear it! Is there anything else I can help you with?"

        # Standard greetings
        else:
            greetings_list = [
                "Hello!",
                "Hi there!",
                "Hey! Great to see you!",
                "Greetings!",
                "Hello! Welcome back!"
            ]

            greeting = random.choice(greetings_list)

            # Enrich greeting with quick database stats when available
            summary_lines = [
                greeting, "", "I'm Aerp.ai, your intelligent database assistant!", ""]
            try:
                table_name = self.config.TARGET_TABLE
                # Use the DatabaseManager helper to attempt a count (safe)
                count_query = f"SELECT COUNT(*) as total FROM {table_name}"
                result = self.db_manager.execute_query(count_query)
                record_count = None
                if result and isinstance(result, list) and len(result) and 'total' in result[0]:
                    record_count = result[0].get('total')

                if record_count is not None:
                    summary_lines.append(
                        f"Quick status: table {table_name} contains {record_count:,} rows.")
                else:
                    summary_lines.append(
                        "Quick status: table information not available.")

            except Exception:
                summary_lines.append(
                    "Quick status: table information not available.")

            summary_lines.append("")
            summary_lines.append(
                "How can I help you today? You can ask me to:")
            summary_lines.append("- Search for specific records")
            summary_lines.append("- View recent entries")
            summary_lines.append("- Get database statistics")
            summary_lines.append("- Ask questions about your data")
            summary_lines.append("- Or just chat with me!")

            summary = "\n".join(summary_lines)

        return {
            'success': True,
            'query': query,
            'data': [],
            'summary': summary
        }

    def _is_help_query(self, query: str) -> bool:
        """Check if query is asking for help or connectivity support (but not data queries)"""
        query_lower = query.lower()

        # Exclude data queries - these should go to database
        if any(word in query_lower for word in ['how many', 'count', 'show', 'list', 'get', 'find', 'search']):
            return False

        # Only match explicit help requests
        help_keywords = [
            'help me', 'need help', 'support', 'can\'t connect', 'cannot connect',
            'connection failed', 'connection error', 'setup guide', 'configure',
            'installation', 'how to connect', 'how do i', 'what can you',
            'guide', 'tutorial', 'problem connecting', 'issue with'
        ]
        return any(keyword in query_lower for keyword in help_keywords)

    def _is_quick_action(self, query: str) -> bool:
        """Check if query is a quick action button click"""
        query_lower = query.lower().strip()
        quick_actions = [
            'view recent entries', 'recent entries', 'show recent', 'latest records',
            'view recent records', 'show latest', 'recent data'
        ]
        return query_lower in quick_actions

    def _handle_quick_action(self, query: str) -> Dict[str, Any]:
        """Handle quick action queries"""
        query_lower = query.lower().strip()

        # View recent entries
        if any(keyword in query_lower for keyword in ['recent', 'latest']):
            try:
                # First, try to get some tables from the database
                tables_query = "SELECT TOP 5 TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME"
                tables = self.db_manager.execute_query(tables_query)

                if tables:
                    # Get a sample from the first available table
                    first_table = f"[{tables[0]['TABLE_SCHEMA']}].[{tables[0]['TABLE_NAME']}]"
                    sample_query = f"SELECT TOP 10 * FROM {first_table}"
                    records = self.db_manager.execute_query(sample_query)

                    if records:
                        summary = f"📋 **Recent Entries**\n\n"
                        summary += f"Showing **{len(records)} records** from **{first_table}**\n\n"
                        summary += f"**Available Tables** (showing first 5):\n"
                        for t in tables:
                            summary += f"  • {t['TABLE_SCHEMA']}.{t['TABLE_NAME']}\n"

                        return {
                            'success': True,
                            'query': query,
                            'data': records,
                            'summary': summary
                        }

                # Fallback if no tables found
                return {
                    'success': True,
                    'query': query,
                    'data': [],
                    'summary': "ℹ️ **No Data Available**\n\nI couldn't find any accessible tables in the current database.\n\nTry asking:\n• \"How many tables in database absolutebook_2172?\"\n• \"How many leads in database absolutebook_2172?\""
                }
            except Exception as e:
                return {
                    'success': True,
                    'query': query,
                    'data': [],
                    'summary': f"ℹ️ **Quick Search Available**\n\nI can help you query specific databases:\n\n• \"How many tables in database absolutebook_2172?\"\n• \"How many leads in database absolutebook_2172?\"\n• \"Show me database statistics\"\n\nWhat would you like to know?"
                }

        # Default fallback
        return {
            'success': True,
            'query': query,
            'data': [],
            'summary': "ℹ️ I can help you with:\n- View recent records from your database\n- Count tables and records\n- Search for specific data\n\nWhat would you like to know?"
        }

    def _generate_help_response(self, query: str) -> Dict[str, Any]:
        """Generate helpful response for connectivity and general questions"""
        query_lower = query.lower()

        # Database connectivity help
        if 'connect' in query_lower or 'connection' in query_lower or 'database' in query_lower:
            summary = """**Database Connection Help**

I can help you with database connectivity! Here are common solutions:

**1. Check Database Server**
   - Ensure SQL Server is running
   - Verify network connectivity to the server
   - Check firewall settings

**2. Verify Credentials**
   - Check your .env file for correct credentials
   - Ensure database name is correct
   - Verify user permissions

**3. ODBC Driver**
   - Install ODBC Driver 17 for SQL Server
   - Download from Microsoft's website

**4. Connection String**
   - Server: Check IP address or hostname
   - Database: Verify database name
   - Authentication: Windows or SQL Server auth

Need specific help? Ask me about any of these topics!"""

        # Support/Talk to human
        elif 'support' in query_lower or 'human' in query_lower or 'talk' in query_lower:
            summary = """**Support Options**

I'm here to help! Here's how you can get assistance:

**1. Database Queries**
   - Ask me to search for specific data
   - Request table information
   - Get record counts and statistics

**2. Technical Support**
   - Connection issues
   - Configuration help
   - Error troubleshooting

**3. Contact Information**
   - Email: support@aerp.ai
   - Documentation: See INSTALLATION_GUIDE.md
   - GitHub: Check the repository for issues

How can I assist you today?"""

        # General help
        else:
            summary = """**Welcome to Aerp.ai! 🤖**

I'm your intelligent database assistant. Here's what I can do:

**📊 Database Operations**
   - Search and retrieve records
   - View table information
   - Get statistics and counts
   - Filter and query data

**🔧 Technical Help**
   - Database connectivity support
   - Configuration assistance
   - Error troubleshooting

**💡 Quick Actions**
   - "Show me recent records"
   - "How many records are there?"
   - "Help me connect to database"
   - "Search for [specific data]"

Just ask me anything about your database!"""

        return {
            'success': True,
            'query': query,
            'data': [],
            'summary': summary
        }

    def _generate_intelligent_summary(self, query: str, results: List[Dict], context: List[Dict]) -> str:
        """Generate an intelligent, context-aware natural language summary"""
        query_lower = query.lower()

        # Handle error responses
        if results and isinstance(results[0], dict) and 'error' in results[0]:
            error_msg = results[0]['error']
            if 'not found' in error_msg:
                return f"❌ {error_msg.capitalize()}. Please verify the database name and try again."
            return f"❌ Error: {error_msg}"

        # Handle empty results
        if not results:
            return "❓ I couldn't find any results for your query. Try rephrasing or asking about available databases/tables."

        # Handle "how many tables" queries
        if 'tables' in query_lower and any(r.get('metric') == 'tables' for r in results):
            for r in results:
                if r.get('metric') == 'tables':
                    count = r.get('count', 0)
                    db_name = r.get('database', 'the database')
                    return f"📊 **Database Information**\n\nThere are **{count} tables** in {db_name}."

        # Handle "how many leads" or lead-related queries
        if 'lead' in query_lower:
            total_leads = 0
            table_details = []
            db_name = None

            for r in results:
                if r.get('metric') == 'leads':
                    count = r.get('count')
                    table = r.get('table', 'unknown')
                    db_name = r.get('database', db_name)

                    if count is not None:
                        total_leads += count
                        table_details.append(
                            f"  • **{table}**: {count:,} records")
                    elif 'note' in r:
                        return f"ℹ️ {r['note']}"

            if table_details:
                db_info = f" in database **{db_name}**" if db_name else ""
                summary = f"📈 **Lead Records Summary**{db_info}\n\n"
                summary += f"**Total Lead Records**: {total_leads:,}\n\n"
                summary += "**Breakdown by Table**:\n" + \
                    "\n".join(table_details)
                return summary

        # Handle "count rows" queries
        if 'count' in query_lower or 'rows' in query_lower:
            for r in results:
                if r.get('metric') == 'rows':
                    count = r.get('count', 0)
                    table = r.get('table', 'table')
                    db_name = r.get('database')
                    db_info = f" in database **{db_name}**" if db_name else ""
                    return f"📊 Table **{table}**{db_info} contains **{count:,} rows**."

        # Generic result summary
        result_count = len(results)

        # Check if results have recognizable structure
        if results and isinstance(results[0], dict):
            # Check for metric/count structure
            if 'metric' in results[0] and 'count' in results[0]:
                items = []
                for r in results:
                    metric = r.get('metric', 'items')
                    count = r.get('count', 0)
                    items.append(f"  • {metric}: {count:,}")
                return f"📊 **Query Results**:\n\n" + "\n".join(items)

            # Regular data records
            if result_count == 1:
                return f"✅ Found **1 record** matching your query."
            else:
                return f"✅ Found **{result_count} records** matching your query."

        # Fallback
        return f"ℹ️ Query executed successfully. Found {result_count} result(s)."

    def _generate_summary(self, query: str, results: List[Dict], context: List[Dict]) -> str:
        """Legacy summary method - redirects to intelligent summary"""
        return self._generate_intelligent_summary(query, results, context)

    def search_database(self, search_term: str, columns: List[str] = None) -> List[Dict[str, Any]]:
        """Search database with specific term"""
        return self.db_manager.search_records(
            self.config.TARGET_TABLE,
            search_term,
            columns
        )

    def get_table_info(self) -> Dict[str, Any]:
        """Get information about the target table"""
        table_name = self.config.TARGET_TABLE
        return {
            'table_name': table_name,
            'schema': self.db_manager.get_table_schema(table_name),
            'sample_data': self.db_manager.get_sample_data(table_name, limit=3)
        }
