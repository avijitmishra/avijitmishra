# Plesk Server Deployment - Summary

## ✅ Deployment Files Created

### Production Server Files
1. **wsgi_production.py** - WSGI entry point for production
2. **passenger_wsgi.py** - Plesk Passenger configuration
3. **gunicorn_config.py** - Gunicorn server configuration
4. **requirements_production.txt** - Production dependencies

### Startup & Control Scripts
5. **start_production.sh** - Start the server
6. **stop_production.sh** - Stop the server
7. **restart_production.sh** - Restart the server
8. **check_status.sh** - Check server status

### Service Configuration
9. **systemd_service.txt** - Systemd service configuration
10. **supervisor_config.txt** - Supervisor configuration

### Documentation
11. **PLESK_DEPLOYMENT_GUIDE.md** - Complete deployment guide
12. **DEPLOYMENT_CHECKLIST.md** - Step-by-step checklist

---

## 🎯 Server Information

- **URL:** http://156.67.110.254:8880/
- **IP:** 156.67.110.254
- **SSH Port:** 15987
- **User:** sshuser
- **Application Port:** 8000

---

## 🚀 Quick Deployment Steps

### 1. Upload Files
```bash
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

### 2. SSH to Server
```bash
ssh sshuser@156.67.110.254 -p 15987
cd ~/chatbot
```

### 3. Setup Environment
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements_production.txt
chmod +x *.sh
mkdir -p logs
```

### 4. Configure .env
```bash
nano .env
# Add your database credentials
```

### 5. Start Server
```bash
./start_production.sh
```

### 6. Verify Running
```bash
./check_status.sh
curl http://localhost:8000/api/health
```

---

## 🔄 Keeping Server Running Permanently

### Recommended: Supervisor

```bash
# Install
sudo apt-get install supervisor

# Configure
sudo cp supervisor_config.txt /etc/supervisor/conf.d/aerp-chatbot.conf
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start aerp-chatbot

# Verify
sudo supervisorctl status aerp-chatbot
```

**Benefits:**
- ✅ Auto-starts on server boot
- ✅ Auto-restarts if crashes
- ✅ Easy to manage
- ✅ Built-in logging

---

## 📊 Server Features

### Automatic Restart
- Server automatically restarts if it crashes
- Configured in supervisor/systemd
- Restart delay: 10 seconds

### Logging
- Application logs: `logs/nohup.log`
- Gunicorn access: `logs/gunicorn_access.log`
- Gunicorn errors: `logs/gunicorn_error.log`
- Service logs: `logs/service.log`

### Performance
- Multi-worker configuration
- Auto-scales based on CPU cores
- Formula: (2 × CPU cores) + 1
- Timeout: 300 seconds
- Max requests per worker: 1000

### Security
- Input sanitization enabled
- SQL injection prevention
- XSS protection
- Prompt injection detection
- Secure .env file (chmod 600)

---

## 🌐 Access Points

After deployment:

- **Health Check:** http://156.67.110.254:8000/api/health
- **Main UI:** http://156.67.110.254:8000/
- **cURL Test Page:** http://156.67.110.254:8000/curl
- **Query API:** http://156.67.110.254:8000/api/query?q=hello
- **Chat API:** http://156.67.110.254:8000/api/chat

---

## 🛠️ Management Commands

### Start/Stop/Restart
```bash
./start_production.sh    # Start server
./stop_production.sh     # Stop server
./restart_production.sh  # Restart server
./check_status.sh        # Check status
```

### Using Supervisor
```bash
sudo supervisorctl start aerp-chatbot
sudo supervisorctl stop aerp-chatbot
sudo supervisorctl restart aerp-chatbot
sudo supervisorctl status aerp-chatbot
```

### View Logs
```bash
tail -f logs/nohup.log
tail -f logs/gunicorn_access.log
tail -f logs/gunicorn_error.log
```

---

## 🔍 Monitoring

### Check if Running
```bash
./check_status.sh
```

### Check Processes
```bash
ps aux | grep gunicorn
```

### Check Port
```bash
netstat -tlnp | grep 8000
```

### Test Endpoints
```bash
curl http://localhost:8000/api/health
curl "http://localhost:8000/api/query?q=hello"
```

---

## 🐛 Troubleshooting

### Server Won't Start
```bash
# Check logs
tail -f logs/nohup.log

# Check if port is in use
netstat -tlnp | grep 8000

# Kill existing processes
sudo fuser -k 8000/tcp
```

### Database Connection Issues
```bash
# Test connection
python -c "from database import DatabaseManager; db = DatabaseManager(); print(db.connect())"

# Check .env
cat .env
```

### Permission Issues
```bash
# Fix ownership
sudo chown -R sshuser:sshuser ~/chatbot

# Fix permissions
chmod -R 755 ~/chatbot
chmod 600 .env
chmod +x *.sh
```

---

## 📝 Important Notes

### Environment Variables
Ensure `.env` file contains:
```env
DB_SERVER=192.168.1.167
DB_NAME=absolutebook_2172
DB_USER=sa
DB_PASSWORD=?P1t8@6in4R
DB_TIMEOUT=200
FLASK_PORT=8000
```

### Firewall
If external access doesn't work:
```bash
sudo ufw allow 8000/tcp
sudo ufw reload
```

### Updates
To update the application:
```bash
./stop_production.sh
git pull  # or upload new files
source venv/bin/activate
pip install -r requirements_production.txt
./start_production.sh
```

---

## ✅ Post-Deployment Checklist

- [ ] Server is running
- [ ] Health endpoint responds
- [ ] Chat endpoint works
- [ ] External access works
- [ ] Logs are being written
- [ ] Auto-restart configured
- [ ] Firewall configured
- [ ] .env file secured

---

## 📚 Documentation Files

- **PLESK_DEPLOYMENT_GUIDE.md** - Complete deployment instructions
- **DEPLOYMENT_CHECKLIST.md** - Step-by-step checklist
- **QUERYSTRING_API_GUIDE.md** - API documentation
- **GREETING_FIX_SUMMARY.md** - Greeting functionality
- **QUERYSTRING_SUMMARY.md** - Query string endpoint

---

## 🎉 Success Criteria

Your deployment is successful when:

1. ✅ Server starts without errors
2. ✅ Health endpoint returns `{"status": "healthy"}`
3. ✅ Chat endpoint responds to queries
4. ✅ Server survives SSH disconnect
5. ✅ Server restarts automatically after crash
6. ✅ Logs are being written
7. ✅ External access works

---

## 🆘 Support

If you encounter issues:

1. Check `PLESK_DEPLOYMENT_GUIDE.md` for detailed instructions
2. Review logs in `logs/` directory
3. Run `./check_status.sh` for diagnostics
4. Verify `.env` configuration
5. Check firewall settings

---

## 🔐 Security Recommendations

1. ✅ Keep `.env` file secure (chmod 600)
2. ✅ Use firewall to restrict access
3. ✅ Keep dependencies updated
4. ✅ Monitor logs regularly
5. ✅ Consider SSL certificate for production
6. ✅ Regular backups

---

## 📞 Quick Reference

**Server:** 156.67.110.254:8000  
**SSH:** ssh sshuser@156.67.110.254 -p 15987  
**Start:** ./start_production.sh  
**Stop:** ./stop_production.sh  
**Status:** ./check_status.sh  
**Logs:** tail -f logs/nohup.log  

---

Your Aerp.ai chatbot is now ready for production deployment on Plesk server!
