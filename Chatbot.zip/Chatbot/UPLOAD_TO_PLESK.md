# Upload to Plesk Server - Quick Guide

## Before You Start

**Server Details:**
- IP: 156.67.110.254
- Port: 15987
- User: sshuser
- Application Port: 8000

---

## Step 1: Clean Up Files

Run the cleanup script to remove unnecessary files:

**Windows:**
```cmd
cleanup_for_plesk.bat
```

**Linux/Mac:**
```bash
chmod +x cleanup_for_plesk.sh
./cleanup_for_plesk.sh
```

This will:
- Remove IIS-specific files (not needed for Linux)
- Remove development/testing files
- Remove build files
- Remove old documentation
- Create backup in `backup/` folder
- Create `README.md` from `README_PLESK.md`

---

## Step 2: Essential Files to Upload

After cleanup, you'll have these essential files:

### Core Application (Required)
- `app.py` - Main Flask application
- `config.py` - Configuration management
- `database.py` - Database handler
- `rag_engine.py` - RAG engine

### Production Server (Required)
- `wsgi_production.py` - WSGI entry point
- `passenger_wsgi.py` - Plesk Passenger config
- `gunicorn_config.py` - Gunicorn configuration
- `requirements_production.txt` - Dependencies

### Management Scripts (Required)
- `start_production.sh` - Start server
- `stop_production.sh` - Stop server
- `restart_production.sh` - Restart server
- `check_status.sh` - Check status

### Service Configuration (Required)
- `supervisor_config.txt` - Supervisor config
- `systemd_service.txt` - Systemd service

### Frontend (Required)
- `static/` folder - All frontend files
  - `index.html`
  - `curl_test.html`
  - `script.js`
  - `styles.css`

### Configuration (Required)
- `.env.example` - Environment template
- `.gitignore` - Git ignore rules

### Documentation (Recommended)
- `README.md` - Main documentation
- `PLESK_DEPLOYMENT_GUIDE.md` - Detailed guide
- `DEPLOYMENT_CHECKLIST.md` - Checklist
- `QUERYSTRING_API_GUIDE.md` - API reference
- `SECURITY_FEATURES.md` - Security docs

---

## Step 3: Upload Files

### Option A: Using SCP (Recommended)

**Upload all files:**
```bash
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

**Upload specific folders:**
```bash
# Core files
scp -P 15987 d:\Chatbot\*.py sshuser@156.67.110.254:~/chatbot/

# Scripts
scp -P 15987 d:\Chatbot\*.sh sshuser@156.67.110.254:~/chatbot/

# Static files
scp -P 15987 -r d:\Chatbot\static sshuser@156.67.110.254:~/chatbot/

# Config files
scp -P 15987 d:\Chatbot\*.txt sshuser@156.67.110.254:~/chatbot/
scp -P 15987 d:\Chatbot\.env.example sshuser@156.67.110.254:~/chatbot/
```

### Option B: Using SFTP

```bash
sftp -P 15987 sshuser@156.67.110.254

# Once connected:
cd chatbot
put -r *
exit
```

### Option C: Using FileZilla (GUI)

1. Open FileZilla
2. Host: `sftp://156.67.110.254`
3. Username: `sshuser`
4. Password: (your password)
5. Port: `15987`
6. Click "Quickconnect"
7. Navigate to `/home/sshuser/chatbot`
8. Drag and drop files from local to remote

### Option D: Using WinSCP (Windows GUI)

1. Open WinSCP
2. File protocol: `SFTP`
3. Host name: `156.67.110.254`
4. Port: `15987`
5. User name: `sshuser`
6. Password: (your password)
7. Click "Login"
8. Navigate to `/home/sshuser/chatbot`
9. Upload files

---

## Step 4: SSH to Server

```bash
ssh sshuser@156.67.110.254 -p 15987
cd ~/chatbot
```

---

## Step 5: Quick Setup

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements_production.txt

# Make scripts executable
chmod +x *.sh

# Create logs directory
mkdir -p logs

# Configure environment
cp .env.example .env
nano .env
# Edit with your database credentials
```

---

## Step 6: Configure .env File

Edit `.env` with your database details:

```env
DB_SERVER=192.168.1.167
DB_NAME=absolutebook_2172
DB_USER=sa
DB_PASSWORD=?P1t8@6in4R
DB_TIMEOUT=200
FLASK_PORT=8000
TARGET_TABLE=dbo.Leads
```

Save: `Ctrl+X`, then `Y`, then `Enter`

---

## Step 7: Start Server

```bash
./start_production.sh
```

---

## Step 8: Verify

```bash
# Check status
./check_status.sh

# Test health
curl http://localhost:8000/api/health

# Test chat
curl "http://localhost:8000/api/query?q=hello"
```

---

## Step 9: Setup Auto-Restart (Recommended)

### Using Supervisor:

```bash
# Install
sudo apt-get install supervisor

# Configure
sudo cp supervisor_config.txt /etc/supervisor/conf.d/aerp-chatbot.conf

# Update paths in config if needed
sudo nano /etc/supervisor/conf.d/aerp-chatbot.conf

# Reload and start
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start aerp-chatbot

# Check status
sudo supervisorctl status aerp-chatbot
```

---

## Step 10: Test External Access

From your local machine:

```bash
curl http://156.67.110.254:8000/api/health
```

Or open in browser:
```
http://156.67.110.254:8000/
```

---

## File Size Reference

Total upload size (after cleanup): ~50-100 MB

Breakdown:
- Python files: ~100 KB
- Static files: ~50 KB
- Virtual environment: (created on server)
- Dependencies: (installed on server)

---

## Troubleshooting Upload

### Connection Refused
```bash
# Check if SSH port is correct
ssh -p 15987 sshuser@156.67.110.254

# Try with verbose mode
ssh -v -p 15987 sshuser@156.67.110.254
```

### Permission Denied
```bash
# Check file permissions locally
ls -la d:\Chatbot\

# After upload, fix on server
ssh sshuser@156.67.110.254 -p 15987
chmod -R 755 ~/chatbot
chmod 600 ~/chatbot/.env
chmod +x ~/chatbot/*.sh
```

### Upload Interrupted
```bash
# Resume with rsync (if available)
rsync -avz -e "ssh -p 15987" d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

---

## Quick Commands Reference

```bash
# Upload
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/

# SSH
ssh sshuser@156.67.110.254 -p 15987

# Setup
cd ~/chatbot
python3 -m venv venv
source venv/bin/activate
pip install -r requirements_production.txt
chmod +x *.sh
mkdir -p logs
cp .env.example .env
nano .env

# Start
./start_production.sh

# Check
./check_status.sh
curl http://localhost:8000/api/health
```

---

## Next Steps

After successful upload and deployment:

1. ✅ Verify server is running
2. ✅ Test all API endpoints
3. ✅ Setup supervisor for auto-restart
4. ✅ Configure firewall
5. ✅ Setup SSL (optional)
6. ✅ Configure backups
7. ✅ Monitor logs

See `README.md` for detailed documentation.

---

## Support

For detailed instructions, see:
- `README.md` - Main documentation
- `PLESK_DEPLOYMENT_GUIDE.md` - Complete deployment guide
- `DEPLOYMENT_CHECKLIST.md` - Step-by-step checklist

---

**Ready to deploy!** 🚀
