# Plesk Server Deployment Checklist

## Pre-Deployment

- [ ] Verify server access: `ssh sshuser@156.67.110.254 -p 15987`
- [ ] Confirm Python 3.8+ installed: `python3 --version`
- [ ] Database credentials ready
- [ ] `.env` file configured with correct database details
- [ ] All files ready for upload

## File Upload

- [ ] Upload all files to server
- [ ] Verify all scripts are present
- [ ] Check `.env` file is uploaded
- [ ] Confirm `requirements_production.txt` is present

## Server Setup

- [ ] Create virtual environment: `python3 -m venv venv`
- [ ] Activate venv: `source venv/bin/activate`
- [ ] Install dependencies: `pip install -r requirements_production.txt`
- [ ] Make scripts executable: `chmod +x *.sh`
- [ ] Create logs directory: `mkdir -p logs`

## Testing

- [ ] Test application: `python wsgi_production.py`
- [ ] Test health endpoint: `curl http://localhost:8000/api/health`
- [ ] Test chat endpoint: `curl "http://localhost:8000/api/query?q=hello"`
- [ ] Verify database connection works

## Production Deployment

Choose ONE method:

### Option 1: Supervisor (Recommended)
- [ ] Install supervisor: `sudo apt-get install supervisor`
- [ ] Copy config: `sudo cp supervisor_config.txt /etc/supervisor/conf.d/aerp-chatbot.conf`
- [ ] Update paths in config file
- [ ] Reload supervisor: `sudo supervisorctl reread && sudo supervisorctl update`
- [ ] Start service: `sudo supervisorctl start aerp-chatbot`
- [ ] Verify running: `sudo supervisorctl status aerp-chatbot`

### Option 2: Systemd
- [ ] Copy service: `sudo cp systemd_service.txt /etc/systemd/system/aerp-chatbot.service`
- [ ] Update paths in service file
- [ ] Reload systemd: `sudo systemctl daemon-reload`
- [ ] Enable service: `sudo systemctl enable aerp-chatbot`
- [ ] Start service: `sudo systemctl start aerp-chatbot`
- [ ] Verify running: `sudo systemctl status aerp-chatbot`

### Option 3: Simple Start Script
- [ ] Run: `./start_production.sh`
- [ ] Verify running: `./check_status.sh`

## Post-Deployment Verification

- [ ] Server is running: `./check_status.sh`
- [ ] Health check works: `curl http://localhost:8000/api/health`
- [ ] Chat works: `curl "http://localhost:8000/api/query?q=hello"`
- [ ] External access works: `curl "http://156.67.110.254:8000/api/health"`
- [ ] Logs are being written: `tail -f logs/nohup.log`
- [ ] Auto-restart works (kill process and check if it restarts)

## Security

- [ ] Configure firewall: `sudo ufw allow 8000/tcp`
- [ ] Secure .env file: `chmod 600 .env`
- [ ] Review gunicorn_config.py settings
- [ ] Consider SSL certificate if using domain

## Monitoring

- [ ] Set up log rotation
- [ ] Configure backup script
- [ ] Test restart script: `./restart_production.sh`
- [ ] Document access URLs

## Final Steps

- [ ] Document deployment date and version
- [ ] Share access URLs with team
- [ ] Set up monitoring/alerts (optional)
- [ ] Schedule regular maintenance

## Access URLs

After deployment, your application will be available at:

- Health: http://156.67.110.254:8000/api/health
- Main UI: http://156.67.110.254:8000/
- cURL Test: http://156.67.110.254:8000/curl
- API: http://156.67.110.254:8000/api/query?q=hello

## Quick Commands Reference

```bash
# Start
./start_production.sh

# Stop
./stop_production.sh

# Restart
./restart_production.sh

# Status
./check_status.sh

# Logs
tail -f logs/nohup.log
```

## Troubleshooting

If something goes wrong:

1. Check logs: `tail -f logs/nohup.log`
2. Check status: `./check_status.sh`
3. Verify port: `netstat -tlnp | grep 8000`
4. Test database: `python -c "from database import DatabaseManager; db = DatabaseManager(); print(db.connect())"`
5. Review deployment guide: `PLESK_DEPLOYMENT_GUIDE.md`

## Support

For detailed instructions, see `PLESK_DEPLOYMENT_GUIDE.md`
