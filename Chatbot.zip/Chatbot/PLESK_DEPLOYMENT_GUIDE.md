# Plesk Server Deployment Guide - Aerp.ai Chatbot

## Server Information
- **URL:** http://156.67.110.254:8880/
- **IP:** 156.67.110.254
- **Port:** 15987
- **User:** sshuser

---

## 📋 Pre-Deployment Checklist

- [ ] Server access credentials verified
- [ ] Python 3.8+ installed on server
- [ ] Database connection details configured in `.env`
- [ ] All required files uploaded
- [ ] Firewall allows port 8000 (or your chosen port)

---

## 🚀 Deployment Steps

### Step 1: Connect to Plesk Server

```bash
ssh sshuser@156.67.110.254 -p 15987
```

### Step 2: Create Application Directory

```bash
mkdir -p ~/chatbot
cd ~/chatbot
```

### Step 3: Upload Files

**Option A: Using SCP (from your local machine)**
```bash
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

**Option B: Using SFTP**
```bash
sftp -P 15987 sshuser@156.67.110.254
cd chatbot
put -r *
```

**Option C: Using Git (recommended)**
```bash
# On server
cd ~/chatbot
git clone <your-repository-url> .
```

### Step 4: Configure Environment

```bash
cd ~/chatbot

# Copy environment template
cp .env.example .env

# Edit with your database credentials
nano .env
```

**Update `.env` file:**
```env
DB_SERVER=192.168.1.167
DB_NAME=absolutebook_2172
DB_USER=sa
DB_PASSWORD=?P1t8@6in4R
DB_TIMEOUT=200
FLASK_PORT=8000
```

### Step 5: Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 6: Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements_production.txt
```

### Step 7: Make Scripts Executable

```bash
chmod +x start_production.sh
chmod +x stop_production.sh
chmod +x restart_production.sh
chmod +x check_status.sh
```

### Step 8: Create Logs Directory

```bash
mkdir -p logs
```

### Step 9: Test the Application

```bash
# Quick test
python wsgi_production.py

# If it works, press Ctrl+C and proceed to production start
```

### Step 10: Start Production Server

```bash
./start_production.sh
```

---

## 🔄 Keeping Server Running Permanently

### Option 1: Using Supervisor (Recommended for Plesk)

#### Install Supervisor
```bash
sudo apt-get update
sudo apt-get install supervisor
```

#### Configure Supervisor
```bash
# Copy configuration
sudo cp supervisor_config.txt /etc/supervisor/conf.d/aerp-chatbot.conf

# Edit paths if needed
sudo nano /etc/supervisor/conf.d/aerp-chatbot.conf

# Update supervisor
sudo supervisorctl reread
sudo supervisorctl update

# Start the service
sudo supervisorctl start aerp-chatbot
```

#### Supervisor Commands
```bash
# Status
sudo supervisorctl status aerp-chatbot

# Start
sudo supervisorctl start aerp-chatbot

# Stop
sudo supervisorctl stop aerp-chatbot

# Restart
sudo supervisorctl restart aerp-chatbot

# View logs
sudo supervisorctl tail -f aerp-chatbot
```

### Option 2: Using Systemd

#### Install Service
```bash
# Copy service file
sudo cp systemd_service.txt /etc/systemd/system/aerp-chatbot.service

# Edit paths if needed
sudo nano /etc/systemd/system/aerp-chatbot.service

# Reload systemd
sudo systemctl daemon-reload

# Enable service (start on boot)
sudo systemctl enable aerp-chatbot

# Start service
sudo systemctl start aerp-chatbot
```

#### Systemd Commands
```bash
# Status
sudo systemctl status aerp-chatbot

# Start
sudo systemctl start aerp-chatbot

# Stop
sudo systemctl stop aerp-chatbot

# Restart
sudo systemctl restart aerp-chatbot

# View logs
sudo journalctl -u aerp-chatbot -f
```

### Option 3: Using Screen (Simple Alternative)

```bash
# Install screen
sudo apt-get install screen

# Start a screen session
screen -S aerp-chatbot

# Run the application
./start_production.sh

# Detach from screen: Press Ctrl+A, then D

# Reattach to screen
screen -r aerp-chatbot

# List screens
screen -ls
```

### Option 4: Using Nohup (Basic)

```bash
# Already included in start_production.sh
# The script uses nohup to keep running after logout
./start_production.sh

# Check if running
./check_status.sh
```

---

## 🔧 Configuration for Plesk

### Plesk Python Application Setup

1. **Log into Plesk Panel**
   - Go to: http://156.67.110.254:8880/

2. **Create Python Application**
   - Websites & Domains → Python
   - Click "Enable Python"
   - Application root: `/home/sshuser/chatbot`
   - Application URL: `/` or `/chatbot`
   - Application startup file: `passenger_wsgi.py`
   - Python version: 3.8 or higher

3. **Set Environment Variables in Plesk**
   - Add all variables from `.env` file
   - Or ensure `.env` file is readable

4. **Restart Application**
   - Click "Restart App" in Plesk panel

---

## 🌐 Nginx/Apache Configuration

### For Nginx (if using)

Create `/etc/nginx/sites-available/aerp-chatbot`:

```nginx
server {
    listen 80;
    server_name 156.67.110.254;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # WebSocket support (if needed)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

Enable and restart:
```bash
sudo ln -s /etc/nginx/sites-available/aerp-chatbot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### For Apache (if using)

Create `/etc/apache2/sites-available/aerp-chatbot.conf`:

```apache
<VirtualHost *:80>
    ServerName 156.67.110.254

    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:8000/
    ProxyPassReverse / http://127.0.0.1:8000/

    ErrorLog ${APACHE_LOG_DIR}/aerp-chatbot-error.log
    CustomLog ${APACHE_LOG_DIR}/aerp-chatbot-access.log combined
</VirtualHost>
```

Enable and restart:
```bash
sudo a2enmod proxy proxy_http
sudo a2ensite aerp-chatbot
sudo systemctl restart apache2
```

---

## 🔍 Monitoring & Maintenance

### Check Server Status

```bash
./check_status.sh
```

### View Logs

```bash
# Application logs
tail -f logs/nohup.log

# Gunicorn access logs
tail -f logs/gunicorn_access.log

# Gunicorn error logs
tail -f logs/gunicorn_error.log

# Supervisor logs (if using)
sudo tail -f /var/log/supervisor/aerp-chatbot-stdout.log
```

### Restart Server

```bash
./restart_production.sh
```

### Update Application

```bash
# Stop server
./stop_production.sh

# Pull latest changes (if using git)
git pull

# Install any new dependencies
source venv/bin/activate
pip install -r requirements_production.txt

# Start server
./start_production.sh
```

---

## 🔒 Security Recommendations

### 1. Firewall Configuration

```bash
# Allow SSH
sudo ufw allow 15987/tcp

# Allow HTTP
sudo ufw allow 80/tcp

# Allow HTTPS (if using SSL)
sudo ufw allow 443/tcp

# Allow application port (if direct access needed)
sudo ufw allow 8000/tcp

# Enable firewall
sudo ufw enable
```

### 2. SSL Certificate (Recommended)

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d yourdomain.com

# Auto-renewal is configured automatically
```

### 3. Secure .env File

```bash
chmod 600 .env
```

### 4. Update Dependencies Regularly

```bash
pip list --outdated
pip install --upgrade <package-name>
```

---

## 🐛 Troubleshooting

### Server Won't Start

```bash
# Check logs
tail -f logs/nohup.log
tail -f logs/gunicorn_error.log

# Check if port is in use
netstat -tlnp | grep 8000
# or
ss -tlnp | grep 8000

# Kill processes on port
sudo fuser -k 8000/tcp
```

### Database Connection Issues

```bash
# Test database connection
python -c "from database import DatabaseManager; db = DatabaseManager(); print(db.connect())"

# Check .env file
cat .env

# Verify database server is accessible
ping 192.168.1.167
telnet 192.168.1.167 1433
```

### Permission Issues

```bash
# Fix ownership
sudo chown -R sshuser:sshuser ~/chatbot

# Fix permissions
chmod -R 755 ~/chatbot
chmod 600 .env
```

### Memory Issues

```bash
# Check memory usage
free -h

# Check process memory
ps aux | grep gunicorn

# Reduce workers in gunicorn_config.py if needed
nano gunicorn_config.py
# Change: workers = 2
```

---

## 📊 Performance Optimization

### 1. Adjust Gunicorn Workers

Edit `gunicorn_config.py`:
```python
# Formula: (2 x CPU cores) + 1
workers = 5  # For 2 CPU cores

# Or use auto-detection (already configured)
import multiprocessing
workers = multiprocessing.cpu_count() * 2 + 1
```

### 2. Enable Caching (Optional)

```bash
pip install Flask-Caching
```

### 3. Use Gevent for Better Concurrency

Already included in `requirements_production.txt`

---

## 📞 Support & Maintenance

### Regular Maintenance Tasks

```bash
# Weekly: Check logs
./check_status.sh
tail -f logs/gunicorn_error.log

# Monthly: Update dependencies
source venv/bin/activate
pip list --outdated
pip install --upgrade <package>

# Monthly: Clean old logs
find logs/ -name "*.log" -mtime +30 -delete

# Quarterly: Review security
sudo apt-get update
sudo apt-get upgrade
```

### Backup Script

Create `backup.sh`:
```bash
#!/bin/bash
BACKUP_DIR=~/backups/chatbot
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/chatbot_$DATE.tar.gz \
    --exclude='venv' \
    --exclude='__pycache__' \
    --exclude='logs/*.log' \
    ~/chatbot
echo "Backup created: $BACKUP_DIR/chatbot_$DATE.tar.gz"
```

---

## ✅ Post-Deployment Verification

### 1. Check Server is Running
```bash
./check_status.sh
```

### 2. Test Health Endpoint
```bash
curl http://localhost:8000/api/health
```

### 3. Test Chat Endpoint
```bash
curl "http://localhost:8000/api/query?q=hello"
```

### 4. Test from External Network
```bash
# From your local machine
curl "http://156.67.110.254:8000/api/health"
```

### 5. Verify Auto-Restart
```bash
# Kill the process
sudo pkill -f gunicorn

# Wait 10 seconds
sleep 10

# Check if it restarted
./check_status.sh
```

---

## 🎯 Quick Reference Commands

```bash
# Start server
./start_production.sh

# Stop server
./stop_production.sh

# Restart server
./restart_production.sh

# Check status
./check_status.sh

# View logs
tail -f logs/nohup.log

# Test health
curl http://localhost:8000/api/health

# Test chat
curl "http://localhost:8000/api/query?q=hello"
```

---

## 📝 Important Files

- `passenger_wsgi.py` - Plesk/Passenger entry point
- `wsgi_production.py` - WSGI application
- `gunicorn_config.py` - Gunicorn configuration
- `start_production.sh` - Start script
- `stop_production.sh` - Stop script
- `restart_production.sh` - Restart script
- `check_status.sh` - Status check script
- `.env` - Environment variables (keep secure!)
- `requirements_production.txt` - Production dependencies

---

## 🎉 Deployment Complete!

Your Aerp.ai chatbot should now be running persistently on the Plesk server. The application will:

✅ Start automatically on server boot (if using systemd/supervisor)
✅ Restart automatically if it crashes
✅ Log all activity for debugging
✅ Handle multiple concurrent requests
✅ Remain running even after SSH disconnect

**Access your chatbot at:**
- Health Check: http://156.67.110.254:8000/api/health
- Main UI: http://156.67.110.254:8000/
- cURL Test Page: http://156.67.110.254:8000/curl
- API: http://156.67.110.254:8000/api/query?q=hello
