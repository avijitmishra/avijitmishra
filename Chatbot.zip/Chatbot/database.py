"""Database access layer with real pyodbc backend and in-memory mock fallback.

Provides a DatabaseManager class with a consistent API used by the app and
RAG engine. If pyodbc cannot be imported or a connection cannot be made, the
module falls back to a lightweight in-memory mock implementation so endpoints
can be tested without native ODBC drivers.
"""
from typing import List, Dict, Any, Optional
import traceback

try:
    import pyodbc  # type: ignore
    _PYODBC_AVAILABLE = True
except Exception:
    pyodbc = None  # type: ignore
    _PYODBC_AVAILABLE = False

from config import Config


class _MockDB:
    """Simple in-memory mock database implementation."""

    def __init__(self):
        self._mock_data = [
            {"SRC_UID": "SOME_SRC_UID", "id": 1,
                "name": "Sample Record", "notes": "This is mock data."},
            {"SRC_UID": "ABC123", "id": 2, "name": "Another Record",
                "notes": "More mock rows."},
            {"SRC_UID": "TEST123", "id": 3, "name": "Test Record",
                "notes": "Used for integration tests."}
        ]

    def connect(self) -> bool:
        print("pyodbc not available or not used - using mock database")
        return True

    def execute_query(self, query: str, params: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
        # Very small SQL-like support for simple queries used by the app
        q = (query or '').strip().lower()
        if 'information_schema.columns' in q:
            return [
                {"COLUMN_NAME": "SRC_UID", "DATA_TYPE": "varchar"},
                {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                {"COLUMN_NAME": "name", "DATA_TYPE": "varchar"},
                {"COLUMN_NAME": "notes", "DATA_TYPE": "varchar"},
            ]

        if 'count(' in q and 'from' in q:
            return [{"total": len(self._mock_data)}]

        if 'where' in q and 'src_uid' in q:
            # params expected: [src_uid]
            val = params[0] if params else None
            return [r for r in self._mock_data if r.get('SRC_UID') == val]

        # fallback: return top N or all
        return self._mock_data

    def execute_natural_language_query(self, nl_query: str) -> List[Dict[str, Any]]:
        """Very small rule-based NL handler for mock backend."""
        q = (nl_query or '').lower()
        # how many tables
        if 'how many tables' in q or 'number of tables' in q:
            # return a pretend table count based on known mock structures
            # We don't have a real catalog in the mock, so return a small number
            return [{'metric': 'tables', 'count': 5}]

        # how many leads (look for table names containing 'lead')
        if 'lead' in q:
            # pretend there is a table called 'leads' with 42 rows
            return [{'metric': 'leads', 'table': 'dbo.Leads', 'count': 42}]

        # fallback: return empty
        return []

    def get_table_schema(self, table_name: str) -> List[Dict[str, Any]]:
        return self.execute_query('')

    def get_sample_data(self, table_name: str, limit: int = 5) -> List[Dict[str, Any]]:
        return self._mock_data[:limit]

    def search_records(self, table_name: str, term: str, columns: Optional[List[str]] = None, limit: int = 50) -> List[Dict[str, Any]]:
        if not term:
            return self.get_sample_data(table_name, limit)
        term_l = term.lower()
        results = [r for r in self._mock_data if any(
            term_l in str(v).lower() for v in r.values())]
        return results[:limit]

    def get_record_by_src_uid(self, table_name: str, src_uid: str, src_column: str = 'SRC_UID') -> List[Dict[str, Any]]:
        return [r for r in self._mock_data if r.get(src_column) == src_uid]


class _PyODBCDB:
    """pyodbc-backed implementation."""

    def __init__(self, conn_str: Optional[str] = None):
        self.conn_str = conn_str or Config().connection_string
        self.cnxn = None
        self.cursor = None

    def connect(self) -> bool:
        try:
            self.cnxn = pyodbc.connect(self.conn_str, autocommit=True)
            self.cursor = self.cnxn.cursor()
            print(f"Connected to database: {Config().DB_NAME}")
            return True
        except Exception:
            print("pyodbc connection failed:\n" + traceback.format_exc())
            return False

    def execute_query(self, query: str, params: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)

            if not self.cursor.description:
                return []

            columns = [c[0] for c in self.cursor.description]
            rows = self.cursor.fetchall()
            return [dict(zip(columns, row)) for row in rows]
        except Exception as e:
            # Always log a concise, single-line message for query failures so
            # startup logs remain readable. If you need a full traceback for
            # debugging, set the environment variable DEBUG_SQL_TRACE=1.
            try:
                import os
                if os.getenv('DEBUG_SQL_TRACE'):
                    print("Query failed:\n" + traceback.format_exc())
                else:
                    print(f"Query failed: {e.__class__.__name__}: {str(e)}")
            except Exception:
                # Best-effort concise message
                print(f"Query failed: {str(e)}")

            return []

    def get_table_schema(self, table_name: str) -> List[Dict[str, Any]]:
        q = f"SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'"
        return self.execute_query(q)

    def get_sample_data(self, table_name: str, limit: int = 5) -> List[Dict[str, Any]]:
        q = f"SELECT TOP {limit} * FROM {table_name}"
        return self.execute_query(q)

    def search_records(self, table_name: str, term: str, columns: Optional[List[str]] = None, limit: int = 50) -> List[Dict[str, Any]]:
        if not columns:
            q = f"SELECT TOP {limit} * FROM {table_name}"
            return self.execute_query(q)
        else:
            where = ' OR '.join([f"[{c}] LIKE ?" for c in columns])
            params = ['%' + term + '%'] * len(columns)
            q = f"SELECT TOP {limit} * FROM {table_name} WHERE {where}"
            return self.execute_query(q, params)

    def get_record_by_src_uid(self, table_name: str, src_uid: str, src_column: str = 'SRC_UID') -> List[Dict[str, Any]]:
        q = f"SELECT * FROM {table_name} WHERE [{src_column}] = ?"
        return self.execute_query(q, [src_uid])

    def execute_natural_language_query(self, nl_query: str) -> List[Dict[str, Any]]:
        """Small rule-based NL handler for pyodbc backend.

        Recognizes:
        - "how many tables" / "number of tables"
        - "how many <something like leads>" (looks for tables with the word)
        Returns a list of dict results with keys like 'metric'/'count' or 'table'/'count'.
        """
        q_raw = nl_query or ''
        q = q_raw.lower()
        results = []
        try:
            # Optional: detect an explicit database name
            # patterns: "in database <name>", "in db <name>", "from database <name>"
            db_name: Optional[str] = None
            for key in ['in database', 'from database', 'in db']:
                if key in q:
                    after = q.split(key, 1)[1].strip()
                    # take first token up to space or punctuation
                    candidate = after.split()[0].strip().strip('?.!;,')
                    # remove quotes or brackets if any
                    candidate = candidate.strip("'\"")
                    db_name = candidate
                    break

            def _db_prefix(db: Optional[str]) -> str:
                return f"[{db}]." if db else ""

            # Validate database if provided
            if db_name:
                try:
                    self.cursor.execute(
                        "SELECT COUNT(*) FROM sys.databases WHERE name = ?", db_name)
                    r = self.cursor.fetchone()
                    if not r or int(r[0]) == 0:
                        return [{'error': f"database '{db_name}' not found", 'metric': 'db'}]
                except Exception:
                    # If validation fails, still attempt queries with prefix and let them fail gracefully
                    pass

            # how many tables in the current database
            if 'how many tables' in q or 'number of tables' in q:
                self.cursor.execute(
                    f"SELECT COUNT(*) AS total FROM {_db_prefix(db_name)}sys.tables")
                row = self.cursor.fetchone()
                total = int(row[0]) if row else 0
                out = {'metric': 'tables', 'count': total}
                if db_name:
                    out['database'] = db_name
                return [out]

            # how many leads (search for table names containing 'lead')
            if 'lead' in q:
                # find tables with 'lead' in the name
                self.cursor.execute(
                    f"SELECT s.name AS schema_name, t.name AS table_name FROM {_db_prefix(db_name)}sys.tables t "
                    f"JOIN {_db_prefix(db_name)}sys.schemas s ON t.schema_id = s.schema_id "
                    f"WHERE LOWER(t.name) LIKE '%lead%'"
                )
                tables = self.cursor.fetchall()
                if not tables:
                    out = {'metric': 'leads', 'count': 0,
                           'note': 'no tables with "lead" in name'}
                    if db_name:
                        out['database'] = db_name
                    return [out]

                # For each matching table, count rows
                out = []
                for t in tables:
                    schema_name = t.schema_name
                    table_name = t.table_name
                    fq = f"SELECT COUNT(*) AS total FROM {_db_prefix(db_name)}[{schema_name}].[{table_name}]"
                    try:
                        self.cursor.execute(fq)
                        r = self.cursor.fetchone()
                        cnt = int(r[0]) if r else 0
                    except Exception:
                        cnt = None
                    item = {'metric': 'leads',
                            'table': f'{schema_name}.{table_name}', 'count': cnt}
                    if db_name:
                        item['database'] = db_name
                    out.append(item)
                return out

            # generic: if query asks count of rows in a specific table 'count rows in <table>'
            if 'count' in q and 'in' in q:
                # attempt to extract a table name token after 'in'
                parts = q.split(' in ')
                if len(parts) > 1:
                    candidate = parts[1].strip().split()[0]
                    # try to count rows
                    try:
                        prefix = _db_prefix(db_name)
                        # allow schema-qualified candidate already
                        if '.' in candidate:
                            table_ref = candidate
                        else:
                            table_ref = f"dbo.{candidate}"
                        self.cursor.execute(
                            f"SELECT COUNT(*) FROM {prefix}{table_ref}")
                        r = self.cursor.fetchone()
                        cnt = int(r[0]) if r else 0
                        out = {'metric': 'rows',
                               'table': table_ref, 'count': cnt}
                        if db_name:
                            out['database'] = db_name
                        return [out]
                    except Exception:
                        err = {'error': f'failed to count rows in {candidate}'}
                        if db_name:
                            err['database'] = db_name
                        return [err]

        except Exception:
            return [{'error': 'nl query failed'}]

        return results


class DatabaseManager:
    """Facade that provides a stable API and chooses backend at runtime."""

    def __init__(self):
        self.config = Config()
        self._backend = None

        # Prefer real pyodbc backend if available and connection succeeds
        if _PYODBC_AVAILABLE:
            try:
                real = _PyODBCDB(self.config.connection_string)
                if real.connect():
                    self._backend = real
            except Exception:
                print(
                    "pyodbc backend initialization failed, falling back to mock:\n" + traceback.format_exc())

        if not self._backend:
            self._backend = _MockDB()
            self._backend.connect()

    # Delegate methods to the chosen backend
    def connect(self) -> bool:
        return True

    def execute_query(self, query: str, params: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
        return self._backend.execute_query(query, params)

    def get_table_schema(self, table_name: str) -> List[Dict[str, Any]]:
        return self._backend.get_table_schema(table_name)

    def get_sample_data(self, table_name: str, limit: int = 5) -> List[Dict[str, Any]]:
        return self._backend.get_sample_data(table_name, limit)

    def search_records(self, table_name: str, term: str, columns: Optional[List[str]] = None, limit: int = 50) -> List[Dict[str, Any]]:
        return self._backend.search_records(table_name, term, columns, limit)

    def get_record_by_src_uid(self, table_name: str, src_uid: str, src_column: str = 'SRC_UID') -> List[Dict[str, Any]]:
        return self._backend.get_record_by_src_uid(table_name, src_uid, src_column)

    def execute_natural_language_query(self, nl_query: str) -> List[Dict[str, Any]]:
        """Attempt to interpret a short natural language question and return data.

        This is intentionally small and rule-based: it recognizes requests like
        - "how many tables"
        - "how many leads"
        - "count rows in <table>"

        The method delegates to the chosen backend.
        """
        # Delegate to backend if implemented
        impl = getattr(self._backend, 'execute_natural_language_query', None)
        if callable(impl):
            return impl(nl_query)

        # Fallback: return empty
        return []

    def ping(self) -> (bool, str):
        """Quick health check: attempt a trivial query to validate connectivity.

        Returns (True, '') on success, or (False, error_message) on failure.
        """
        try:
            # A simple SELECT 1 that should work on SQL Server and other DBs
            res = self.execute_query('SELECT 1')
            # If execute_query returns rows or empty list but no exception, consider success
            return True, ''
        except Exception as e:
            return False, str(e)
