"""
WSGI Production Configuration for Plesk Server
This file ensures the Flask app runs persistently on Plesk
"""

import sys
import os

# Add the application directory to the Python path
app_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, app_dir)

# Import the Flask application
from app import app as application

# Configure for production
application.config['DEBUG'] = False
application.config['TESTING'] = False

# Ensure the app initializes on startup
if __name__ == "__main__":
    application.run()
