#!/bin/bash
# Stop Production Server Script

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}  Stopping Aerp.ai Chatbot Server${NC}"
echo -e "${YELLOW}========================================${NC}"

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Stop using PID file if it exists
if [ -f "logs/gunicorn.pid" ]; then
    PID=$(cat logs/gunicorn.pid)
    echo -e "${YELLOW}Stopping process with PID: $PID${NC}"
    kill $PID 2>/dev/null || true
    sleep 2
    
    # Force kill if still running
    if ps -p $PID > /dev/null 2>&1; then
        echo -e "${YELLOW}Force killing process...${NC}"
        kill -9 $PID 2>/dev/null || true
    fi
    
    rm -f logs/gunicorn.pid
fi

# Kill any remaining gunicorn processes
echo -e "${YELLOW}Killing any remaining gunicorn processes...${NC}"
pkill -f "gunicorn.*wsgi_production" || true

sleep 1

# Verify all processes are stopped
if pgrep -f "gunicorn.*wsgi_production" > /dev/null; then
    echo -e "${RED}Warning: Some processes may still be running${NC}"
    pgrep -f "gunicorn.*wsgi_production"
else
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}✓ Server stopped successfully${NC}"
    echo -e "${GREEN}========================================${NC}"
fi
