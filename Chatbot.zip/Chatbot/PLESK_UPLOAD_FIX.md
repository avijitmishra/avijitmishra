# Plesk Upload Error - Complete Fix

## ❌ Problem
Plesk File Manager cannot upload files starting with `.` (dotfiles) like `.env.example` and `.gitignore`

## ✅ Solution

### Option 1: Use SCP/SFTP (RECOMMENDED - Most Reliable)

This bypasses Plesk File Manager and uploads directly via SSH.

**Windows PowerShell:**
```powershell
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

**This will upload ALL files correctly, including dotfiles.**

---

### Option 2: Upload Without Dotfiles (Plesk File Manager)

If you must use Plesk File Manager, skip the dotfiles and create them manually on the server.

**Files to upload via Plesk (skip dotfiles):**
- ✅ app.py
- ✅ config.py
- ✅ database.py
- ✅ rag_engine.py
- ✅ wsgi_production.py
- ✅ passenger_wsgi.py
- ✅ gunicorn_config.py
- ✅ requirements_production.txt
- ✅ start_production.sh
- ✅ stop_production.sh
- ✅ restart_production.sh
- ✅ check_status.sh
- ✅ supervisor_config.txt
- ✅ systemd_service.txt
- ✅ All .md files
- ✅ static/ folder
- ❌ Skip: .env.example
- ❌ Skip: .gitignore

**Then SSH to server and create dotfiles manually:**

```bash
ssh sshuser@156.67.110.254 -p 15987
cd ~/chatbot

# Create .env file
cat > .env << 'EOF'
# Database Configuration
DB_SERVER=192.168.1.167
DB_NAME=absolutebook_2172
DB_USER=sa
DB_PASSWORD=?P1t8@6in4R
DB_TIMEOUT=200
DB_POOLING=True
DB_MAX_POOL_SIZE=500

# Flask Configuration
FLASK_PORT=8000
FLASK_DEBUG=False

# Target table for queries
TARGET_TABLE=dbo.Leads
EOF

# Create .gitignore (optional)
cat > .gitignore << 'EOF'
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
ENV/
.env
.vscode/
*.log
logs/
dist/
build/
*.egg-info/
.DS_Store
EOF

# Set permissions
chmod 600 .env
```

---

### Option 3: Rename Dotfiles (Already Done)

I've created copies without dots:
- `.env.example` → `env.example`
- `.gitignore` → `gitignore.txt`

**Upload these instead, then rename on server:**

```bash
ssh sshuser@156.67.110.254 -p 15987
cd ~/chatbot

# Rename back to dotfiles
mv env.example .env.example
mv gitignore.txt .gitignore

# Create .env from example
cp .env.example .env
nano .env  # Edit with your credentials
```

---

## 🚀 RECOMMENDED: Use SCP Method

This is the most reliable method and uploads everything correctly:

### Step 1: Open PowerShell on Windows

```powershell
cd d:\Chatbot
```

### Step 2: Upload All Files

```powershell
scp -P 15987 -r * sshuser@156.67.110.254:~/chatbot/
```

**Enter password when prompted**

### Step 3: SSH to Server

```bash
ssh sshuser@156.67.110.254 -p 15987
cd ~/chatbot
```

### Step 4: Verify Upload

```bash
ls -la
```

You should see all files including `.env.example` and `.gitignore`

### Step 5: Setup Environment

```bash
# Create .env from example
cp .env.example .env
nano .env
```

**Edit .env with your database credentials:**
```env
DB_SERVER=192.168.1.167
DB_NAME=absolutebook_2172
DB_USER=sa
DB_PASSWORD=?P1t8@6in4R
DB_TIMEOUT=200
FLASK_PORT=8000
TARGET_TABLE=dbo.Leads
```

Save: `Ctrl+X`, `Y`, `Enter`

### Step 6: Set Permissions

```bash
chmod +x *.sh
chmod 600 .env
```

### Step 7: Install Dependencies

```bash
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements_production.txt
```

### Step 8: Start Server

```bash
./start_production.sh
```

### Step 9: Verify

```bash
./check_status.sh
curl http://localhost:8000/api/health
```

---

## 🔧 Alternative: Use FileZilla

If SCP command doesn't work, use FileZilla GUI:

1. **Download FileZilla Client** (if not installed)
   - https://filezilla-project.org/download.php?type=client

2. **Open FileZilla**

3. **Connection Settings:**
   - Host: `sftp://156.67.110.254`
   - Username: `sshuser`
   - Password: (your password)
   - Port: `15987`

4. **Connect**

5. **Navigate:**
   - Remote site: `/home/sshuser/chatbot/`
   - Local site: `d:\Chatbot\`

6. **Upload:**
   - Select all files in left pane (local)
   - Right-click → Upload
   - Or drag and drop to right pane (remote)

7. **FileZilla will upload ALL files including dotfiles correctly**

---

## 🔧 Alternative: Use WinSCP

1. **Download WinSCP** (if not installed)
   - https://winscp.net/eng/download.php

2. **Open WinSCP**

3. **New Site:**
   - File protocol: `SFTP`
   - Host name: `156.67.110.254`
   - Port number: `15987`
   - User name: `sshuser`
   - Password: (your password)

4. **Login**

5. **Navigate to:** `/home/sshuser/chatbot/`

6. **Upload:**
   - Drag and drop all files from `d:\Chatbot\`
   - WinSCP handles dotfiles correctly

---

## 📋 Quick Fix Summary

**Best Solution:**
```powershell
# From Windows PowerShell
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

**If SCP not available:**
1. Download FileZilla or WinSCP
2. Connect via SFTP
3. Upload all files

**If must use Plesk File Manager:**
1. Upload all files except dotfiles
2. SSH to server
3. Create `.env` file manually (see Option 2 above)

---

## ✅ After Successful Upload

```bash
# SSH to server
ssh sshuser@156.67.110.254 -p 15987
cd ~/chatbot

# Verify files
ls -la

# Setup
cp .env.example .env
nano .env  # Add database credentials
chmod +x *.sh
chmod 600 .env

# Install
python3 -m venv venv
source venv/bin/activate
pip install -r requirements_production.txt

# Start
./start_production.sh

# Check
./check_status.sh
curl http://localhost:8000/api/health
```

---

## 🎯 Why SCP is Better Than Plesk File Manager

✅ Uploads dotfiles correctly  
✅ Faster for multiple files  
✅ More reliable  
✅ Preserves file permissions  
✅ Can resume interrupted uploads  
✅ No file size limits  
✅ Command-line automation  

---

## 📞 Still Having Issues?

If SCP command gives "command not found":

**Install OpenSSH on Windows:**
1. Settings → Apps → Optional Features
2. Add a feature → OpenSSH Client
3. Install
4. Restart PowerShell

**Or use Git Bash:**
1. Install Git for Windows
2. Open Git Bash
3. Run SCP command

**Or use FileZilla/WinSCP** (GUI tools that always work)

---

**The SCP method will solve all upload issues!** 🚀
