import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Configuration class for Aerp.ai chatbot"""

    # Database Configuration
    # Default database connection (updated to the provided server)
    DB_SERVER = os.getenv('DB_SERVER', '192.168.1.167')
    DB_NAME = os.getenv('DB_NAME', 'absolutebook_2172')
    DB_USER = os.getenv('DB_USER', 'sa')
    # Defaults updated to use provided database server details
    DB_PASSWORD = os.getenv('DB_PASSWORD', '?P1t8@6in4R')
    DB_TIMEOUT = int(os.getenv('DB_TIMEOUT', '200'))
    # Pooling options
    DB_POOLING = os.getenv('DB_POOLING', 'True')
    DB_MAX_POOL_SIZE = int(os.getenv('DB_MAX_POOL_SIZE', '500'))

    # Connection String
    @property
    def connection_string(self):
        return (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={self.DB_SERVER};"
            f"DATABASE={self.DB_NAME};"
            f"UID={self.DB_USER};"
            f"PWD={self.DB_PASSWORD};"
            f"Timeout={self.DB_TIMEOUT};"
            f"Connection Timeout={self.DB_TIMEOUT};"
            f"Pooling={self.DB_POOLING};"
            f"Max Pool Size={self.DB_MAX_POOL_SIZE};"
        )

    # OpenAI Configuration
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')

    # Flask Configuration
    FLASK_PORT = int(os.getenv('FLASK_PORT', '8000'))
    # Optional: support multiple ports (comma-separated), e.g. "8000,8509"
    FLASK_PORTS = [
        int(p.strip()) for p in os.getenv('FLASK_PORTS', '').split(',') if p.strip()
    ]
    FLASK_DEBUG = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'

    # Security / Admin
    # Optional admin token to protect internal endpoints (e.g., KB rebuild)
    ADMIN_TOKEN = os.getenv('ADMIN_TOKEN', '')

    # CORS origins (comma-separated). If empty, CORS will allow all origins by default
    ALLOWED_ORIGINS = [o.strip() for o in os.getenv(
        'ALLOWED_ORIGINS', '').split(',') if o.strip()]

    # Table to query - set to a valid table name in your database
    # Default uses schema.table format; update based on actual table in absolutebookmultidatabase
    TARGET_TABLE = os.getenv('TARGET_TABLE', 'dbo.Leads')
