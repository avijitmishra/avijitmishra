#!/bin/bash
# Production Startup Script for Plesk Server
# This script ensures the server starts and stays running

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Aerp.ai Chatbot - Production Startup${NC}"
echo -e "${GREEN}========================================${NC}"

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Create logs directory if it doesn't exist
mkdir -p logs

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}Creating virtual environment...${NC}"
    python3 -m venv venv
fi

# Activate virtual environment
echo -e "${GREEN}Activating virtual environment...${NC}"
source venv/bin/activate

# Install/upgrade dependencies
echo -e "${GREEN}Installing dependencies...${NC}"
pip install --upgrade pip
pip install -r requirements.txt
pip install gunicorn

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}Warning: .env file not found!${NC}"
    echo -e "${YELLOW}Creating .env from .env.example...${NC}"
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo -e "${YELLOW}Please edit .env file with your configuration${NC}"
    fi
fi

# Stop any existing instances
echo -e "${GREEN}Stopping any existing instances...${NC}"
pkill -f "gunicorn.*wsgi_production" || true
sleep 2

# Start the application with Gunicorn
echo -e "${GREEN}Starting Gunicorn server...${NC}"
nohup gunicorn --config gunicorn_config.py wsgi_production:application > logs/nohup.log 2>&1 &

# Get the PID
GUNICORN_PID=$!
echo $GUNICORN_PID > logs/gunicorn.pid

# Wait a moment for startup
sleep 3

# Check if process is running
if ps -p $GUNICORN_PID > /dev/null; then
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}✓ Server started successfully!${NC}"
    echo -e "${GREEN}PID: $GUNICORN_PID${NC}"
    echo -e "${GREEN}URL: http://0.0.0.0:8000${NC}"
    echo -e "${GREEN}Logs: $SCRIPT_DIR/logs/${NC}"
    echo -e "${GREEN}========================================${NC}"
    
    # Show recent logs
    echo -e "\n${YELLOW}Recent logs:${NC}"
    tail -n 20 logs/nohup.log
else
    echo -e "${RED}========================================${NC}"
    echo -e "${RED}✗ Failed to start server${NC}"
    echo -e "${RED}Check logs for details:${NC}"
    echo -e "${RED}  tail -f logs/nohup.log${NC}"
    echo -e "${RED}========================================${NC}"
    exit 1
fi
