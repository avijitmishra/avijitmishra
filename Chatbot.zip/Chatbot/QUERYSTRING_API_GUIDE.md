# Query String API Guide

## Overview
This guide covers the new query string endpoint and all available API endpoints for Aerp.ai chatbot.

---

## 🆕 Query String Endpoint

### Endpoint: `/api/query`
**Method:** `GET`  
**Description:** Send chat messages via URL query string parameters

### URL Format
```
http://localhost:8000/api/query?q=your+message+here
```

### Parameters
- `q` (required): The message/query to send to the chatbot
  - Spaces should be encoded as `+` or `%20`
  - Special characters should be URL-encoded

### Examples

#### 1. Simple Greeting
```bash
curl "http://localhost:8000/api/query?q=hello"
```

**Response:**
```json
{
  "success": true,
  "query": "hello",
  "data": [],
  "summary": "Hi there!\n\nI'm Aerp.ai, your intelligent database assistant!..."
}
```

#### 2. Query with Spaces
```bash
curl "http://localhost:8000/api/query?q=how+many+leads"
```

#### 3. Thank You Message
```bash
curl "http://localhost:8000/api/query?q=thanks"
```

**Response:**
```json
{
  "success": true,
  "query": "thanks",
  "data": [],
  "summary": "My pleasure! Feel free to ask more questions."
}
```

#### 4. Complex Query
```bash
curl "http://localhost:8000/api/query?q=show+me+recent+entries"
```

### PowerShell Examples
```powershell
# Simple query
Invoke-RestMethod -Uri "http://localhost:8000/api/query?q=hello"

# With variable
$message = "how many leads"
$encoded = [System.Web.HttpUtility]::UrlEncode($message)
Invoke-RestMethod -Uri "http://localhost:8000/api/query?q=$encoded"
```

### Browser Usage
You can test directly in your browser:
```
http://localhost:8000/api/query?q=hello
http://localhost:8000/api/query?q=how+many+leads
http://localhost:8000/api/query?q=thanks
```

---

## 💬 Chat Endpoint (POST)

### Endpoint: `/api/chat`
**Method:** `POST`  
**Content-Type:** `application/json`

### Request Body
```json
{
  "message": "your message here"
}
```

### Examples

#### Windows PowerShell
```powershell
$body = @{message="hello"} | ConvertTo-Json
Invoke-RestMethod -Uri "http://localhost:8000/api/chat" -Method POST -ContentType "application/json" -Body $body
```

#### Linux/Mac cURL
```bash
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "hello"}'
```

#### JavaScript/Fetch
```javascript
fetch('http://localhost:8000/api/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({ message: 'hello' })
})
.then(response => response.json())
.then(data => console.log(data));
```

---

## 🧠 Natural Language Query Endpoint

### Endpoint: `/api/nl`
**Methods:** `GET`, `POST`  
**Description:** Execute database queries using natural language

### GET Request
```bash
curl "http://localhost:8000/api/nl?q=how+many+tables"
curl "http://localhost:8000/api/nl?q=how+many+leads+in+database+absolutebook_2172"
```

### POST Request
```bash
curl -X POST http://localhost:8000/api/nl \
  -H "Content-Type: application/json" \
  -d '{"query": "how many leads"}'
```

---

## 🔍 Search by SRC UID

### Endpoint: `/api/src`
**Methods:** `GET`, `POST`

### GET Request
```bash
curl "http://localhost:8000/api/src?src_uid=ABC123"
```

### POST Request
```bash
curl -X POST http://localhost:8000/api/src \
  -H "Content-Type: application/json" \
  -d '{"src_uid": "ABC123"}'
```

---

## 🏥 Health Check

### Endpoint: `/api/health`
**Method:** `GET`

```bash
curl http://localhost:8000/api/health
```

**Response:**
```json
{
  "status": "healthy",
  "service": "Aerp.ai",
  "version": "1.0.0"
}
```

---

## 🗄️ Database Status

### Endpoint: `/api/db-status`
**Method:** `GET`

```bash
curl http://localhost:8000/api/db-status
```

**Response:**
```json
{
  "success": true,
  "connected": true,
  "error": null
}
```

---

## 📊 Table Information

### Endpoint: `/api/table-info`
**Method:** `GET`

```bash
curl http://localhost:8000/api/table-info
```

---

## 🔎 Search Records

### Endpoint: `/api/search`
**Method:** `POST`

```bash
curl -X POST http://localhost:8000/api/search \
  -H "Content-Type: application/json" \
  -d '{"search_term": "john", "columns": ["name", "email"]}'
```

---

## 🧪 Interactive Testing Page

Visit the interactive cURL testing page:
```
http://localhost:8000/curl
```

This page provides:
- ✅ Interactive form-based testing
- ✅ Copy-to-clipboard cURL commands
- ✅ Live API response viewing
- ✅ Examples for all endpoints

---

## 📝 Response Format

All endpoints return JSON with a consistent structure:

### Success Response
```json
{
  "success": true,
  "query": "user's query",
  "data": [...],
  "summary": "Human-readable response"
}
```

### Error Response
```json
{
  "success": false,
  "error": "Error message description"
}
```

---

## 🔒 Security Features

All endpoints include:
- ✅ Input sanitization
- ✅ SQL injection prevention
- ✅ XSS protection
- ✅ Prompt injection detection
- ✅ Input length limits
- ✅ Malicious pattern blocking

---

## 🌐 URL Encoding Reference

Common characters that need encoding:
- Space: `+` or `%20`
- `?`: `%3F`
- `&`: `%26`
- `=`: `%3D`
- `#`: `%23`
- `/`: `%2F`

### Encoding in Different Languages

**JavaScript:**
```javascript
const encoded = encodeURIComponent("hello world");
```

**Python:**
```python
from urllib.parse import quote
encoded = quote("hello world")
```

**PowerShell:**
```powershell
$encoded = [System.Web.HttpUtility]::UrlEncode("hello world")
```

---

## 📖 Usage Examples by Scenario

### Scenario 1: Greeting the Bot
```bash
# Query string method (easiest)
curl "http://localhost:8000/api/query?q=hi"

# POST method
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "hi"}'
```

### Scenario 2: Thanking the Bot
```bash
curl "http://localhost:8000/api/query?q=thank+you"
```

### Scenario 3: Database Query
```bash
curl "http://localhost:8000/api/query?q=how+many+leads"
```

### Scenario 4: Saying Goodbye
```bash
curl "http://localhost:8000/api/query?q=regards"
```

---

## 🚀 Quick Start

1. **Start the server:**
   ```bash
   python app.py
   ```

2. **Test the health endpoint:**
   ```bash
   curl http://localhost:8000/api/health
   ```

3. **Send your first query:**
   ```bash
   curl "http://localhost:8000/api/query?q=hello"
   ```

4. **Open the testing page:**
   ```
   http://localhost:8000/curl
   ```

---

## 💡 Tips

1. **Use Query String for Simple Requests:** The `/api/query` endpoint is perfect for quick tests and simple integrations
2. **Use POST for Complex Data:** The `/api/chat` endpoint is better for programmatic access with complex payloads
3. **Test in Browser:** Query string endpoints can be tested directly in your browser
4. **Use the Testing Page:** Visit `/curl` for an interactive testing experience

---

## 🆘 Troubleshooting

### Issue: "No query parameter provided"
**Solution:** Make sure to include `?q=` in your URL:
```bash
# ❌ Wrong
curl "http://localhost:8000/api/query"

# ✅ Correct
curl "http://localhost:8000/api/query?q=hello"
```

### Issue: Spaces not working
**Solution:** Encode spaces as `+` or `%20`:
```bash
# ✅ Correct
curl "http://localhost:8000/api/query?q=how+many+leads"
curl "http://localhost:8000/api/query?q=how%20many%20leads"
```

### Issue: Special characters causing errors
**Solution:** URL-encode special characters or use POST method instead

---

## 📚 Additional Resources

- Main chatbot UI: `http://localhost:8000/`
- cURL testing page: `http://localhost:8000/curl`
- API documentation: This file
- Health check: `http://localhost:8000/api/health`
