// Aerp.ai Chatbot Frontend Script

const API_BASE_URL = window.location.origin;

class AerpChatbot {
  constructor() {
    this.chatButton = document.getElementById("chatButton");
    this.chatPopup = document.getElementById("chatPopup");
    this.closeBtn = document.getElementById("closeBtn");
    this.menuBtn = document.getElementById("menuBtn");
    this.sendBtn = document.getElementById("sendBtn");
    this.messageInput = document.getElementById("messageInput");
    this.chatBody = document.getElementById("chatBody");

    this.initializeEventListeners();
    this.addWelcomeMessage();
  }

  initializeEventListeners() {
    // Chat button click
    this.chatButton.addEventListener("click", () => this.openChat());

    // Close button click
    this.closeBtn.addEventListener("click", () => this.closeChat());

    // Menu button click (optional functionality)
    this.menuBtn.addEventListener("click", () => {
      console.log("Menu clicked");
    });

    // Send button click
    this.sendBtn.addEventListener("click", () => this.sendMessage());

    // Enter key press
    this.messageInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        this.sendMessage();
      }
    });
  }

  async fetchBySrcUid(srcUid) {
    if (!srcUid) return null;

    try {
      const resp = await fetch(`${API_BASE_URL}/api/src`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ src_uid: srcUid }),
      });

      const data = await resp.json();
      if (data.success) {
        // Display a bot message with the fetched record(s)
        if (data.count === 0) {
          this.addMessage(`No records found for SRC UID: ${srcUid}`, "bot");
        } else {
          const payload = {
            success: true,
            summary: `Found ${data.count} record(s) for SRC UID: ${srcUid}`,
            data: data.results,
          };
          this.addBotResponse(payload);
        }
        return data;
      } else {
        this.addMessage(`Error fetching SRC UID: ${data.error}`, "bot");
        return null;
      }
    } catch (err) {
      this.addMessage("Network error while fetching SRC UID", "bot");
      console.error(err);
      return null;
    }
  }

  addWelcomeMessage() {
    // Add initial bot message
    const welcomeText = "Hi there! 👋 How can I help you today?";
    this.addMessage(welcomeText, "bot");
  }

  openChat() {
    this.chatPopup.classList.add("active");
    this.chatButton.classList.add("hidden");
    this.messageInput.focus();
  }

  closeChat() {
    this.chatPopup.classList.remove("active");
    this.chatButton.classList.remove("hidden");
  }

  async sendMessage() {
    const message = this.messageInput.value.trim();

    if (!message) return;

    // Clear input
    this.messageInput.value = "";

    // Add user message to chat
    this.addMessage(message, "user");

    // Show typing indicator
    this.showTypingIndicator();

    try {
      // Send request to backend
      const response = await fetch(`${API_BASE_URL}/api/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message }),
      });

      const data = await response.json();

      // Remove typing indicator
      this.removeTypingIndicator();

      if (data.success) {
        // Add bot response
        this.addBotResponse(data);
      } else {
        this.addMessage(`Sorry, I encountered an error: ${data.error}`, "bot");
      }
    } catch (error) {
      this.removeTypingIndicator();
      this.addMessage(
        "Sorry, I could not connect to the server. Please try again.",
        "bot"
      );
      console.error("Error:", error);
    }
  }

  addMessage(text, sender = "bot") {
    const messageDiv = document.createElement("div");
    messageDiv.className = `message ${sender}-message`;

    const avatarDiv = document.createElement("div");
    avatarDiv.className = "message-avatar";
    avatarDiv.innerHTML =
      sender === "bot"
        ? '<i class="fas fa-robot"></i>'
        : '<i class="fas fa-user"></i>';

    const contentDiv = document.createElement("div");
    contentDiv.className = "message-content";

    const bubbleDiv = document.createElement("div");
    bubbleDiv.className = "message-bubble";
    bubbleDiv.innerHTML = `<p>${this.escapeHtml(text)}</p>`;

    contentDiv.appendChild(bubbleDiv);

    messageDiv.appendChild(avatarDiv);
    messageDiv.appendChild(contentDiv);

    this.chatBody.appendChild(messageDiv);
    this.scrollToBottom();
  }

  addBotResponse(data) {
    const messageDiv = document.createElement("div");
    messageDiv.className = "message bot-message";

    const avatarDiv = document.createElement("div");
    avatarDiv.className = "message-avatar";
    avatarDiv.innerHTML = '<i class="fas fa-robot"></i>';

    const contentDiv = document.createElement("div");
    contentDiv.className = "message-content";

    const bubbleDiv = document.createElement("div");
    bubbleDiv.className = "message-bubble";

    // Add summary with markdown support
    if (data.summary) {
      const summaryDiv = document.createElement("div");
      summaryDiv.innerHTML = this.formatMarkdown(data.summary);
      bubbleDiv.appendChild(summaryDiv);
    }

    // Add data table if results exist
    if (data.data && data.data.length > 0) {
      const tableDiv = this.createDataTable(data.data);
      bubbleDiv.appendChild(tableDiv);
    } else if (data.data && data.data.length === 0 && !data.summary) {
      const noDataP = document.createElement("p");
      noDataP.textContent = "No records found matching your query.";
      bubbleDiv.appendChild(noDataP);
    }

    contentDiv.appendChild(bubbleDiv);

    messageDiv.appendChild(avatarDiv);
    messageDiv.appendChild(contentDiv);

    this.chatBody.appendChild(messageDiv);
    this.scrollToBottom();
  }

  formatMarkdown(text) {
    // Simple markdown formatting
    let formatted = this.escapeHtml(text);

    // Bold text **text**
    formatted = formatted.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");

    // Line breaks
    formatted = formatted.replace(/\n/g, "<br>");

    // Preserve spacing
    formatted = formatted.replace(/   /g, "&nbsp;&nbsp;&nbsp;");

    return formatted;
  }

  createDataTable(data) {
    const tableContainer = document.createElement("div");
    tableContainer.className = "data-table";

    const table = document.createElement("table");

    // Create header
    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");

    const columns = Object.keys(data[0]);
    columns.forEach((col) => {
      const th = document.createElement("th");
      th.textContent = col;
      headerRow.appendChild(th);
    });

    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Create body
    const tbody = document.createElement("tbody");

    // Limit to first 10 rows for display
    const displayData = data.slice(0, 10);

    displayData.forEach((row) => {
      const tr = document.createElement("tr");
      columns.forEach((col) => {
        const td = document.createElement("td");
        td.textContent = row[col] !== null ? row[col] : "N/A";
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    tableContainer.appendChild(table);

    // Add note if more records exist
    if (data.length > 10) {
      const note = document.createElement("p");
      note.style.marginTop = "8px";
      note.style.fontSize = "12px";
      note.style.color = "#6b7280";
      note.textContent = `Showing 10 of ${data.length} records`;
      tableContainer.appendChild(note);
    }

    return tableContainer;
  }

  showTypingIndicator() {
    const typingDiv = document.createElement("div");
    typingDiv.className = "message bot-message";
    typingDiv.id = "typingIndicator";

    const avatarDiv = document.createElement("div");
    avatarDiv.className = "message-avatar";
    avatarDiv.innerHTML = '<i class="fas fa-robot"></i>';

    const contentDiv = document.createElement("div");
    contentDiv.className = "message-content";

    const bubbleDiv = document.createElement("div");
    bubbleDiv.className = "message-bubble";

    const typingIndicator = document.createElement("div");
    typingIndicator.className = "typing-indicator";
    typingIndicator.innerHTML =
      '<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';

    bubbleDiv.appendChild(typingIndicator);
    contentDiv.appendChild(bubbleDiv);

    typingDiv.appendChild(avatarDiv);
    typingDiv.appendChild(contentDiv);

    this.chatBody.appendChild(typingDiv);
    this.scrollToBottom();
  }

  removeTypingIndicator() {
    const typingIndicator = document.getElementById("typingIndicator");
    if (typingIndicator) {
      typingIndicator.remove();
    }
  }

  scrollToBottom() {
    this.chatBody.scrollTop = this.chatBody.scrollHeight;
  }

  getCurrentTime() {
    const now = new Date();
    return now.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  }

  escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
}

// Initialize chatbot when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  const chatbot = new AerpChatbot();
  console.log("Aerp.ai Chatbot initialized");
});
