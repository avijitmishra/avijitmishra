# Aerp.ai Chatbot - Plesk Server Deployment

**Intelligent Database Assistant with RAG (Retrieval Augmented Generation)**

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Server Information](#server-information)
3. [Prerequisites](#prerequisites)
4. [Quick Start](#quick-start)
5. [Detailed Deployment Steps](#detailed-deployment-steps)
6. [Configuration](#configuration)
7. [Starting the Server](#starting-the-server)
8. [Keeping Server Running Permanently](#keeping-server-running-permanently)
9. [Management Commands](#management-commands)
10. [API Endpoints](#api-endpoints)
11. [Troubleshooting](#troubleshooting)
12. [File Structure](#file-structure)
13. [Security](#security)
14. [Maintenance](#maintenance)

---

## Overview

Aerp.ai is an intelligent chatbot that provides natural language interface to your SQL Server database. It features:

- ✅ Natural language query processing
- ✅ Greeting and conversational responses
- ✅ Query string and POST API endpoints
- ✅ Interactive cURL testing page
- ✅ Automatic server restart on crashes
- ✅ Multi-worker production server
- ✅ Comprehensive security features

---

## Server Information

**Plesk Server Details:**
- **URL:** http://156.67.110.254:8880/
- **IP:** 156.67.110.254
- **SSH Port:** 15987
- **User:** sshuser
- **Application Port:** 8000

---

## Prerequisites

### On Plesk Server

1. **Python 3.8 or higher**
   ```bash
   python3 --version
   ```

2. **pip (Python package manager)**
   ```bash
   pip3 --version
   ```

3. **Virtual environment support**
   ```bash
   python3 -m venv --help
   ```

4. **SQL Server ODBC Driver 17**
   ```bash
   # Check if installed
   odbcinst -q -d
   
   # If not installed:
   # Ubuntu/Debian
   sudo apt-get install unixodbc-dev
   curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -
   curl https://packages.microsoft.com/config/ubuntu/20.04/prod.list | sudo tee /etc/apt/sources.list.d/mssql-release.list
   sudo apt-get update
   sudo ACCEPT_EULA=Y apt-get install msodbcsql17
   ```

5. **Supervisor (recommended for auto-restart)**
   ```bash
   sudo apt-get install supervisor
   ```

### On Your Local Machine

1. **SSH client** (PuTTY, OpenSSH, or built-in terminal)
2. **SCP/SFTP client** (FileZilla, WinSCP, or command-line)

---

## Quick Start

### 1. Upload Files to Server

**Using SCP:**
```bash
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

**Using SFTP:**
```bash
sftp -P 15987 sshuser@156.67.110.254
cd chatbot
put -r *
```

### 2. SSH to Server

```bash
ssh sshuser@156.67.110.254 -p 15987
cd ~/chatbot
```

### 3. Quick Setup

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements_production.txt

# Make scripts executable
chmod +x *.sh

# Create logs directory
mkdir -p logs

# Configure environment
cp .env.example .env
nano .env  # Edit with your database credentials
```

### 4. Start Server

```bash
./start_production.sh
```

### 5. Verify

```bash
./check_status.sh
curl http://localhost:8000/api/health
```

---

## Detailed Deployment Steps

### Step 1: Prepare Files Locally

Before uploading, clean up unnecessary files:

```bash
# Delete files listed in FILES_TO_DELETE.txt
# Keep only essential production files
```

**Essential files to upload:**
- `app.py` - Main Flask application
- `config.py` - Configuration management
- `database.py` - Database connection handler
- `rag_engine.py` - RAG engine for intelligent responses
- `wsgi_production.py` - WSGI entry point
- `passenger_wsgi.py` - Plesk Passenger configuration
- `gunicorn_config.py` - Gunicorn server configuration
- `requirements_production.txt` - Production dependencies
- `.env.example` - Environment template
- `.gitignore` - Git ignore rules
- `start_production.sh` - Start script
- `stop_production.sh` - Stop script
- `restart_production.sh` - Restart script
- `check_status.sh` - Status check script
- `supervisor_config.txt` - Supervisor configuration
- `systemd_service.txt` - Systemd service configuration
- `static/` - Frontend files (entire folder)
- Documentation files (optional but recommended)

### Step 2: Connect to Plesk Server

```bash
ssh sshuser@156.67.110.254 -p 15987
```

**First-time connection:**
- You may be asked to verify the server's fingerprint
- Type `yes` to continue
- Enter your password

### Step 3: Create Application Directory

```bash
mkdir -p ~/chatbot
cd ~/chatbot
```

### Step 4: Upload Files

**Option A: Using SCP (from local machine)**
```bash
# Upload all files
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/

# Or upload specific files
scp -P 15987 d:\Chatbot\app.py sshuser@156.67.110.254:~/chatbot/
scp -P 15987 d:\Chatbot\config.py sshuser@156.67.110.254:~/chatbot/
# ... etc
```

**Option B: Using SFTP**
```bash
sftp -P 15987 sshuser@156.67.110.254
cd chatbot
put app.py
put config.py
put database.py
put rag_engine.py
# ... etc
```

**Option C: Using Git (recommended for updates)**
```bash
# On server
cd ~/chatbot
git clone <your-repository-url> .
```

### Step 5: Create Virtual Environment

```bash
cd ~/chatbot
python3 -m venv venv
```

**Activate virtual environment:**
```bash
source venv/bin/activate
```

You should see `(venv)` in your prompt.

### Step 6: Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements_production.txt
```

**Expected output:**
```
Successfully installed Flask-3.0.0 Flask-CORS-4.0.0 gunicorn-21.2.0 pyodbc-5.0.1 ...
```

### Step 7: Configure Environment Variables

```bash
# Copy template
cp .env.example .env

# Edit configuration
nano .env
```

**Required configuration in `.env`:**
```env
# Database Configuration
DB_SERVER=192.168.1.167
DB_NAME=absolutebook_2172
DB_USER=sa
DB_PASSWORD=?P1t8@6in4R
DB_TIMEOUT=200
DB_POOLING=True
DB_MAX_POOL_SIZE=500

# Flask Configuration
FLASK_PORT=8000
FLASK_DEBUG=False

# Optional: Admin token for internal endpoints
ADMIN_TOKEN=your-secure-token-here

# Optional: CORS origins (comma-separated)
ALLOWED_ORIGINS=

# Target table for queries
TARGET_TABLE=dbo.Leads
```

**Save and exit:**
- Press `Ctrl+X`
- Press `Y` to confirm
- Press `Enter`

### Step 8: Make Scripts Executable

```bash
chmod +x start_production.sh
chmod +x stop_production.sh
chmod +x restart_production.sh
chmod +x check_status.sh
```

### Step 9: Create Logs Directory

```bash
mkdir -p logs
```

### Step 10: Test the Application

```bash
# Quick test (will run in foreground)
python wsgi_production.py
```

**Expected output:**
```
Initializing Aerp.ai...
Aerp.ai is ready!
```

Press `Ctrl+C` to stop.

### Step 11: Start Production Server

```bash
./start_production.sh
```

**Expected output:**
```
========================================
✓ Server started successfully!
PID: 12345
URL: http://0.0.0.0:8000
Logs: /home/sshuser/chatbot/logs/
========================================
```

### Step 12: Verify Server is Running

```bash
./check_status.sh
```

**Test endpoints:**
```bash
# Health check
curl http://localhost:8000/api/health

# Chat test
curl "http://localhost:8000/api/query?q=hello"
```

---

## Configuration

### Environment Variables (.env)

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `DB_SERVER` | SQL Server IP/hostname | 192.168.1.167 | Yes |
| `DB_NAME` | Database name | absolutebook_2172 | Yes |
| `DB_USER` | Database username | sa | Yes |
| `DB_PASSWORD` | Database password | - | Yes |
| `DB_TIMEOUT` | Connection timeout (seconds) | 200 | No |
| `DB_POOLING` | Enable connection pooling | True | No |
| `DB_MAX_POOL_SIZE` | Max pool size | 500 | No |
| `FLASK_PORT` | Application port | 8000 | No |
| `FLASK_DEBUG` | Debug mode | False | No |
| `ADMIN_TOKEN` | Admin endpoint token | - | No |
| `ALLOWED_ORIGINS` | CORS origins | - | No |
| `TARGET_TABLE` | Default query table | dbo.Leads | No |

### Gunicorn Configuration (gunicorn_config.py)

**Key settings:**
```python
bind = "0.0.0.0:8000"  # Listen on all interfaces
workers = (CPU_cores * 2) + 1  # Auto-calculated
timeout = 300  # Request timeout
max_requests = 1000  # Restart worker after N requests
```

**To customize:**
```bash
nano gunicorn_config.py
```

---

## Starting the Server

### Manual Start

```bash
./start_production.sh
```

This script:
1. Creates virtual environment if needed
2. Installs dependencies
3. Stops any existing instances
4. Starts Gunicorn server in background
5. Saves PID to `logs/gunicorn.pid`
6. Shows startup logs

### Check Status

```bash
./check_status.sh
```

Shows:
- Running status
- Process IDs
- Port usage
- Health check result
- Recent logs

### Stop Server

```bash
./stop_production.sh
```

### Restart Server

```bash
./restart_production.sh
```

---

## Keeping Server Running Permanently

### Option 1: Supervisor (Recommended)

Supervisor ensures the server:
- Starts automatically on server boot
- Restarts automatically if it crashes
- Runs in background
- Logs all output

#### Install Supervisor

```bash
sudo apt-get update
sudo apt-get install supervisor
```

#### Configure Supervisor

```bash
# Copy configuration
sudo cp supervisor_config.txt /etc/supervisor/conf.d/aerp-chatbot.conf

# Edit if needed (update paths)
sudo nano /etc/supervisor/conf.d/aerp-chatbot.conf

# Reload supervisor
sudo supervisorctl reread
sudo supervisorctl update

# Start service
sudo supervisorctl start aerp-chatbot
```

#### Supervisor Commands

```bash
# Check status
sudo supervisorctl status aerp-chatbot

# Start
sudo supervisorctl start aerp-chatbot

# Stop
sudo supervisorctl stop aerp-chatbot

# Restart
sudo supervisorctl restart aerp-chatbot

# View logs
sudo supervisorctl tail -f aerp-chatbot

# View error logs
sudo supervisorctl tail -f aerp-chatbot stderr
```

### Option 2: Systemd Service

```bash
# Copy service file
sudo cp systemd_service.txt /etc/systemd/system/aerp-chatbot.service

# Edit if needed
sudo nano /etc/systemd/system/aerp-chatbot.service

# Reload systemd
sudo systemctl daemon-reload

# Enable (start on boot)
sudo systemctl enable aerp-chatbot

# Start service
sudo systemctl start aerp-chatbot

# Check status
sudo systemctl status aerp-chatbot

# View logs
sudo journalctl -u aerp-chatbot -f
```

### Option 3: Screen Session (Simple)

```bash
# Install screen
sudo apt-get install screen

# Start screen session
screen -S aerp-chatbot

# Run server
./start_production.sh

# Detach: Press Ctrl+A, then D

# Reattach later
screen -r aerp-chatbot

# List sessions
screen -ls
```

### Option 4: Nohup (Basic)

Already included in `start_production.sh`:
```bash
./start_production.sh
# Server runs in background even after logout
```

---

## Management Commands

### Server Control

```bash
# Start server
./start_production.sh

# Stop server
./stop_production.sh

# Restart server
./restart_production.sh

# Check status
./check_status.sh
```

### View Logs

```bash
# Application logs
tail -f logs/nohup.log

# Gunicorn access logs
tail -f logs/gunicorn_access.log

# Gunicorn error logs
tail -f logs/gunicorn_error.log

# Last 50 lines
tail -n 50 logs/nohup.log

# Follow logs (Ctrl+C to exit)
tail -f logs/nohup.log
```

### Process Management

```bash
# Find processes
ps aux | grep gunicorn

# Check port usage
netstat -tlnp | grep 8000
# or
ss -tlnp | grep 8000

# Kill specific PID
kill <PID>

# Force kill
kill -9 <PID>

# Kill all gunicorn processes
pkill -f gunicorn
```

---

## API Endpoints

### Health Check
```bash
GET /api/health
curl http://localhost:8000/api/health
```

**Response:**
```json
{
  "status": "healthy",
  "service": "Aerp.ai",
  "version": "1.0.0"
}
```

### Chat (Query String)
```bash
GET /api/query?q=<message>
curl "http://localhost:8000/api/query?q=hello"
curl "http://localhost:8000/api/query?q=how+many+leads"
```

### Chat (POST)
```bash
POST /api/chat
Content-Type: application/json
{"message": "hello"}

curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "hello"}'
```

### Natural Language Query
```bash
GET /api/nl?q=<query>
curl "http://localhost:8000/api/nl?q=how+many+tables"
```

### Database Status
```bash
GET /api/db-status
curl http://localhost:8000/api/db-status
```

### Search by SRC UID
```bash
GET /api/src?src_uid=<uid>
curl "http://localhost:8000/api/src?src_uid=ABC123"
```

### Table Information
```bash
GET /api/table-info
curl http://localhost:8000/api/table-info
```

### cURL Testing Page
```
http://localhost:8000/curl
```

---

## Troubleshooting

### Server Won't Start

**Check logs:**
```bash
tail -f logs/nohup.log
tail -f logs/gunicorn_error.log
```

**Common issues:**

1. **Port already in use**
   ```bash
   # Find process using port 8000
   netstat -tlnp | grep 8000
   
   # Kill the process
   sudo fuser -k 8000/tcp
   ```

2. **Permission denied**
   ```bash
   # Fix ownership
   sudo chown -R sshuser:sshuser ~/chatbot
   
   # Fix permissions
   chmod -R 755 ~/chatbot
   chmod 600 .env
   chmod +x *.sh
   ```

3. **Module not found**
   ```bash
   # Reinstall dependencies
   source venv/bin/activate
   pip install -r requirements_production.txt
   ```

### Database Connection Issues

**Test connection:**
```bash
python -c "from database import DatabaseManager; db = DatabaseManager(); print(db.connect())"
```

**Check configuration:**
```bash
cat .env
```

**Verify database server:**
```bash
# Ping server
ping 192.168.1.167

# Test SQL Server port (1433)
telnet 192.168.1.167 1433
# or
nc -zv 192.168.1.167 1433
```

**Check ODBC driver:**
```bash
odbcinst -q -d
```

### External Access Not Working

**Check firewall:**
```bash
# Allow port 8000
sudo ufw allow 8000/tcp
sudo ufw reload

# Check status
sudo ufw status
```

**Check if server is listening:**
```bash
netstat -tlnp | grep 8000
```

**Test from server:**
```bash
curl http://localhost:8000/api/health
```

**Test from external:**
```bash
# From your local machine
curl http://156.67.110.254:8000/api/health
```

### Memory Issues

**Check memory usage:**
```bash
free -h
```

**Check process memory:**
```bash
ps aux | grep gunicorn
```

**Reduce workers:**
```bash
nano gunicorn_config.py
# Change: workers = 2
```

### Logs Not Appearing

**Check log directory:**
```bash
ls -la logs/
```

**Create if missing:**
```bash
mkdir -p logs
chmod 755 logs
```

**Check disk space:**
```bash
df -h
```

---

## File Structure

```
chatbot/
├── app.py                      # Main Flask application
├── config.py                   # Configuration management
├── database.py                 # Database connection handler
├── rag_engine.py               # RAG engine for responses
├── wsgi_production.py          # WSGI entry point
├── passenger_wsgi.py           # Plesk Passenger config
├── gunicorn_config.py          # Gunicorn configuration
├── requirements_production.txt # Production dependencies
├── .env                        # Environment variables (create from .env.example)
├── .env.example                # Environment template
├── .gitignore                  # Git ignore rules
│
├── start_production.sh         # Start server script
├── stop_production.sh          # Stop server script
├── restart_production.sh       # Restart server script
├── check_status.sh             # Status check script
│
├── supervisor_config.txt       # Supervisor configuration
├── systemd_service.txt         # Systemd service file
│
├── static/                     # Frontend files
│   ├── index.html              # Main chatbot UI
│   ├── curl_test.html          # cURL testing page
│   ├── script.js               # Frontend JavaScript
│   └── styles.css              # Frontend styles
│
├── logs/                       # Log files (created automatically)
│   ├── nohup.log               # Application logs
│   ├── gunicorn_access.log     # Access logs
│   ├── gunicorn_error.log      # Error logs
│   └── gunicorn.pid            # Process ID file
│
└── venv/                       # Virtual environment (created during setup)
```

---

## Security

### Input Sanitization

All user inputs are sanitized to prevent:
- SQL injection
- XSS attacks
- Prompt injection
- Code injection

### Environment Variables

**Secure `.env` file:**
```bash
chmod 600 .env
```

**Never commit `.env` to git:**
Already included in `.gitignore`

### Firewall

**Allow only necessary ports:**
```bash
sudo ufw allow 15987/tcp  # SSH
sudo ufw allow 80/tcp     # HTTP (if using reverse proxy)
sudo ufw allow 443/tcp    # HTTPS (if using SSL)
sudo ufw allow 8000/tcp   # Application (or use reverse proxy)
sudo ufw enable
```

### SSL Certificate (Recommended)

**Using Let's Encrypt:**
```bash
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### Admin Endpoints

Protected by `ADMIN_TOKEN` in `.env`:
```bash
# Set in .env
ADMIN_TOKEN=your-secure-random-token-here
```

**Usage:**
```bash
curl -X POST http://localhost:8000/internal/rebuild-kb \
  -H "X-Admin-Token: your-secure-random-token-here"
```

---

## Maintenance

### Regular Tasks

**Weekly:**
```bash
# Check status
./check_status.sh

# Review logs
tail -n 100 logs/gunicorn_error.log
```

**Monthly:**
```bash
# Update dependencies
source venv/bin/activate
pip list --outdated
pip install --upgrade <package-name>

# Clean old logs
find logs/ -name "*.log" -mtime +30 -delete

# Restart server
./restart_production.sh
```

**Quarterly:**
```bash
# Security updates
sudo apt-get update
sudo apt-get upgrade

# Review configuration
nano .env
nano gunicorn_config.py
```

### Backup

**Create backup script:**
```bash
#!/bin/bash
BACKUP_DIR=~/backups/chatbot
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/chatbot_$DATE.tar.gz \
    --exclude='venv' \
    --exclude='__pycache__' \
    --exclude='logs/*.log' \
    ~/chatbot
echo "Backup created: $BACKUP_DIR/chatbot_$DATE.tar.gz"
```

**Run backup:**
```bash
chmod +x backup.sh
./backup.sh
```

### Updates

**To update application:**
```bash
# Stop server
./stop_production.sh

# Pull latest changes (if using git)
git pull

# Or upload new files via SCP/SFTP

# Update dependencies
source venv/bin/activate
pip install -r requirements_production.txt

# Start server
./start_production.sh
```

---

## Support & Documentation

### Additional Documentation

- **PLESK_DEPLOYMENT_GUIDE.md** - Detailed deployment instructions
- **DEPLOYMENT_CHECKLIST.md** - Step-by-step checklist
- **QUERYSTRING_API_GUIDE.md** - Complete API reference
- **SECURITY_FEATURES.md** - Security documentation

### Quick Reference

**Server:** 156.67.110.254:8000  
**SSH:** `ssh sshuser@156.67.110.254 -p 15987`  
**Start:** `./start_production.sh`  
**Stop:** `./stop_production.sh`  
**Status:** `./check_status.sh`  
**Logs:** `tail -f logs/nohup.log`

### Access URLs

- **Health:** http://156.67.110.254:8000/api/health
- **Main UI:** http://156.67.110.254:8000/
- **cURL Test:** http://156.67.110.254:8000/curl
- **API:** http://156.67.110.254:8000/api/query?q=hello

---

## Success Checklist

After deployment, verify:

- [ ] Server starts without errors
- [ ] Health endpoint returns `{"status": "healthy"}`
- [ ] Chat endpoint responds to queries
- [ ] External access works from your machine
- [ ] Server survives SSH disconnect
- [ ] Server restarts automatically (if using supervisor/systemd)
- [ ] Logs are being written to `logs/` directory
- [ ] Database connection works
- [ ] Firewall allows necessary ports

---

## License

Copyright © 2025 Aerp.ai. All rights reserved.

---

## Version

**Version:** 1.0.0  
**Last Updated:** November 6, 2025  
**Deployment Target:** Plesk Server (Linux)

---

**Your Aerp.ai chatbot is ready for production deployment!**

For issues or questions, refer to the troubleshooting section or check the detailed deployment guide.
