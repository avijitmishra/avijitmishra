#!/bin/bash
# Check Server Status Script

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Aerp.ai Chatbot - Server Status${NC}"
echo -e "${BLUE}========================================${NC}"

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Check if gunicorn is running
if pgrep -f "gunicorn.*wsgi_production" > /dev/null; then
    echo -e "${GREEN}✓ Server is RUNNING${NC}"
    
    # Show PIDs
    echo -e "\n${YELLOW}Process IDs:${NC}"
    pgrep -f "gunicorn.*wsgi_production" | while read pid; do
        echo -e "  PID: $pid"
    done
    
    # Show PID file
    if [ -f "logs/gunicorn.pid" ]; then
        echo -e "\n${YELLOW}PID File:${NC} $(cat logs/gunicorn.pid)"
    fi
    
    # Show port usage
    echo -e "\n${YELLOW}Port Usage:${NC}"
    netstat -tlnp 2>/dev/null | grep :8000 || ss -tlnp 2>/dev/null | grep :8000 || echo "  Port 8000 status unknown"
    
    # Test health endpoint
    echo -e "\n${YELLOW}Health Check:${NC}"
    if command -v curl &> /dev/null; then
        HEALTH=$(curl -s http://localhost:8000/api/health 2>/dev/null)
        if [ $? -eq 0 ]; then
            echo -e "  ${GREEN}✓ Health endpoint responding${NC}"
            echo "  Response: $HEALTH"
        else
            echo -e "  ${RED}✗ Health endpoint not responding${NC}"
        fi
    else
        echo "  curl not available for health check"
    fi
    
    # Show recent logs
    echo -e "\n${YELLOW}Recent Logs (last 10 lines):${NC}"
    if [ -f "logs/nohup.log" ]; then
        tail -n 10 logs/nohup.log
    else
        echo "  No logs found"
    fi
    
else
    echo -e "${RED}✗ Server is NOT RUNNING${NC}"
    
    # Check for recent errors
    if [ -f "logs/nohup.log" ]; then
        echo -e "\n${YELLOW}Recent Errors:${NC}"
        tail -n 20 logs/nohup.log | grep -i error || echo "  No recent errors found"
    fi
fi

echo -e "\n${BLUE}========================================${NC}"
echo -e "${YELLOW}Commands:${NC}"
echo -e "  Start:   ./start_production.sh"
echo -e "  Stop:    ./stop_production.sh"
echo -e "  Restart: ./restart_production.sh"
echo -e "  Status:  ./check_status.sh"
echo -e "${BLUE}========================================${NC}"
