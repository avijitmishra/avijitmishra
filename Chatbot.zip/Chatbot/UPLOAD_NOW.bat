@echo off
echo ============================================
echo Uploading files to Plesk Server
echo ============================================
echo.
echo Server: 156.67.110.254
echo Port: 15987
echo User: sshuser
echo.
echo You will be asked for your password...
echo.
pause

scp -P 15987 -r * sshuser@156.67.110.254:~/chatbot/

echo.
echo ============================================
echo Upload Complete!
echo ============================================
echo.
echo Next steps:
echo 1. SSH to server: ssh sshuser@156.67.110.254 -p 15987
echo 2. Go to folder: cd ~/chatbot
echo 3. Setup: See USE_THIS_COMMAND.txt for instructions
echo.
pause
