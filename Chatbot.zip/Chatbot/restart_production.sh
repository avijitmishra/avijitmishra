#!/bin/bash
# Restart Production Server Script

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}  Restarting Aerp.ai Chatbot Server${NC}"
echo -e "${YELLOW}========================================${NC}"

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Stop the server
echo -e "${YELLOW}Stopping server...${NC}"
./stop_production.sh

# Wait a moment
sleep 2

# Start the server
echo -e "${GREEN}Starting server...${NC}"
./start_production.sh
