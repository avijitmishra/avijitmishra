from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import re
from rag_engine import RAGEngine
from config import Config

app = Flask(__name__, static_folder='static')
config = Config()
# Configure CORS: allow specific origins if ALLOWED_ORIGINS is set; otherwise allow all
_origins = getattr(config, 'ALLOWED_ORIGINS', [])
if _origins:
    CORS(app, resources={r"/api/*": {"origins": _origins}})
else:
    CORS(app)

# Initialize RAG Engine
rag_engine = RAGEngine()

# Security: Maximum input lengths
MAX_MESSAGE_LENGTH = 5000
MAX_QUERY_LENGTH = 2000


def sanitize_input(text, max_length=MAX_MESSAGE_LENGTH):
    """Sanitize user input to prevent injection attacks and malicious code.

    Args:
        text: User input string
        max_length: Maximum allowed length

    Returns:
        Sanitized string
    """
    if not text or not isinstance(text, str):
        return ''

    # Truncate to max length
    text = text[:max_length]

    # Remove null bytes
    text = text.replace('\x00', '')

    # Remove control characters except newline, tab, carriage return
    text = ''.join(char for char in text if ord(
        char) >= 32 or char in '\n\t\r')

    # Detect and block common prompt injection patterns
    injection_patterns = [
        r'ignore\s+(previous|all|above|prior|earlier)\s+(instruction|command|prompt|rule|context)',
        r'ignore\s+all',
        r'disregard\s+(previous|all|above|prior)',
        r'forget\s+(previous|all|above|everything)',
        r'new\s+(instruction|command|prompt|rule)',
        r'you\s+are\s+now',
        r'act\s+as',
        r'pretend\s+to\s+be',
        r'roleplay',
        r'system\s*:\s*',
        r'assistant\s*:\s*',
        r'<\s*script\s*>',
        r'javascript\s*:',
        r'onerror\s*=',
        r'onclick\s*=',
        r'eval\s*\(',
        r'exec\s*\(',
        r'__import__\s*\(',
        r'os\.(system|popen|exec)',
        r'subprocess\.',
        r'DROP\s+TABLE',
        r'DELETE\s+FROM',
        r'INSERT\s+INTO',
        r'UPDATE\s+.*\s+SET',
        r';--',
        r'\'\s*OR\s+',
        r'UNION\s+SELECT',
        r'1\s*=\s*1',
        r'<img\s+src',
        r'onerror\s*=',
    ]

    text_lower = text.lower()
    for pattern in injection_patterns:
        if re.search(pattern, text_lower, re.IGNORECASE):
            # Log potential attack (in production, send to security monitoring)
            print(
                f"⚠️ SECURITY: Blocked potential injection attempt: {pattern}")
            return ''  # Return empty string to block the request

    return text.strip()


def is_unclear_input(text):
    """Check if user input is unclear, nonsensical, or just random characters.

    Args:
        text: User input string

    Returns:
        True if input appears unclear, False if it seems like a valid question
    """
    if not text or len(text.strip()) < 2:
        return True

    text = text.strip().lower()

    # Common greetings and conversational words that should ALWAYS be allowed
    allowed_conversational = [
        'hi', 'hey', 'hello', 'hiya', 'howdy', 'hola', 'sup', 'yo',
        'yes', 'no', 'ok', 'okay', 'cool', 'nice', 'great', 'awesome',
        'thanks', 'thank', 'thankyou', 'thanku', 'thx', 'ty',
        'bye', 'goodbye', 'regards', 'cheers', 'later', 'cya',
        'morning', 'afternoon', 'evening', 'night',
        'please', 'help', 'sorry', 'excuse'
    ]
    
    # If the text contains any allowed conversational word, it's valid
    if any(word in text for word in allowed_conversational):
        return False

    # Check for very short random inputs (but allow conversational words)
    if len(text) <= 3:
        return True

    # Check for random single letters/numbers
    if re.match(r'^[a-z0-9]{1,2}$', text):
        return True

    # Check for repeated characters (like "aaaa" or "1111")
    if len(set(text.replace(' ', ''))) <= 2 and len(text) > 3:
        return True

    # Check for keyboard mashing patterns
    keyboard_patterns = [
        r'qwerty|asdf|zxcv|qaz|wsx|edc',
        r'123456|abcdef|uvwxyz',
    ]
    
    for pattern in keyboard_patterns:
        if re.search(pattern, text):
            return True

    # If it's just random letters with no clear words, flag it
    if re.match(r'^[a-z]{4,}$', text) and not any(
        common_word in text for common_word in [
            'show', 'find', 'get', 'what', 'how', 'where', 'when', 'who',
            'data', 'table', 'record', 'info', 'customer', 'lead', 'contact',
            'search', 'list', 'count', 'total', 'report'
        ]
    ):
        return True

    return False


def validate_src_uid(src_uid):
    """Validate SRC_UID to prevent SQL injection.

    Args:
        src_uid: Source UID string

    Returns:
        Sanitized SRC_UID or None if invalid
    """
    if not src_uid or not isinstance(src_uid, str):
        return None

    # Only allow alphanumeric, underscore, hyphen, and common safe characters
    if not re.match(r'^[A-Za-z0-9_\-\.]+$', src_uid):
        print(f"⚠️ SECURITY: Invalid SRC_UID format: {src_uid}")
        return None

    return src_uid[:100]  # Limit length


@app.route('/')
def index():
    """Serve the main popup interface"""
    return send_from_directory('static', 'index.html')


@app.route('/curl')
def curl_test():
    """Serve the cURL testing page"""
    return send_from_directory('static', 'curl_test.html')


@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat requests with input sanitization"""
    try:
        # Accept JSON with or without strict Content-Type checking
        data = request.get_json(force=True, silent=True)
        if data is None:
            data = {}

        user_message = data.get('message', '')

        if not user_message:
            return jsonify({
                'success': False,
                'error': 'No message provided'
            }), 400

        # Sanitize input to prevent injection attacks
        sanitized_message = sanitize_input(user_message, MAX_MESSAGE_LENGTH)

        if not sanitized_message:
            return jsonify({
                'success': False,
                'error': 'Invalid or potentially malicious input detected'
            }), 400

        # Check for unclear/nonsensical input
        if is_unclear_input(sanitized_message):
            return jsonify({
                'success': True,
                'response': "I couldn't understand your concern. Please try asking about:\n\n" +
                           "• Database information: 'Show me table info'\n" +
                           "• Search records: 'Find customers from New York'\n" +
                           "• General queries: 'How many leads do we have?'\n" +
                           "• Specific data: 'Show me contact details for ID 123'\n" +
                           "• Business questions: 'What is our conversion rate?'\n\n" +
                           "Please provide a clear question about your data or business needs."
                           })

        # Generate response using RAG
        response = rag_engine.generate_response(sanitized_message)

        return jsonify(response)

    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'An error occurred processing your request'
        }), 500


@app.route('/api/search', methods=['POST'])
def search():
    """Handle search requests with input sanitization"""
    try:
        data = request.get_json(force=True, silent=True)
        if data is None:
            data = {}

        search_term = data.get('search_term', '')
        columns = data.get('columns', None)

        if not search_term:
            return jsonify({
                'success': False,
                'error': 'No search term provided'
            }), 400

        # Sanitize search input
        sanitized_search = sanitize_input(search_term, MAX_QUERY_LENGTH)

        if not sanitized_search:
            return jsonify({
                'success': False,
                'error': 'Invalid or potentially malicious search term'
            }), 400

        results = rag_engine.search_database(sanitized_search, columns)

        return jsonify({
            'success': True,
            'results': results,
            'count': len(results)
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'An error occurred processing your search'
        }), 500


@app.route('/api/table-info', methods=['GET'])
def table_info():
    """Get information about the target table"""
    try:
        info = rag_engine.get_table_info()
        return jsonify({
            'success': True,
            'data': info
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/src', methods=['GET'])
def get_by_src_get():
    """Get record by src uid via query param ?src_uid=... with validation"""
    src_uid = request.args.get('src_uid', '')
    if not src_uid:
        return jsonify({'success': False, 'error': 'src_uid parameter missing'}), 400

    # Validate SRC_UID to prevent SQL injection
    validated_uid = validate_src_uid(src_uid)
    if not validated_uid:
        return jsonify({'success': False, 'error': 'Invalid src_uid format'}), 400

    try:
        # Use DatabaseManager to fetch record
        table = config.TARGET_TABLE
        results = rag_engine.db_manager.get_record_by_src_uid(
            table, validated_uid)
        return jsonify({'success': True, 'count': len(results), 'results': results})
    except Exception as e:
        return jsonify({'success': False, 'error': 'An error occurred'}), 500


@app.route('/api/src', methods=['POST'])
def get_by_src_post():
    """Post JSON {src_uid: '...'} to retrieve record with validation"""
    try:
        data = request.get_json() or {}
        src_uid = data.get('src_uid')
        if not src_uid:
            return jsonify({'success': False, 'error': 'src_uid missing'}), 400

        # Validate SRC_UID to prevent SQL injection
        validated_uid = validate_src_uid(src_uid)
        if not validated_uid:
            return jsonify({'success': False, 'error': 'Invalid src_uid format'}), 400

        table = config.TARGET_TABLE
        results = rag_engine.db_manager.get_record_by_src_uid(
            table, validated_uid)
        return jsonify({'success': True, 'count': len(results), 'results': results})
    except Exception as e:
        return jsonify({'success': False, 'error': 'An error occurred'}), 500


@app.route('/api/query', methods=['GET'])
def chat_query_string():
    """Handle chat requests via query string with input sanitization
    
    Usage: /api/query?q=hello
           /api/query?q=how+many+leads
    """
    try:
        user_message = request.args.get('q', '')

        if not user_message:
            return jsonify({
                'success': False,
                'error': 'No query parameter provided. Use ?q=your+message'
            }), 400

        # Sanitize input to prevent injection attacks
        sanitized_message = sanitize_input(user_message, MAX_MESSAGE_LENGTH)

        if not sanitized_message:
            return jsonify({
                'success': False,
                'error': 'Invalid or potentially malicious input detected'
            }), 400

        # Check for unclear/nonsensical input
        if is_unclear_input(sanitized_message):
            return jsonify({
                'success': True,
                'response': "I couldn't understand your concern. Please try asking about:\n\n" +
                           "• Database information: 'Show me table info'\n" +
                           "• Search records: 'Find customers from New York'\n" +
                           "• General queries: 'How many leads do we have?'\n" +
                           "• Specific data: 'Show me contact details for ID 123'\n" +
                           "• Business questions: 'What is our conversion rate?'\n\n" +
                           "Please provide a clear question about your data or business needs."
                           })

        # Generate response using RAG
        response = rag_engine.generate_response(sanitized_message)

        return jsonify(response)

    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'An error occurred processing your request'
        }), 500


@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'Aerp.ai',
        'version': '1.0.0'
    })


@app.route('/api/nl', methods=['GET', 'POST'])
def nl_query():
    """Handle small natural-language queries with input sanitization.

    GET:  /api/nl?q=how+many+tables
    POST: {"query": "how many leads"}
    """
    try:
        if request.method == 'POST':
            data = request.get_json() or {}
            query = data.get('query', '')
        else:
            query = request.args.get('q', '')

        if not query:
            return jsonify({'success': False, 'error': 'query parameter missing'}), 400

        # Sanitize query input
        sanitized_query = sanitize_input(query, MAX_QUERY_LENGTH)

        if not sanitized_query:
            return jsonify({
                'success': False,
                'error': 'Invalid or potentially malicious query'
            }), 400

        # Delegate to the DatabaseManager's NL handler (rule-based)
        results = rag_engine.db_manager.execute_natural_language_query(
            sanitized_query)

        return jsonify({
            'success': True,
            'query': sanitized_query,
            'data': results,
            'summary': results[0]['summary'] if results else ''
        })

    except Exception as e:
        return jsonify({'success': False, 'error': 'An error occurred processing your query'}), 500


@app.route('/api/db-status', methods=['GET'])
def db_status():
    """Return database connectivity status (quick ping)."""
    try:
        ok, err = rag_engine.db_manager.ping()
        return jsonify({'success': True, 'connected': ok, 'error': err})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/internal/rebuild-kb', methods=['POST'])
def internal_rebuild_kb():
    """Secure endpoint to rebuild the RAG knowledge base without restarting the app.

    Requires header: X-Admin-Token equal to Config.ADMIN_TOKEN (if set). If ADMIN_TOKEN is empty,
    the endpoint is disabled and returns 403.
    """
    token = request.headers.get('X-Admin-Token', '')
    admin_token = getattr(config, 'ADMIN_TOKEN', '')

    if not admin_token:
        return jsonify({'success': False, 'error': 'admin endpoint disabled'}), 403

    if token != admin_token:
        return jsonify({'success': False, 'error': 'unauthorized'}), 401

    try:
        rag_engine.build_knowledge_base()
        return jsonify({
            'success': True,
            'kb_ready': getattr(rag_engine, 'kb_ready', False),
            'entries': len(getattr(rag_engine, 'knowledge_base', []))
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.before_request
def before_first_request():
    """Initialize RAG engine before first request"""
    if not hasattr(app, 'rag_initialized'):
        print("Initializing Aerp.ai...")
        if rag_engine.initialize():
            app.rag_initialized = True
            print("Aerp.ai is ready!")
        else:
            print("Failed to initialize Aerp.ai")


if __name__ == '__main__':
    print("\n" + "=" * 60)
    print("    Aerp.ai Chatbot - Development Server")
    print("    Running on: http://localhost:8000")
    print("=" * 60 + "\n")

    # Create static directory if it doesn't exist
    os.makedirs('static', exist_ok=True)

    # Run with auto-reload disabled to prevent crashes
    app.run(
        host='localhost',
        port=config.FLASK_PORT,
        debug=False,
        use_reloader=False
    )
