"""
Passenger WSGI file for Plesk Server
Plesk uses Passenger to run Python applications
"""

import sys
import os

# Get the directory of this file
INTERP = os.path.join(os.environ.get('HOME', '/home/sshuser'), '.local', 'share', 'virtualenvs', 'venv', 'bin', 'python3')
if sys.executable != INTERP:
    os.execl(INTERP, INTERP, *sys.argv)

# Add application directory to path
cwd = os.getcwd()
sys.path.insert(0, cwd)

# Import Flask application
from app import app as application

# This is what Passenger will use
if __name__ == '__main__':
    application.run()
