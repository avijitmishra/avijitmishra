# Final File List for Plesk Deployment

## Total: 26 Files + 2 Folders

### Core Application Files (4 files)
1. `app.py` - Main Flask application
2. `config.py` - Configuration management
3. `database.py` - Database connection handler
4. `rag_engine.py` - RAG engine for intelligent responses

### Production Server Files (3 files)
5. `wsgi_production.py` - WSGI entry point
6. `passenger_wsgi.py` - Plesk Passenger configuration
7. `gunicorn_config.py` - Gunicorn server configuration

### Management Scripts (4 files)
8. `start_production.sh` - Start server script
9. `stop_production.sh` - Stop server script
10. `restart_production.sh` - Restart server script
11. `check_status.sh` - Status check script

### Service Configuration (2 files)
12. `supervisor_config.txt` - Supervisor configuration
13. `systemd_service.txt` - Systemd service configuration

### Configuration Files (3 files)
14. `.env` - Environment variables (configure before upload)
15. `.env.example` - Environment template
16. `.gitignore` - Git ignore rules
17. `requirements_production.txt` - Production dependencies

### Documentation Files (6 files)
18. `README.md` - Main comprehensive deployment guide
19. `DEPLOYMENT_CHECKLIST.md` - Step-by-step deployment checklist
20. `PLESK_DEPLOYMENT_GUIDE.md` - Detailed Plesk deployment guide
21. `PLESK_DEPLOYMENT_SUMMARY.md` - Quick deployment summary
22. `QUERYSTRING_API_GUIDE.md` - Complete API reference
23. `SECURITY_FEATURES.md` - Security documentation
24. `UPLOAD_TO_PLESK.md` - Upload instructions

### Folders (2 folders)
25. `static/` - Frontend files (4 files inside)
    - `index.html` - Main chatbot UI
    - `curl_test.html` - cURL testing page
    - `script.js` - Frontend JavaScript
    - `styles.css` - Frontend styles
26. `logs/` - Log directory (empty, will be populated on server)

### Optional (can delete if not using Git)
27. `.git/` - Git repository (optional)

---

## Files Removed

✅ **35 unnecessary files deleted:**
- 15 IIS-specific files
- 8 Development/testing files
- 3 Build files
- 9 Old documentation files
- Cleanup scripts (no longer needed)
- Build directories (dist, __pycache__, .qodo, .vscode, backup)

---

## Ready for Upload!

**Total size:** ~150 KB (excluding .git folder)

**Upload command:**
```bash
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

**Exclude .git folder (optional):**
```bash
scp -P 15987 -r --exclude='.git' d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

---

## Next Steps

1. ✅ Files cleaned up (70 → 26 files)
2. ⏭️ Configure `.env` file with your database credentials
3. ⏭️ Upload files to Plesk server
4. ⏭️ Follow `README.md` for deployment
5. ⏭️ Run `./start_production.sh` on server

See **README.md** for complete deployment instructions!
