# Plesk File Manager Upload Instructions

## ✅ Files Ready for Upload

The `.git` folder and `.env` file have been removed to prevent upload errors.

**Total files to upload:** 25 files + 2 folders (static, logs)

---

## 📤 Upload Methods

### Method 1: Plesk File Manager (GUI) - RECOMMENDED

1. **Login to Plesk**
   - Go to: http://156.67.110.254:8880/
   - Login as Administrator

2. **Navigate to File Manager**
   - Click "Files" in left sidebar
   - Navigate to: `/home/sshuser/chatbot/`
   - If folder doesn't exist, create it

3. **Upload Files**
   - Click "Upload" button
   - Select all files from `d:\Chatbot\`
   - **IMPORTANT:** Upload in batches if you get errors:
     
     **Batch 1 - Core Python files:**
     - app.py
     - config.py
     - database.py
     - rag_engine.py
     
     **Batch 2 - Production files:**
     - wsgi_production.py
     - passenger_wsgi.py
     - gunicorn_config.py
     - requirements_production.txt
     
     **Batch 3 - Scripts:**
     - start_production.sh
     - stop_production.sh
     - restart_production.sh
     - check_status.sh
     
     **Batch 4 - Config files:**
     - supervisor_config.txt
     - systemd_service.txt
     - .env.example
     - .gitignore
     
     **Batch 5 - Documentation:**
     - README.md
     - DEPLOYMENT_CHECKLIST.md
     - PLESK_DEPLOYMENT_GUIDE.md
     - QUERYSTRING_API_GUIDE.md
     - SECURITY_FEATURES.md
     - UPLOAD_TO_PLESK.md
     - PLESK_DEPLOYMENT_SUMMARY.md
     - FINAL_FILE_LIST.md
     
     **Batch 6 - Folders:**
     - static/ (upload entire folder)
     - logs/ (create empty folder)

4. **Set Permissions**
   - Select all `.sh` files
   - Click "Change Permissions"
   - Set to: 755 (rwxr-xr-x)

---

### Method 2: SCP Command (Recommended for Large Uploads)

**Windows PowerShell:**
```powershell
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

**Exclude specific files:**
```powershell
# Upload without .git folder (already removed)
scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
```

---

### Method 3: FileZilla (GUI)

1. **Open FileZilla**
2. **Connection Settings:**
   - Protocol: SFTP
   - Host: 156.67.110.254
   - Port: 15987
   - Username: sshuser
   - Password: (your password)

3. **Connect and Upload:**
   - Navigate to: `/home/sshuser/chatbot/`
   - Drag and drop all files from `d:\Chatbot\`

---

### Method 4: WinSCP (GUI)

1. **Open WinSCP**
2. **Connection Settings:**
   - File protocol: SFTP
   - Host: 156.67.110.254
   - Port: 15987
   - Username: sshuser
   - Password: (your password)

3. **Upload:**
   - Navigate to: `/home/sshuser/chatbot/`
   - Upload all files

---

## ⚠️ Common Upload Errors & Solutions

### Error: "No upload response"
**Solution:** Upload files in smaller batches (see Batch 1-6 above)

### Error: ".git folder failed"
**Solution:** ✅ Already fixed - .git folder removed

### Error: "Permission denied"
**Solution:** 
- Check you're uploading to `/home/sshuser/chatbot/`
- Ensure you have write permissions

### Error: "File too large"
**Solution:** 
- Upload files individually
- Use SCP instead of Plesk File Manager

### Error: "Connection timeout"
**Solution:**
- Check internet connection
- Try uploading fewer files at once
- Use SCP method instead

---

## 📋 After Upload Checklist

Once files are uploaded:

1. **SSH to server:**
   ```bash
   ssh sshuser@156.67.110.254 -p 15987
   cd ~/chatbot
   ```

2. **Verify files:**
   ```bash
   ls -la
   ```

3. **Create .env file:**
   ```bash
   cp .env.example .env
   nano .env
   ```
   
   Add your database credentials:
   ```env
   DB_SERVER=192.168.1.167
   DB_NAME=absolutebook_2172
   DB_USER=sa
   DB_PASSWORD=?P1t8@6in4R
   DB_TIMEOUT=200
   FLASK_PORT=8000
   TARGET_TABLE=dbo.Leads
   ```

4. **Set permissions:**
   ```bash
   chmod +x *.sh
   chmod 600 .env
   ```

5. **Setup virtual environment:**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements_production.txt
   ```

6. **Start server:**
   ```bash
   ./start_production.sh
   ```

7. **Verify:**
   ```bash
   ./check_status.sh
   curl http://localhost:8000/api/health
   ```

---

## 🎯 Quick Upload Steps (Plesk File Manager)

1. ✅ Remove .git folder (already done)
2. ✅ Remove .env file (already done)
3. Login to Plesk
4. Go to Files → `/home/sshuser/chatbot/`
5. Upload files in batches (Batch 1-6)
6. Set .sh files to 755 permissions
7. SSH to server and follow "After Upload Checklist"

---

## 📞 Need Help?

If upload continues to fail:

1. **Try SCP method** (most reliable):
   ```bash
   scp -P 15987 -r d:\Chatbot\* sshuser@156.67.110.254:~/chatbot/
   ```

2. **Upload only essential files first:**
   - app.py, config.py, database.py, rag_engine.py
   - wsgi_production.py, gunicorn_config.py
   - requirements_production.txt
   - static/ folder
   - Then upload the rest

3. **Check Plesk logs** for specific errors

---

**Files are now ready for upload!** 🚀

The .git folder has been removed to prevent upload errors.
