import os
from PIL import Image

def resize_icon(image_path, output_dir):
    try:
        img = Image.open(image_path)
    except Exception as e:
        print(f"Error opening image: {e}")
        return

    # iOS App Icon sizes
    sizes = [
        (20, 1), (20, 2), (20, 3),
        (29, 1), (29, 2), (29, 3),
        (40, 1), (40, 2), (40, 3),
        (60, 2), (60, 3),
        (76, 1), (76, 2),
        (83.5, 2),
        (1024, 1)
    ]

    contents = {
        "images": [],
        "info": {
            "version": 1,
            "author": "xcode"
        }
    }

    for size_pt, scale in sizes:
        size_px = int(size_pt * scale)
        filename = f"Icon-App-{size_pt}x{size_pt}@{scale}x.png"
        
        # Special case for 1024
        if size_pt == 1024:
            filename = "Icon-App-1024x1024@1x.png"

        target_path = os.path.join(output_dir, filename)
        
        print(f"Resizing to {size_px}x{size_px} -> {target_path}")
        img_resized = img.resize((size_px, size_px), Image.Resampling.LANCZOS)
        img_resized.save(target_path)

        image_entry = {
            "size": f"{size_pt}x{size_pt}",
            "idiom": "iphone",
            "filename": filename,
            "scale": f"{scale}x"
        }
        
        # Adjust idiom for iPad sizes (76, 83.5) and marketing (1024)
        if size_pt in [76, 83.5]:
            image_entry["idiom"] = "ipad"
        elif size_pt == 1024:
            image_entry["idiom"] = "ios-marketing"
        elif size_pt in [20, 29, 40]:
             # Add ipad entry for these as well since they are shared
             ipad_entry = image_entry.copy()
             ipad_entry["idiom"] = "ipad"
             contents["images"].append(ipad_entry)

        contents["images"].append(image_entry)

    import json
    with open(os.path.join(output_dir, "Contents.json"), "w") as f:
        json.dump(contents, f, indent=4)

if __name__ == "__main__":
    # Source image path
    source_image = "C:/Users/user/.gemini/antigravity/brain/tempmediaStorage/media__1771323419808.png"
    # Output directory
    output_dir = "d:/AbsoluteCRMios/AbsoluteCRM/AbsoluteCRM/Assets.xcassets/AppIcon.appiconset"
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        
    resize_icon(source_image, output_dir)
