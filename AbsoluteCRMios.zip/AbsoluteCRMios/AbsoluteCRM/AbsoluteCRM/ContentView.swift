import SwiftUI
import WebKit

struct ContentView: View {
    private let urlString: String = "https://crm.erpabsolute.net/crm/"

    var body: some View {
        WebView(url: URL(string: urlString)!)
            .edgesIgnoringSafeArea(.all)
    }
}

struct WebView: UIViewRepresentable {
    var url: URL

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        let request = URLRequest(url: url)
        uiView.load(request)
    }
}

#Preview {
    ContentView()
}
