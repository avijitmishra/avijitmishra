import SwiftUI

@main
struct AbsoluteCRMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
